<!DOCTYPE html>
<html dir='ltr' lang='id' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>

<!-- Mirrored from bejajadigital24.blogspot.com/p/bagikan-aplikasi-naufalid.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 10 Nov 2022 06:49:11 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<link href='../../www.blogger.com/static/v1/widgets/55013136-widget_css_bundle.css' rel='stylesheet' type='text/css'/>
<link crossorigin='anonymous' href='../../use.fontawesome.com/releases/v5.3.1/css/all.css' integrity='sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU' rel='stylesheet'/>
<link href='../../maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'/>
<link href='../../maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' rel='stylesheet'/>
<script src='../../ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
<script src='../../maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
<!--[if IE]> <script> (function() { var html5 = ("abbr,article,aside,audio,canvas,datalist,details," + "figure,footer,header,hgroup,mark,menu,meter,nav,output," + "progress,section,time,video").split(','); for (var i = 0; i < html5.length; i++) { document.createElement(html5[i]); } try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {} })(); </script> <![endif]-->
<link href='https://fonts.googleapis.com/css?family=Allerta+Stencil|Anton|Archivo+Black|Arima+Madurai|Bad+Script|Bangers|Berkshire+Swash|Bubblegum+Sans|Contrail+One|Cookie|Droid+Sans+Mono|Dynalight|Encode+Sans+Semi+Expanded|Farsan|Grand+Hotel|Inconsolata|Just+Me+Again+Down+Here|Kelly+Slab|Kite+One|Kranky|Lekton|Metal+Mania|Oleo+Script+Swash+Caps|Passero+One|Pattaya|Rancho|Reem+Kufi|Russo+One|Sail|Seaweed+Script|Sirin+Stencil|Sofia|Special+Elite|Stardos+Stencil|Viga|Roboto|Droid+Sans|Lato|Jockey+One|Roboto+Condensed|Teko|Merriweather|Rubik|Raleway|Amatic+SC|Asap|Baloo+Bhai|Bangers|Cairo|Crete+Round|Dancing+Script|EB+Garamond|Francois+One|Great+Vibes|Kaushan+Script|Merriweather+Sans|Poppins:400,500,700|Montserrat:400,500,700|PT+Sans|Prata|Quicksand:400,500,700|Shadows+Into+Light|Signika+Negative|Slabo+27px|Vidaloka' rel='stylesheet'/>
<meta charset='utf-8'/>
<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<title>Bagikan Aplikasi Naufal.id</title>
<meta content='index/follow' name='robots'/>
<meta content='index/follow' name='googlebot'/>
<meta content='blogger' name='generator'/>
<link href='https://www.blogger.com/openid-server.g' rel='openid.server'/>
<link href='https://rtrwnet.xyz/' rel='openid.delegate'/>
<link href='bagikan-aplikasi-naufalid.html' rel='canonical'/>
<link href='https://rtrwnet.xyz/feeds/posts/default' rel='alternate' title='Bejajadigital24 - Atom' type='application/atom+xml'/>
<link href='https://rtrwnet.xyz/feeds/posts/default?alt=rss' rel='alternate' title='Bejajadigital24 - RSS' type='application/rss+xml'/>
<link href='https://www.blogger.com/feeds/1537200080672385442/posts/default' rel='alternate' title='Bejajadigital24 - Atom' type='application/atom+xml'/>
<meta content='https://rtrwnet.xyz/sitemap.xml' rel='sitemap' type='application/xml'/>
<meta content='Bagikan Aplikasi Naufal.id, Bejajadigital24: Bagikan Aplikasi Naufal.id, Bejajadigital24' name='description'/>
<meta content='Bagikan Aplikasi Naufal.id' name='keywords'/>
<link href='bagikan-aplikasi-naufalid.html' hreflang='x-default' rel='alternate'/>
<link href='../../lh3.googleusercontent.com/-pGir-O9yQT4/Yjn1E0j04mI/AAAAAAAAAGw/3tcdiciXndo8UxeHnvz3q03eJOdViP4gwCNcBGAsYHQ/s1600/1647965455644124-0.png' rel='icon' type='image/x-icon'/>
<!-- Open Graph -->
<meta content='Bejajadigital24' property='og:title'/>
<meta content='website' property='og:type'/>
<meta content='https://play.google.com/store/apps/details?id=com.naufal.id' property='og:url'/>
<meta content='https://lh3.googleusercontent.com/-pGir-O9yQT4/Yjn1E0j04mI/AAAAAAAAAGw/3tcdiciXndo8UxeHnvz3q03eJOdViP4gwCNcBGAsYHQ/s1600/1647965455644124-0.png' property='og:image'/>
<meta content='Bejajadigital24' property='og:description'/>
<meta content='Bejajadigital24' property='og:site_name'/>
<meta content='id' name='geo.country'/>
<meta content='id_ID' property='og:locale'/>
<meta content='en_US' property='og:locale:alternate'/>
<meta content='Indonesia' name='geo.placename'/>
<meta content='general' name='rating'/>
<meta content='Bejajadigital24' property='og:image:alt'/>
<meta content='Bejajadigital24' name='twitter:site'/>
<meta content='IE=edge,chrome=1' http-equiv='X-UA-Compatible'/>
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<meta content='blogger' name='generator'/>
<link href='https://rtrwnet.xyz/favicon.ico' rel='icon' type='image/x-icon'/>
<link href='bagikan-aplikasi-naufalid.html' rel='canonical'/>
<link rel="alternate" type="application/atom+xml" title="Bejajadigital24 - Atom" href="https://rtrwnet.xyz/feeds/posts/default" />
<link rel="alternate" type="application/rss+xml" title="Bejajadigital24 - RSS" href="https://rtrwnet.xyz/feeds/posts/default?alt=rss" />
<link rel="service.post" type="application/atom+xml" title="Bejajadigital24 - Atom" href="https://www.blogger.com/feeds/1537200080672385442/posts/default" />
<!--Can't find substitution for tag [blog.ieCssRetrofitLinks]-->
<meta content='https://play.google.com/store/apps/details?id=com.naufal.id' property='og:url'/>
<meta content='Bagikan Aplikasi Naufal.id' property='og:title'/>
<meta content=' Bagikan aplikasi          ' property='og:description'/>
<style id='page-skin-1' type='text/css'>
body{font:normal normal 20px Poppins, sans-serif;
background: #fff }
a{color:#2167c7;}
a:hover{color:#00a2ff;text-decoration:none}
#peklis-wrapper{background:#000000;}
#peklis ul li a{color:#ffffff;font:small Arial,Geneva,sans-serif;}
h2.title, p.title{color:#0000ff;font:normal normal 28px small Arial,Geneva,sans-serif;}
p.description{color:#0000ff;font:normal normal 16px small Arial,Geneva,sans-serif;}
h1.post-title.entry-title a{color:#0000ff;font:normal normal 25px medium Arial,Genevea,sans-serif;}
h1.post-title.entry-title a span{color:#0000ff;}
.sidebar h3{color:#ffffff;background:#0000ff;font:small Geneva,Arial,sans-serif;}
#blog-pager{background:transparent;font:small Geneva,Arial,sans-serif;}
#blog-pager a{color:#0000ff;}
#footer-wrapper{background:#ffffff;color:#ff0000;font:small Geneva,Arial,sans-serif;}
.berita .dalam > h3 a{color:#ffffff;background:#ffffff;font:small Geneva,Arial,sans-serif;}
.puter a{color:#0000ff;}
#outer-wrapper{background:#ffffff;}
#layout #outer-wrapper{width:100%;}
#layout #left-side{width:70%;float:left;overflow:hidden;}
#layout #right-bar{overflow:hidden;}
#layout #footer-wrapper{overflow:hidden;}
#layout #header-wrapper{overflow:hidden;}
h1.post-title.entry-title,h1.post-title.entry-title a {text-align:left;font-weight:bold;font-size: 32px;font-family: 'Poppins', sans-serif;letter-spacing:auto;line-height:auto;color:#2167c7}
h1 {font-size:32px;line-height:1.2em;padding:5px 0;font-family: 'Poppins', sans-serif;letter-spacing:auto;}
h2 {font-size:32px;line-height:1.2em;padding:5px 0;font-family: 'Poppins', sans-serif;letter-spacing:auto;}
h3 {font-size:32px;line-height:1.2em;padding:5px 0;font-family: 'Poppins', sans-serif;letter-spacing:auto;}
h4 {font-size:26px;line-height:1.2em;padding:5px 0;font-family: 'Poppins', sans-serif;letter-spacing:auto;}
h5 {font-size:22px;line-height:auto;padding:5px 0;font-family: 'Poppins', sans-serif;letter-spacing:auto;}
h6 {font-size:18px;line-height:auto;padding:5px 0;font-family: 'Poppins', sans-serif;letter-spacing:auto;}
.fitur {padding:60px 20px 60px}
.konten {margin:0px auto;padding-right:5px;padding-left:5px;max-width: 1140px;}
.konten:after{content:"";display:table;clear:both}
.style1 {font-family:'Anton', sans-serif;line-height:1.4em}
.style2 {font-family:'Russo One', sans-serif;line-height:1.2em}
.style3 {font-family:'Archivo Black', sans-serif;line-height:1.2em}
.style4 {font-family:'Jockey One', sans-serif;line-height:1.2em}
.style5 {font-family:'Roboto', sans-serif;line-height:1.2em}
.style6 {font-family:'lato', sans-serif;line-height:1.2em}
.style7 {font-family:'Bangers', cursive;line-height:1.2em}
.style8 {font-family:'Viga', sans-serif;line-height:1.2em}
.style9 {font-family:'Sirin Stencil', cursive;line-height:1.3em}
.style10 {font-family:'Kite One', sans-serif;line-height:1.4em}
.style11 {font-family:'Pattaya', sans-serif;line-height:1.2em}
.style12 {font-family:'Contrail One', cursive;line-height:1.3em}
.style13 {font-family:'Allerta Stencil', sans-serif;line-height:1.2em}
.style14 {font-family:'Encode Sans Semi Expanded', sans-serif;line-height:1.3em}
.style15 {font-family:'Special Elite', cursive;line-height:1.3em}
.style16 {font-family:'Reem Kufi', sans-serif;line-height:1.2em}
.style17 {font-family:'Arima Madurai', cursive;line-height:1.3em}
.style18 {font-family:'Bubblegum Sans', cursive;line-height:1.2em}
.style19 {font-family:'Kelly Slab', cursive;line-height:1.2em}
.style20 {font-family:'Lekton', sans-serif; line-height:1.3em}
.style21 {font-family:'Oleo Script Swash Caps', cursive;line-height:1.2em}
.style22 {font-family:'Stardos Stencil', cursive;line-height:1.2em}
.style23 {font-family:'Kranky', cursive;line-height:1.2em}
.style24 {font-family:'Seaweed Script', cursive;line-height:1.2em}
.style25 {font-family:'Sail', cursive;line-height:1.2em}
.style26 {font-family:'Dynalight', cursive;line-height:1.2em}
.style27 {font-family:'Berkshire Swash', cursive;line-height:1.2em}
.style28 {font-family:'Farsan', cursive;line-height:1.2em}
.style29 {font-family:'Cookie', cursive;line-height:1.3em}
.style30 {font-family:'Passero One', cursive;line-height:1.3em}
.style31 {font-family:'Bad Script', cursive;line-height:1.5em}
.style32 {font-family:'Grand Hotel', cursive;line-height:1.3em}
.style33 {font-family:'Metal Mania', cursive;line-height:1.3em}
.style34 {font-family:'Droid Sans Mono', monospace;line-height:1.2em}
.style35 {font-family:'Inconsolata', monospace;line-height:1.2em}
.style36 {font-family:'Sofia', cursive;line-height:1.3em}
.style37 {font-family:'Just Me Again Down Here', cursive;line-height:1.2em}
.style38 {font-family:'Rancho', cursive;line-height:1.2em}
.style39 {font-family:'Rubik', sans-serif;line-height:1.2em}
.style40 {font-family:'Merriweather', serif;line-height:1.2em}
.style41 {font-family:'Raleway', sans-serif;line-height:1.2em}
.style42 {font-family:'Teko', sans-serif;line-height:1.2em}
.style43 {font-family:'Montserrat', sans-serif;line-height:1.2em}
.style44 {font-family:'PT Sans', sans-serif;line-height:1.2em}
.style45 {font-family:'Slabo 27px', serif;line-height:1.2em}
.style46 {font-family:'Baloo Bhai', cursive;line-height:1.2em}
.style47 {font-family:'Quicksand', sans-serif;line-height:1.5em}
.style48 {font-family:'Merriweather Sans', sans-serif;line-height:1.2em}
.style49 {font-family:'Dancing Script', cursive;line-height:1.2em}
.style50 {font-family:'Shadows Into Light', cursive;line-height:1.2em}
.style51 {font-family:'Asap', sans-serif;line-height:1.2em}
.style52 {font-family:'Amatic SC', cursive;line-height:1.2em}
.style53 {font-family:'Cairo', sans-serif;line-height:1.2em}
.style54 {font-family:'Francois One', sans-serif;line-height:1.2em}
.style55 {font-family:'Crete Round', serif;line-height:1.2em}
.style56 {font-family:'EB Garamond', serif;line-height:1.2em}
.style57 {font-family:'Great Vibes', cursive;line-height:1.2em}
.style58 {font-family:'Kaushan Script', cursive;line-height:1.2em}
.style59 {font-family:'Bangers', cursive;line-height:1.2em}
.style60 {font-family:'Signika Negative', sans-serif;line-height:1.2em}
.style61 {font-family:'Vidaloka', serif;line-height:1.2em}
.style62 {font-family:'Prata', serif;line-height:1.4em}
.style63 {font-family:'Poppins', serif;line-height:1.3em}
.coklat{color:#7e623f} .merah{color:#e53e2d} .merahmuda{color:#e53177} .merahtua{color:#c60404} .hijau{color:#23c869}.hijautua{color:#049c2f}.hijaumuda{color:#9ec502}.hijautoska{color:#4adc8f}.orange{color:darkorange}.biru{color:#2167c7}.birutua{color:#29367a}.birumuda{color:#21b6fc}.birutoska{color:#1de1df}.putih{color:#ffffff}.hitam{color:#333333}.hitampekat{color:#000000}.ungu{color:#8e24ba}.ungutua{color:#7c0ab7}.ungumuda{color:#c258cf}.kuning{color:#f8ce26}.kuningtua{color:#edbe03}.kuningmuda{color:#ffd905}.krem{color:#fde0be}.kremmuda{color:#f8ecd5}.abuabu{color:#7b8691}.abumuda{color:#c5c6c7}.gold{color: #D5AD6D;background: -webkit-linear-gradient(top, #bc9248 0%, #f2d162 26%, #b17a39 35%, #f3cf57 45%, #fbdd85 55%, #d7a252 70%, #eecb71 100%);-webkit-background-clip: text;-webkit-text-fill-color: transparent;}
.sorot-coklat:hover{color:#7e623f} .sorot-merah:hover{color:#e53e2d} .sorot-merahmuda:hover{color:#e53177} .sorot-merahtua:hover{color:#c60404} .sorot-hijau:hover{color:#23c869}.sorot-hijautua:hover{color:#049c2f}.sorot-hijaumuda:hover{color:#62d552}.sorot-hijautoska:hover{color:#9ec502}.sorot-orange:hover{color:darkorange}.sorot-biru:hover{color:#2167c7}.sorot-birutua:hover{color:#29367a}.sorot-birumuda:hover{color:#21b6fc}.sorot-birutoska:hover{color:#1de1df}.sorot-putih:hover{color:#ffffff}.sorot-hitam:hover{color:#333333}.sorot-hitampekat:hover{color:#000000}.sorot-ungu:hover{color:#8e24ba}.sorot-ungutua:hover{color:#7c0ab7}.sorot-ungumuda:hover{color:#c258cf}.sorot-kuning:hover{color:#f8ce26}.sorot-kuningtua:hover{color:#edbe03}.sorot-kuningmuda:hover{color:#ffd905}.sorot-krem:hover{color:#fde0be}.sorot-kremmuda:hover{color:#f8ecd5}.sorot-abuabu:hover{color:#7b8691}.sorot-abumuda:hover{color:#c5c6c7}
#HTML1 .title,#HTML2 .title, #HTML3 .title, #HTML4 .title, #HTML5 .title, #HTML6 .title, #HTML7 .title, #HTML8 .title, #HTML9 .title, #HTML10 .title, #HTML11 .title, #HTML12 .title, #HTML13 .title, #HTML14 .title, #HTML15 .title, #HTML16 .title, #HTML17 .title, #HTML18 .title, #HTML19 .title, #HTML20 .title, #HTML21 .title, #HTML22 .title, #HTML23 .title, #HTML24 .title, #HTML25 .title, #HTML26 .title, #HTML27 .title, #HTML28 .title, #HTML29 .title{ display: none; }
.titik-merah {border-bottom: 1px dotted red;  padding-bottom:10px;margin-top:10px}
.titik-orange {border-bottom: 1px dotted darkorange; padding-bottom:10px;margin-top:10px}
.titik-kuning {border-bottom: 1px dotted yellow; padding-bottom:10px;margin-top:10px}
.titik-hijau {border-bottom: 1px dotted green; padding-bottom:10px;margin-top:10px}
.titik-biru {border-bottom: 1px dotted blue; padding-bottom:10px;margin-top:10px}
.titik-ungu {border-bottom: 1px dotted purple; padding-bottom:10px;margin-top:10px}
.titik-hitam{border-bottom: 1px dotted black; padding-bottom:10px;margin-top:10px}
.titik-putih{border-bottom: 1px dotted white; padding-bottom:10px;margin-top:10px}
.titik-abuabu{border-bottom: 1px dotted #ececec; padding-bottom:10px;margin-top:10px}
hr.merah {border: 2px solid red;  max-width: 100px;  margin-top:-5px;}
hr.orange {border: 2px solid darkorange;  max-width: 100px;  margin-top:-5px;}
hr.kuning {border: 2px solid yellow;  max-width: 100px;  margin-top:-5px;}
hr.hijau {border: 2px solid green;  max-width: 100px;  margin-top:-5px;}
hr.biru {border: 2px solid blue;  max-width: 100px;  margin-top:-5px;}
hr.ungu {border: 2px solid purple;  max-width: 100px;  margin-top:-5px;}
hr.hitam{border: 2px solid black;  max-width: 100px;  margin-top:-5px;}
hr.putih{border: 2px solid white;  max-width: 100px;  margin-top:-5px;}
hr.dot-merah {border-top: 5px dotted red;  max-width: 100px;  margin-top:-5px;}
hr.dot-orange {border-top: 5px dotted darkorange;  max-width: 100px;  margin-top:-5px;}
hr.dot-kuning {border-top: 5px dotted yellow;  max-width: 100px;  margin-top:-5px;}
hr.dot-hijau {border-top: 5px dotted green;  max-width: 100px;  margin-top:-5px;}
hr.dot-biru {border-top: 5px dotted blue;  max-width: 100px;  margin-top:-5px;}
hr.dot-ungu {border-top: 5px dotted purple;  max-width: 100px;  margin-top:-5px;}
hr.dot-hitam{border-top: 5px dotted black;  max-width: 100px;  margin-top:-5px;}
hr.dot-putih{border-top: 5px dotted white;  max-width: 100px;  margin-top:-5px;}
.hijau,.hijautua,.hijautoska,.hijaumuda,.biru,.birutua,.birumuda,.birutoska,.ungu,.ungutua,.ungumuda,.kuning,.kuningtua,.kuningmuda,.krem,.kremmuda,.merah,.merahtua,.merahmuda,.orange,.abuabu,.abumuda,.hitam,.hitampekat,.putih,.sorot-hijau,.sorot-hijautua,.sorot-hijautoska,.sorot-hijaumuda,.sorot-biru,.sorot-birutua,.sorot-birumuda,.sorot-birutoska,.sorot-ungu,.sorot-ungutua,.sorot-ungumuda,.sorot-kuning,.sorot-kuningtua,.sorot-kuningmuda,.sorot-krem,.sorot-kremmuda,.sorot-merah,.sorot-merahtua,.sorot-merahmuda,.sorot-orange,.sorot-abuabu,.sorot-abumuda,.sorot-hitam,.sorot-hitampekat,.sorot-putih{transition:all 1s ease 50ms;}
.latar-hijau,.latar-hijautua,.latar-hijautoska,.latar-hijaumuda,.latar-biru,.latar-birutua,.latar-birumuda,.latar-birutoska,.latar-ungu,.latar-ungutua,.latar-ungumuda,.latar-kuning,.latar-kuningtua,.latar-kuningmuda,.latar-krem,.latar-kremmuda,.latar-merah,.latar-merahtua,.latar-merahmuda,.latar-orange,.latar-abuabu,.latar-abumuda,.latar-hitam,.latar-hitampekat,.latar-putih,.overlay-hitam,.overlay-putih,.overlay-merah,.overlay-orange,.overlay-kuning,.overlay-ungu,.overlay-biru,.overlay-hijau{transition:all 1s ease 50ms;}
.box-shadow-hijau,.box-shadow-hijautua,.box-shadow-hijautoska,.box-shadow-hijaumuda,.box-shadow-biru,.box-shadow-birutua,.box-shadow-birumuda,.box-shadow-birutoska,.box-shadow-ungu,.box-shadow-ungutua,.box-shadow-ungumuda,.box-shadow-kuning,.box-shadow-kuningtua,.box-shadow-kuningmuda,.box-shadow-krem,.box-shadow-kremmuda,.box-shadow-merah,.box-shadow-merahtua,.box-shadow-merahmuda,.box-shadow-orange,.box-shadow-abuabu,.box-shadow-abumuda,.box-shadow-hitam,.box-shadow-hitampekat,.box-shadow-putih{transition:all 1s ease 50ms;}
.box-shadow-hijau2,.box-shadow-hijautua2,.box-shadow-hijautoska2,.box-shadow-hijaumuda2,.box-shadow-biru2,.box-shadow-birutua2,.box-shadow-birumuda2,.box-shadow-birutoska2,.box-shadow-ungu2,.box-shadow-ungutua2,.box-shadow-ungumuda2,.box-shadow-kuning2,.box-shadow-kuningtua2,.box-shadow-kuningmuda2,.box-shadow-krem2,.box-shadow-kremmuda2,.box-shadow-merah2,.box-shadow-merahtua2,.box-shadow-merahmuda2,.box-shadow-orange2,.box-shadow-abuabu2,.box-shadow-abumuda2,.box-shadow-hitam2,.box-shadow-hitampekat2,.box-shadow-putih2{transition:all 1s ease 50ms;}
.box-shadow-hijau3,.box-shadow-hijautua3,.box-shadow-hijautoska3,.box-shadow-hijaumuda3,.box-shadow-biru3,.box-shadow-birutua3,.box-shadow-birumuda3,.box-shadow-birutoska3,.box-shadow-ungu3,.box-shadow-ungutua3,.box-shadow-ungumuda3,.box-shadow-kuning3,.box-shadow-kuningtua3,.box-shadow-kuningmuda3,.box-shadow-krem3,.box-shadow-kremmuda3,.box-shadow-merah3,.box-shadow-merahtua3,.box-shadow-merahmuda3,.box-shadow-orange3,.box-shadow-abuabu3,.box-shadow-abumuda3,.box-shadow-hitam3,.box-shadow-hitampekat3,.box-shadow-putih3{transition:all 1s ease 50ms;}
.box-shadow-hijau4,.box-shadow-hijautua4,.box-shadow-hijautoska4,.box-shadow-hijaumuda4,.box-shadow-biru4,.box-shadow-birutua4,.box-shadow-birumuda4,.box-shadow-birutoska4,.box-shadow-ungu4,.box-shadow-ungutua4,.box-shadow-ungumuda4,.box-shadow-kuning4,.box-shadow-kuningtua4,.box-shadow-kuningmuda4,.box-shadow-krem4,.box-shadow-kremmuda4,.box-shadow-merah4,.box-shadow-merahtua4,.box-shadow-merahmuda4,.box-shadow-orange4,.box-shadow-abuabu4,.box-shadow-abumuda4,.box-shadow-hitam4,.box-shadow-hitampekat4,.box-shadow-putih4{transition:all 1s ease 50ms;}
.sorot-box-shadow-hijau2,.sorot-box-shadow-hijautua2,.sorot-box-shadow-hijautoska2,.sorot-box-shadow-hijaumuda2,.sorot-box-shadow-biru2,.sorot-box-shadow-birutua2,.sorot-box-shadow-birumuda2,.sorot-box-shadow-birutoska2,.sorot-box-shadow-ungu2,.sorot-box-shadow-ungutua2,.sorot-box-shadow-ungumuda2,.sorot-box-shadow-kuning2,.sorot-box-shadow-kuningtua2,.sorot-box-shadow-kuningmuda2,.sorot-box-shadow-krem2,.sorot-box-shadow-kremmuda2,.sorot-box-shadow-merah2,.sorot-box-shadow-merahtua2,.sorot-box-shadow-merahmuda2,.sorot-box-shadow-orange2,.sorot-box-shadow-abuabu2,.sorot-box-shadow-abumuda2,.sorot-box-shadow-hitam2,.sorot-box-shadow-hitampekat2,.sorot-box-shadow-putih2{transition:all 1s ease 50ms;}
.sorot-box-shadow-hijau3,.sorot-box-shadow-hijautua3,.sorot-box-shadow-hijautoska3,.sorot-box-shadow-hijaumuda3,.sorot-box-shadow-biru3,.sorot-box-shadow-birutua3,.sorot-box-shadow-birumuda3,.sorot-box-shadow-birutoska3,.sorot-box-shadow-ungu3,.sorot-box-shadow-ungutua3,.sorot-box-shadow-ungumuda3,.sorot-box-shadow-kuning3,.sorot-box-shadow-kuningtua3,.sorot-box-shadow-kuningmuda3,.sorot-box-shadow-krem3,.sorot-box-shadow-kremmuda3,.sorot-box-shadow-merah3,.sorot-box-shadow-merahtua3,.sorot-box-shadow-merahmuda3,.sorot-box-shadow-orange3,.sorot-box-shadow-abuabu3,.sorot-box-shadow-abumuda3,.sorot-box-shadow-hitam3,.sorot-box-shadow-hitampekat3,.sorot-box-shadow-putih3{transition:all 1s ease 50ms;}
.sorot-box-shadow-hijau4,.sorot-box-shadow-hijautua4,.sorot-box-shadow-hijautoska4,.sorot-box-shadow-hijaumuda4,.sorot-box-shadow-biru4,.sorot-box-shadow-birutua4,.sorot-box-shadow-birumuda4,.sorot-box-shadow-birutoska4,.sorot-box-shadow-ungu4,.sorot-box-shadow-ungutua4,.sorot-box-shadow-ungumuda4,.sorot-box-shadow-kuning4,.sorot-box-shadow-kuningtua4,.sorot-box-shadow-kuningmuda4,.sorot-box-shadow-krem4,.sorot-box-shadow-kremmuda4,.sorot-box-shadow-merah4,.sorot-box-shadow-merahtua4,.sorot-box-shadow-merahmuda4,.sorot-box-shadow-orange4,.sorot-box-shadow-abuabu4,.sorot-box-shadow-abumuda4,.sorot-box-shadow-hitam4,.sorot-box-shadow-hitampekat4,.sorot-box-shadow-putih4{transition:all 1s ease 50ms;}
.sorot-latar-hijau,.sorot-latar-hijautua,.sorot-latar-hijautoska,.sorot-latar-hijaumuda,.sorot-latar-biru,.sorot-latar-birutua,.sorot-latar-birumuda,.sorot-latar-birutoska,.sorot-latar-ungu,.sorot-latar-ungutua,.sorot-latar-ungumuda,.sorot-latar-kuning,.sorot-latar-kuningtua,.sorot-latar-kuningmuda,.sorot-latar-krem,.sorot-latar-kremmuda,.sorot-latar-merah,.sorot-latar-merahtua,.sorot-latar-merahmuda,.sorot-latar-orange,.sorot-latar-abuabu,.sorot-latar-abumuda,.sorot-latar-hitam,.sorot-latar-hitampekat,.sorot-latar-putih,.sorot-overlay-hitam,.sorot-overlay-putih,.sorot-overlay-merah,.sorot-overlay-orange,.sorot-overlay-kuning,.sorot-overlay-ungu,.sorot-overlay-biru,.sorot-overlay-hijau{transition:all 1s ease 50ms;}
.sorot-box-shadow-hijau,.sorot-box-shadow-hijautua,.sorot-box-shadow-hijautoska,.sorot-box-shadow-hijaumuda,.sorot-box-shadow-biru,.sorot-box-shadow-birutua,.sorot-box-shadow-birumuda,.sorot-box-shadow-birutoska,.sorot-box-shadow-ungu,.sorot-box-shadow-ungutua,.sorot-box-shadow-ungumuda,.sorot-box-shadow-kuning,.sorot-box-shadow-kuningtua,.sorot-box-shadow-kuningmuda,.sorot-box-shadow-krem,.sorot-box-shadow-kremmuda,.sorot-box-shadow-merah,.sorot-box-shadow-merahtua,.sorot-box-shadow-merahmuda,.sorot-box-shadow-orange,.sorot-box-shadow-abuabu,.sorot-box-shadow-abumuda,.sorot-box-shadow-hitam,.sorot-box-shadow-hitampekat,.sorot-box-shadow-putih{transition:all 1s ease 50ms;}
.sorot-latar-hijau:hover{background:#23c869;color:#ffffff}.sorot-latar-hijautua:hover{background:#049c2f;color:#ffffff}.sorot-latar-hijaumuda:hover{background:#9ec502;color:#ffffff}.sorot-latar-birudongker:hover{background:#1b4661;}.sorot-latar-biru:hover{background:#2167c7;color:#ffffff}.sorot-latar-birutua:hover{background:#29367a;color:#ffffff}.sorot-latar-birumuda:hover{background:#21b6fc;color:#ffffff}.sorot-latar-birutoska:hover{background:#1de1df;color:#494949}.sorot-latar-hijautoska:hover{background:#4adc8f;color:#ffffff}.sorot-latar-ungu:hover{background:#8e24ba;color:#ffffff}.sorot-latar-ungutua:hover{background:#7c0ab7;color:#ffffff}.sorot-latar-ungumuda:hover{background:#c258cf;color:#ffffff}.sorot-latar-kuning:hover{background:#f8ce26;color:#494949}.sorot-latar-kuningtua:hover{background:#edbe03;color:#494949}.sorot-latar-kuningmuda:hover{background:#ffd905;color:#494949}.sorot-latar-krem:hover{background:#fde0be;color:#494949}.sorot-latar-kremmuda:hover{background:#f8ecd5;color:#494949}.sorot-latar-merah:hover{background:#e53e2d;color:#ffffff}.sorot-latar-merahtua:hover{background:#c60404;color:#ffffff}.sorot-latar-merahmuda:hover{background:#e53177;color:#ffffff}.sorot-latar-orange:hover{background:darkorange;color:#ffffff!important}.sorot-latar-abuabu:hover{background:#7b8691;color:#ffffff}.sorot-latar-abumuda:hover{background:#c5c6c7;color:#ffffff}.sorot-latar-putih:hover{background:#ffffff;color:#494949}.sorot-latar-hitam:hover{background:#494949;color:#ffffff}.sorot-latar-coklat:hover{background:#7e623f;color:#ffffff}.sorot-latar-hitampekat:hover{background:#000000;color:#ffffff}
.sorot-overlay-hitam:hover{background:rgba(0,0,0,0.5)}
.sorot-overlay-putih:hover{background:rgba(255,255,255,0.5)}
.sorot-overlay-merah:hover{background:rgba(220,20,60,0.5)}
.sorot-overlay-orange:hover{background:rgba(255,140,0,0.5)}
.sorot-overlay-kuning:hover{background:rgba(255,255,0,0.5)}
.sorot-overlay-ungu:hover{background:rgba(255,0,255,0.5)}
.sorot-overlay-biru:hover{background:rgba(0,191,255,0.5)}
.sorot-overlay-hijau:hover{background:rgba(50,205,50,0.5)}
.papayawhip {color:papayawhip}.moccasin {color:moccasin}.peachpuff {color:peachpuff}.palegoldenrod {color:palegoldenrod}.khaki {color:khaki}.darkkhaki {color:darkkhaki}.yellow {color:yellow}.lawngreen {color:lawngreen}.chartreuse {color:chartreuse}.limegreen {color:limegreen}.lime {color:lime}.forestgreen {color:forestgreen}.green {color:green}.darkgreen {color:darkgreen}.greenyellow {color:greenyellow}.yellowgreen {color:yellowgreen}.springgreen {color:springgreen}.mediumspringgreen {color:mediumspringgreen}.lightgreen {color:lightgreen}.palegreen {color:palegreen}.darkseagreen {color:darkseagreen}.mediumseagreen {color:mediumseagreen}.seagreen {color:seagreen}.olive {color:olive}.darkolivegreen {color:darkolivegreen}.olivedrab {color:olivedrab}.lightcyan {color:lightcyan}.cyan {color:cyan}.aqua {color:aqua}.aquamarine {color:aquamarine}.mediumaquamarine {color:mediumaquamarine}.paleturquoise {color:paleturquoise}.turquoise {color:turquoise}.mediumturquoise {color:mediumturquoise}.darkturquoise {color:darkturquoise}.lightseagreen {color:lightseagreen}.cadetblue {color:cadetblue}.darkcyan {color:darkcyan}.teal {color:teal}.powderblue {color:powderblue}.lightblue {color:lightblue}.lightskyblue {color:lightskyblue}.skyblue {color:skyblue}.deepskyblue {color:deepskyblue}.lightsteelblue {color:lightsteelblue}.dodgerblue {color:dodgerblue}.cornflowerblue {color:cornflowerblue}.steelblue {color:steelblue}.royalblue {color:royalblue}.blue {color:blue}.mediumblue {color:mediumblue}.darkblue {color:darkblue}.navy {color:navy}.midnightblue {color:midnightblue}.mediumslateblue {color:mediumslateblue}.slateblue {color:slateblue}.darkslateblue {color:darkslateblue}.lavender {color:lavender}.thistle {color:thistle}.plum {color:plum}.violet {color:violet}.orchid {color:orchid}.fuchsia {color:fuchsia}.magenta {color:magenta}.mediumorchid {color:mediumorchid}.mediumpurple {color:mediumpurple}.blueviolet {color:blueviolet}.darkviolet {color:darkviolet}.darkorchid {color:darkorchid}.darkmagenta {color:darkmagenta}.purple {color:purple}.indigo {color:indigo}.pink {color:pink}.lightpink {color:lightpink}.hotpink {color:hotpink}.deeppink {color:deeppink}.palevioletred {color:palevioletred}.mediumvioletred {color:mediumvioletred}.white {color:white}.snow {color:snow}.honeydew {color:honeydew}.mintcream {color:mintcream}.azure {color:azure}.aliceblue {color:aliceblue}.ghostwhite {color:ghostwhite}.whitesmoke {color:whitesmoke}.seashell {color:seashell}.beige {color:beige}.oldlace {color:oldlace}.floralwhite {color:floralwhite}.ivory {color:ivory}.antiquewhite {color:antiquewhite}.linen {color:linen}.lavenderblush {color:lavenderblush}.mistyrose {color:mistyrose}.gainsboro {color:gainsboro}.lightgray {color:lightgray}.silver {color:silver}.darkgray {color:darkgray}.gray {color:gray}.dimgray {color:dimgray}.lightslategray {color:lightslategray}.slategray {color:slategray}.darkslategray {color:darkslategray}.black {color:black}.cornsilk {color:cornsilk}.blanchedalmond {color:blanchedalmond}.bisque {color:bisque}.navajowhite {color:navajowhite}.wheat {color:wheat}.burlywood {color:burlywood}.tan {color:tan}.rosybrown {color:rosybrown}.sandybrown {color:sandybrown}.goldenrod {color:goldenrod}.peru {color:peru}.chocolate {color:chocolate}.saddlebrown {color:saddlebrown}.sienna {color:sienna}.brown {color:brown}.maroon {color:maroon}
.bg-papayawhip {background:papayawhip}.bg-moccasin {background:moccasin}.bg-peachpuff {background:peachpuff}.bg-palegoldenrod {background:palegoldenrod}.bg-khaki {background:khaki}.bg-darkkhaki {background:darkkhaki}.bg-yellow {background:yellow}.bg-lawngreen {background:lawngreen}.bg-chartreuse {background:chartreuse}.bg-limegreen {background:limegreen}.bg-lime {background:lime}.bg-forestgreen {background:forestgreen}.bg-green {background:green}.bg-darkgreen {background:darkgreen}.bg-greenyellow {background:greenyellow}.bg-yellowgreen {background:yellowgreen}.bg-springgreen {background:springgreen}.bg-mediumspringgreen {background:mediumspringgreen}.bg-lightgreen {background:lightgreen}.bg-palegreen {background:palegreen}.bg-darkseagreen {background:darkseagreen}.bg-mediumseagreen {background:mediumseagreen}.bg-seagreen {background:seagreen}.bg-olive {background:olive}.bg-darkolivegreen {background:darkolivegreen}.bg-olivedrab {background:olivedrab}.bg-lightcyan {background:lightcyan}.bg-cyan {background:cyan}.bg-aqua {background:aqua}.bg-aquamarine {background:aquamarine}.bg-mediumaquamarine {background:mediumaquamarine}.bg-paleturquoise {background:paleturquoise}.bg-turquoise {background:turquoise}.bg-mediumturquoise {background:mediumturquoise}.bg-darkturquoise {background:darkturquoise}.bg-lightseagreen {background:lightseagreen}.bg-cadetblue {background:cadetblue}.bg-darkcyan {background:darkcyan}.bg-teal {background:teal}.bg-powderblue {background:powderblue}.bg-lightblue {background:lightblue}.bg-lightskyblue {background:lightskyblue}.bg-skyblue {background:skyblue}.bg-deepskyblue {background:deepskyblue}.bg-lightsteelblue {background:lightsteelblue}.bg-dodgerblue {background:dodgerblue}.bg-cornflowerblue {background:cornflowerblue}.bg-steelblue {background:steelblue}.bg-royalblue {background:royalblue}.bg-blue {background:blue}.bg-mediumblue {background:mediumblue}.bg-darkblue {background:darkblue}.bg-navy {background:navy}.bg-midnightblue {background:midnightblue}.bg-mediumslateblue {background:mediumslateblue}.bg-slateblue {background:slateblue}.bg-darkslateblue {background:darkslateblue}.bg-lavender {background:lavender}.bg-thistle {background:thistle}.bg-plum {background:plum}.bg-violet {background:violet}.bg-orchid {background:orchid}.bg-fuchsia {background:fuchsia}.bg-magenta {background:magenta}.bg-mediumorchid {background:mediumorchid}.bg-mediumpurple {background:mediumpurple}.bg-blueviolet {background:blueviolet}.bg-darkviolet {background:darkviolet}.bg-darkorchid {background:darkorchid}.bg-darkmagenta {background:darkmagenta}.bg-purple {background:purple}.bg-indigo {background:indigo}.bg-pink {background:pink}.bg-lightpink {background:lightpink}.bg-hotpink {background:hotpink}.bg-deeppink {background:deeppink}.bg-palevioletred {background:palevioletred}.bg-mediumvioletred {background:mediumvioletred}.bg-white {background:white}.bg-snow {background:snow}.bg-honeydew {background:honeydew}.bg-mintcream {background:mintcream}.bg-azure {background:azure}.bg-aliceblue {background:aliceblue}.bg-ghostwhite {background:ghostwhite}.bg-whitesmoke {background:whitesmoke}.bg-seashell {background:seashell}.bg-beige {background:beige}.bg-oldlace {background:oldlace}.bg-floralwhite {background:floralwhite}.bg-ivory {background:ivory}.bg-antiquewhite {background:antiquewhite}.bg-linen {background:linen}.bg-lavenderblush {background:lavenderblush}.bg-mistyrose {background:mistyrose}.bg-gainsboro {background:gainsboro}.bg-lightgray {background:lightgray}.bg-silver {background:silver}.bg-darkgray {background:darkgray}.bg-gray {background:gray}.bg-dimgray {background:dimgray}.bg-lightslategray {background:lightslategray}.bg-slategray {background:slategray}.bg-darkslategray {background:darkslategray}.bg-black {background:black}.bg-cornsilk {background:cornsilk}.bg-blanchedalmond {background:blanchedalmond}.bg-bisque {background:bisque}.bg-navajowhite {background:navajowhite}.bg-wheat {background:wheat}.bg-burlywood {background:burlywood}.bg-tan {background:tan}.bg-rosybrown {background:rosybrown}.bg-sandybrown {background:sandybrown}.bg-goldenrod {background:goldenrod}.bg-peru {background:peru}.bg-chocolate {background:chocolate}.bg-saddlebrown {background:saddlebrown}.bg-sienna {background:sienna}.bg-brown {background:brown}.bg-maroon {background:maroon}
.btn-papayawhip {background:papayawhip;border: 2px solid papayawhip}.btn-moccasin {background:moccasin;border: 2px solid moccasin}.btn-peachpuff {background:peachpuff;border: 2px solid peachpuff}.btn-palegoldenrod {background:palegoldenrod;border: 2px solid palegoldenrod}.btn-khaki {background:khaki;border: 2px solid khaki}.btn-darkkhaki {background:darkkhaki;border: 2px solid darkkhaki}.btn-yellow {background:yellow;border: 2px solid yellow}.btn-lawngreen {background:lawngreen;border: 2px solid lawngreen}.btn-chartreuse {background:chartreuse;border: 2px solid chartreuse}.btn-limegreen {background:limegreen;border: 2px solid limegreen}.btn-lime {background:lime;border: 2px solid lime}.btn-forestgreen {background:forestgreen;border: 2px solid forestgreen}.btn-green {background:green;border: 2px solid green}.btn-darkgreen {background:darkgreen;border: 2px solid darkgreen}.btn-greenyellow {background:greenyellow;border: 2px solid greenyellow}.btn-yellowgreen {background:yellowgreen;border: 2px solid yellowgreen}.btn-springgreen {background:springgreen;border: 2px solid springgreen}.btn-mediumspringgreen {background:mediumspringgreen;border: 2px solid mediumspringgreen}.btn-lightgreen {background:lightgreen;border: 2px solid lightgreen}.btn-palegreen {background:palegreen;border: 2px solid palegreen}.btn-darkseagreen {background:darkseagreen;border: 2px solid darkseagreen}.btn-mediumseagreen {background:mediumseagreen;border: 2px solid mediumseagreen}.btn-seagreen {background:seagreen;border: 2px solid seagreen}.btn-olive {background:olive;border: 2px solid olive}.btn-darkolivegreen {background:darkolivegreen;border: 2px solid darkolivegreen}.btn-olivedrab {background:olivedrab;border: 2px solid olivedrab}.btn-lightcyan {background:lightcyan;border: 2px solid lightcyan}.btn-cyan {background:cyan;border: 2px solid cyan}.btn-aqua {background:aqua;border: 2px solid aqua}.btn-aquamarine {background:aquamarine;border: 2px solid aquamarine}.btn-mediumaquamarine {background:mediumaquamarine;border: 2px solid mediumaquamarine}.btn-paleturquoise {background:paleturquoise;border: 2px solid paleturquoise}.btn-turquoise {background:turquoise;border: 2px solid turquoise}.btn-mediumturquoise {background:mediumturquoise;border: 2px solid mediumturquoise}.btn-darkturquoise {background:darkturquoise;border: 2px solid darkturquoise}.btn-lightseagreen {background:lightseagreen;border: 2px solid lightseagreen}.btn-cadetblue {background:cadetblue;border: 2px solid cadetblue}.btn-darkcyan {background:darkcyan;border: 2px solid darkcyan}.btn-teal {background:teal;border: 2px solid teal}.btn-powderblue {background:powderblue;border: 2px solid powderblue}.btn-lightblue {background:lightblue;border: 2px solid lightblue}.btn-lightskyblue {background:lightskyblue;border: 2px solid lightskyblue}.btn-skyblue {background:skyblue;border: 2px solid skyblue}.btn-deepskyblue {background:deepskyblue;border: 2px solid deepskyblue}.btn-lightsteelblue {background:lightsteelblue;border: 2px solid lightsteelblue}.btn-dodgerblue {background:dodgerblue;border: 2px solid dodgerblue}.btn-cornflowerblue {background:cornflowerblue;border: 2px solid cornflowerblue}.btn-steelblue {background:steelblue;border: 2px solid steelblue}.btn-royalblue {background:royalblue;border: 2px solid royalblue}.btn-blue {background:blue;border: 2px solid blue}.btn-mediumblue {background:mediumblue;border: 2px solid mediumblue}.btn-darkblue {background:darkblue;border: 2px solid darkblue}.btn-navy {background:navy;border: 2px solid navy}.btn-midnightblue {background:midnightblue;border: 2px solid midnightblue}.btn-mediumslateblue {background:mediumslateblue;border: 2px solid mediumslateblue}.btn-slateblue {background:slateblue;border: 2px solid slateblue}.btn-darkslateblue {background:darkslateblue;border: 2px solid darkslateblue}.btn-lavender {background:lavender;border: 2px solid lavender}.btn-thistle {background:thistle;border: 2px solid thistle}.btn-plum {background:plum;border: 2px solid plum}.btn-violet {background:violet;border: 2px solid violet}.btn-orchid {background:orchid;border: 2px solid orchid}.btn-fuchsia {background:fuchsia;border: 2px solid fuchsia}.btn-magenta {background:magenta;border: 2px solid magenta}.btn-mediumorchid {background:mediumorchid;border: 2px solid mediumorchid}.btn-mediumpurple {background:mediumpurple;border: 2px solid mediumpurple}.btn-blueviolet {background:blueviolet;border: 2px solid blueviolet}.btn-darkviolet {background:darkviolet;border: 2px solid darkviolet}.btn-darkorchid {background:darkorchid;border: 2px solid darkorchid}.btn-darkmagenta {background:darkmagenta;border: 2px solid darkmagenta}.btn-purple {background:purple;border: 2px solid purple}.btn-indigo {background:indigo;border: 2px solid indigo}.btn-pink {background:pink;border: 2px solid pink}.btn-lightpink {background:lightpink;border: 2px solid lightpink}.btn-hotpink {background:hotpink;border: 2px solid hotpink}.btn-deeppink {background:deeppink;border: 2px solid deeppink}.btn-palevioletred {background:palevioletred;border: 2px solid palevioletred}.btn-mediumvioletred {background:mediumvioletred;border: 2px solid mediumvioletred}.btn-white {background:white;border: 2px solid white}.btn-snow {background:snow;border: 2px solid snow}.btn-honeydew {background:honeydew;border: 2px solid honeydew}.btn-mintcream {background:mintcream;border: 2px solid mintcream}.btn-azure {background:azure;border: 2px solid azure}.btn-aliceblue {background:aliceblue;border: 2px solid aliceblue}.btn-ghostwhite {background:ghostwhite;border: 2px solid ghostwhite}.btn-whitesmoke {background:whitesmoke;border: 2px solid whitesmoke}.btn-seashell {background:seashell;border: 2px solid seashell}.btn-beige {background:beige;border: 2px solid beige}.btn-oldlace {background:oldlace;border: 2px solid oldlace}.btn-floralwhite {background:floralwhite;border: 2px solid floralwhite}.btn-ivory {background:ivory;border: 2px solid ivory}.btn-antiquewhite {background:antiquewhite;border: 2px solid antiquewhite}.btn-linen {background:linen;border: 2px solid linen}.btn-lavenderblush {background:lavenderblush;border: 2px solid lavenderblush}.btn-mistyrose {background:mistyrose;border: 2px solid mistyrose}.btn-gainsboro {background:gainsboro;border: 2px solid gainsboro}.btn-lightgray {background:lightgray;border: 2px solid lightgray}.btn-silver {background:silver;border: 2px solid silver}.btn-darkgray {background:darkgray;border: 2px solid darkgray}.btn-gray {background:gray;border: 2px solid gray}.btn-dimgray {background:dimgray;border: 2px solid dimgray}.btn-lightslategray {background:lightslategray;border: 2px solid lightslategray}.btn-slategray {background:slategray;border: 2px solid slategray}.btn-darkslategray {background:darkslategray;border: 2px solid darkslategray}.btn-black {background:black;border: 2px solid black}.btn-cornsilk {background:cornsilk;border: 2px solid cornsilk}.btn-blanchedalmond {background:blanchedalmond;border: 2px solid blanchedalmond}.btn-bisque {background:bisque;border: 2px solid bisque}.btn-navajowhite {background:navajowhite;border: 2px solid navajowhite}.btn-wheat {background:wheat;border: 2px solid wheat}.btn-burlywood {background:burlywood;border: 2px solid burlywood}.btn-tan {background:tan;border: 2px solid tan}.btn-rosybrown {background:rosybrown;border: 2px solid rosybrown}.btn-sandybrown {background:sandybrown;border: 2px solid sandybrown}.btn-goldenrod {background:goldenrod;border: 2px solid goldenrod}.btn-peru {background:peru;border: 2px solid peru}.btn-chocolate {background:chocolate;border: 2px solid chocolate}.btn-saddlebrown {background:saddlebrown;border: 2px solid saddlebrown}.btn-sienna {background:sienna;border: 2px solid sienna}.btn-brown {background:brown;border: 2px solid brown}.btn-maroon {background:maroon;border: 2px solid maroon}
.border-papayawhip {border:2px solid papayawhip;margin:0 auto;padding:10px}.border-moccasin {border:2px solid moccasin;margin:0 auto;padding:10px}.border-peachpuff {border:2px solid peachpuff;margin:0 auto;padding:10px}.border-palegoldenrod {border:2px solid palegoldenrod;margin:0 auto;padding:10px}.border-khaki {border:2px solid khaki;margin:0 auto;padding:10px}.border-darkkhaki {border:2px solid darkkhaki;margin:0 auto;padding:10px}.border-yellow {border:2px solid yellow;margin:0 auto;padding:10px}.border-lawngreen {border:2px solid lawngreen;margin:0 auto;padding:10px}.border-chartreuse {border:2px solid chartreuse;margin:0 auto;padding:10px}.border-limegreen {border:2px solid limegreen;margin:0 auto;padding:10px}.border-lime {border:2px solid lime;margin:0 auto;padding:10px}.border-forestgreen {border:2px solid forestgreen;margin:0 auto;padding:10px}.border-green {border:2px solid green;margin:0 auto;padding:10px}.border-darkgreen {border:2px solid darkgreen;margin:0 auto;padding:10px}.border-greenyellow {border:2px solid greenyellow;margin:0 auto;padding:10px}.border-yellowgreen {border:2px solid yellowgreen;margin:0 auto;padding:10px}.border-springgreen {border:2px solid springgreen;margin:0 auto;padding:10px}.border-mediumspringgreen {border:2px solid mediumspringgreen;margin:0 auto;padding:10px}.border-lightgreen {border:2px solid lightgreen;margin:0 auto;padding:10px}.border-palegreen {border:2px solid palegreen;margin:0 auto;padding:10px}.border-darkseagreen {border:2px solid darkseagreen;margin:0 auto;padding:10px}.border-mediumseagreen {border:2px solid mediumseagreen;margin:0 auto;padding:10px}.border-seagreen {border:2px solid seagreen;margin:0 auto;padding:10px}.border-olive {border:2px solid olive;margin:0 auto;padding:10px}.border-darkolivegreen {border:2px solid darkolivegreen;margin:0 auto;padding:10px}.border-olivedrab {border:2px solid olivedrab;margin:0 auto;padding:10px}.border-lightcyan {border:2px solid lightcyan;margin:0 auto;padding:10px}.border-cyan {border:2px solid cyan;margin:0 auto;padding:10px}.border-aqua {border:2px solid aqua;margin:0 auto;padding:10px}.border-aquamarine {border:2px solid aquamarine;margin:0 auto;padding:10px}.border-mediumaquamarine {border:2px solid mediumaquamarine;margin:0 auto;padding:10px}.border-paleturquoise {border:2px solid paleturquoise;margin:0 auto;padding:10px}.border-turquoise {border:2px solid turquoise;margin:0 auto;padding:10px}.border-mediumturquoise {border:2px solid mediumturquoise;margin:0 auto;padding:10px}.border-darkturquoise {border:2px solid darkturquoise;margin:0 auto;padding:10px}.border-lightseagreen {border:2px solid lightseagreen;margin:0 auto;padding:10px}.border-cadetblue {border:2px solid cadetblue;margin:0 auto;padding:10px}.border-darkcyan {border:2px solid darkcyan;margin:0 auto;padding:10px}.border-teal {border:2px solid teal;margin:0 auto;padding:10px}.border-powderblue {border:2px solid powderblue;margin:0 auto;padding:10px}.border-lightblue {border:2px solid lightblue;margin:0 auto;padding:10px}.border-lightskyblue {border:2px solid lightskyblue;margin:0 auto;padding:10px}.border-skyblue {border:2px solid skyblue;margin:0 auto;padding:10px}.border-deepskyblue {border:2px solid deepskyblue;margin:0 auto;padding:10px}.border-lightsteelblue {border:2px solid lightsteelblue;margin:0 auto;padding:10px}.border-dodgerblue {border:2px solid dodgerblue;margin:0 auto;padding:10px}.border-cornflowerblue {border:2px solid cornflowerblue;margin:0 auto;padding:10px}.border-steelblue {border:2px solid steelblue;margin:0 auto;padding:10px}.border-royalblue {border:2px solid royalblue;margin:0 auto;padding:10px}.border-blue {border:2px solid blue;margin:0 auto;padding:10px}.border-mediumblue {border:2px solid mediumblue;margin:0 auto;padding:10px}.border-darkblue {border:2px solid darkblue;margin:0 auto;padding:10px}.border-navy {border:2px solid navy;margin:0 auto;padding:10px}.border-midnightblue {border:2px solid midnightblue;margin:0 auto;padding:10px}.border-mediumslateblue {border:2px solid mediumslateblue;margin:0 auto;padding:10px}.border-slateblue {border:2px solid slateblue;margin:0 auto;padding:10px}.border-darkslateblue {border:2px solid darkslateblue;margin:0 auto;padding:10px}.border-lavender {border:2px solid lavender;margin:0 auto;padding:10px}.border-thistle {border:2px solid thistle;margin:0 auto;padding:10px}.border-plum {border:2px solid plum;margin:0 auto;padding:10px}.border-violet {border:2px solid violet;margin:0 auto;padding:10px}.border-orchid {border:2px solid orchid;margin:0 auto;padding:10px}.border-fuchsia {border:2px solid fuchsia;margin:0 auto;padding:10px}.border-magenta {border:2px solid magenta;margin:0 auto;padding:10px}.border-mediumorchid {border:2px solid mediumorchid;margin:0 auto;padding:10px}.border-mediumpurple {border:2px solid mediumpurple;margin:0 auto;padding:10px}.border-blueviolet {border:2px solid blueviolet;margin:0 auto;padding:10px}.border-darkviolet {border:2px solid darkviolet;margin:0 auto;padding:10px}.border-darkorchid {border:2px solid darkorchid;margin:0 auto;padding:10px}.border-darkmagenta {border:2px solid darkmagenta;margin:0 auto;padding:10px}.border-purple {border:2px solid purple;margin:0 auto;padding:10px}.border-indigo {border:2px solid indigo;margin:0 auto;padding:10px}.border-pink {border:2px solid pink;margin:0 auto;padding:10px}.border-lightpink {border:2px solid lightpink;margin:0 auto;padding:10px}.border-hotpink {border:2px solid hotpink;margin:0 auto;padding:10px}.border-deeppink {border:2px solid deeppink;margin:0 auto;padding:10px}.border-palevioletred {border:2px solid palevioletred;margin:0 auto;padding:10px}.border-mediumvioletred {border:2px solid mediumvioletred;margin:0 auto;padding:10px}.border-white {border:2px solid white;margin:0 auto;padding:10px}.border-snow {border:2px solid snow;margin:0 auto;padding:10px}.border-honeydew {border:2px solid honeydew;margin:0 auto;padding:10px}.border-mintcream {border:2px solid mintcream;margin:0 auto;padding:10px}.border-azure {border:2px solid azure;margin:0 auto;padding:10px}.border-aliceblue {border:2px solid aliceblue;margin:0 auto;padding:10px}.border-ghostwhite {border:2px solid ghostwhite;margin:0 auto;padding:10px}.border-whitesmoke {border:2px solid whitesmoke;margin:0 auto;padding:10px}.border-seashell {border:2px solid seashell;margin:0 auto;padding:10px}.border-beige {border:2px solid beige;margin:0 auto;padding:10px}.border-oldlace {border:2px solid oldlace;margin:0 auto;padding:10px}.border-floralwhite {border:2px solid floralwhite;margin:0 auto;padding:10px}.border-ivory {border:2px solid ivory;margin:0 auto;padding:10px}.border-antiquewhite {border:2px solid antiquewhite;margin:0 auto;padding:10px}.border-linen {border:2px solid linen;margin:0 auto;padding:10px}.border-lavenderblush {border:2px solid lavenderblush;margin:0 auto;padding:10px}.border-mistyrose {border:2px solid mistyrose;margin:0 auto;padding:10px}.border-gainsboro {border:2px solid gainsboro;margin:0 auto;padding:10px}.border-lightgray {border:2px solid lightgray;margin:0 auto;padding:10px}.border-silver {border:2px solid silver;margin:0 auto;padding:10px}.border-darkgray {border:2px solid darkgray;margin:0 auto;padding:10px}.border-gray {border:2px solid gray;margin:0 auto;padding:10px}.border-dimgray {border:2px solid dimgray;margin:0 auto;padding:10px}.border-lightslategray {border:2px solid lightslategray;margin:0 auto;padding:10px}.border-slategray {border:2px solid slategray;margin:0 auto;padding:10px}.border-darkslategray {border:2px solid darkslategray;margin:0 auto;padding:10px}.border-black {border:2px solid black;margin:0 auto;padding:10px}.border-cornsilk {border:2px solid cornsilk;margin:0 auto;padding:10px}.border-blanchedalmond {border:2px solid blanchedalmond;margin:0 auto;padding:10px}.border-bisque {border:2px solid bisque;margin:0 auto;padding:10px}.border-navajowhite {border:2px solid navajowhite;margin:0 auto;padding:10px}.border-wheat {border:2px solid wheat;margin:0 auto;padding:10px}.border-burlywood {border:2px solid burlywood;margin:0 auto;padding:10px}.border-tan {border:2px solid tan;margin:0 auto;padding:10px}.border-rosybrown {border:2px solid rosybrown;margin:0 auto;padding:10px}.border-sandybrown {border:2px solid sandybrown;margin:0 auto;padding:10px}.border-goldenrod {border:2px solid goldenrod;margin:0 auto;padding:10px}.border-peru {border:2px solid peru;margin:0 auto;padding:10px}.border-chocolate {border:2px solid chocolate;margin:0 auto;padding:10px}.border-saddlebrown {border:2px solid saddlebrown;margin:0 auto;padding:10px}.border-sienna {border:2px solid sienna;margin:0 auto;padding:10px}.border-brown {border:2px solid brown;margin:0 auto;padding:10px}.border-maroon {border:2px solid maroon}.border-putus-papayawhip {border:2px dashed papayawhip;margin:0 auto;padding:10px}.border-putus-moccasin {border:2px dashed moccasin;margin:0 auto;padding:10px}.border-putus-peachpuff {border:2px dashed peachpuff;margin:0 auto;padding:10px}.border-putus-palegoldenrod {border:2px dashed palegoldenrod;margin:0 auto;padding:10px}.border-putus-khaki {border:2px dashed khaki;margin:0 auto;padding:10px}.border-putus-darkkhaki {border:2px dashed darkkhaki;margin:0 auto;padding:10px}.border-putus-yellow {border:2px dashed yellow;margin:0 auto;padding:10px}.border-putus-lawngreen {border:2px dashed lawngreen;margin:0 auto;padding:10px}.border-putus-chartreuse {border:2px dashed chartreuse;margin:0 auto;padding:10px}.border-putus-limegreen {border:2px dashed limegreen;margin:0 auto;padding:10px}.border-putus-lime {border:2px dashed lime;margin:0 auto;padding:10px}.border-putus-forestgreen {border:2px dashed forestgreen;margin:0 auto;padding:10px}.border-putus-green {border:2px dashed green;margin:0 auto;padding:10px}.border-putus-darkgreen {border:2px dashed darkgreen;margin:0 auto;padding:10px}.border-putus-greenyellow {border:2px dashed greenyellow;margin:0 auto;padding:10px}.border-putus-yellowgreen {border:2px dashed yellowgreen;margin:0 auto;padding:10px}.border-putus-springgreen {border:2px dashed springgreen;margin:0 auto;padding:10px}.border-putus-mediumspringgreen {border:2px dashed mediumspringgreen;margin:0 auto;padding:10px}.border-putus-lightgreen {border:2px dashed lightgreen;margin:0 auto;padding:10px}.border-putus-palegreen {border:2px dashed palegreen;margin:0 auto;padding:10px}.border-putus-darkseagreen {border:2px dashed darkseagreen;margin:0 auto;padding:10px}.border-putus-mediumseagreen {border:2px dashed mediumseagreen;margin:0 auto;padding:10px}.border-putus-seagreen {border:2px dashed seagreen;margin:0 auto;padding:10px}.border-putus-olive {border:2px dashed olive;margin:0 auto;padding:10px}.border-putus-darkolivegreen {border:2px dashed darkolivegreen;margin:0 auto;padding:10px}.border-putus-olivedrab {border:2px dashed olivedrab;margin:0 auto;padding:10px}.border-putus-lightcyan {border:2px dashed lightcyan;margin:0 auto;padding:10px}.border-putus-cyan {border:2px dashed cyan;margin:0 auto;padding:10px}.border-putus-aqua {border:2px dashed aqua;margin:0 auto;padding:10px}.border-putus-aquamarine {border:2px dashed aquamarine;margin:0 auto;padding:10px}.border-putus-mediumaquamarine {border:2px dashed mediumaquamarine;margin:0 auto;padding:10px}.border-putus-paleturquoise {border:2px dashed paleturquoise;margin:0 auto;padding:10px}.border-putus-turquoise {border:2px dashed turquoise;margin:0 auto;padding:10px}.border-putus-mediumturquoise {border:2px dashed mediumturquoise;margin:0 auto;padding:10px}.border-putus-darkturquoise {border:2px dashed darkturquoise;margin:0 auto;padding:10px}.border-putus-lightseagreen {border:2px dashed lightseagreen;margin:0 auto;padding:10px}.border-putus-cadetblue {border:2px dashed cadetblue;margin:0 auto;padding:10px}.border-putus-darkcyan {border:2px dashed darkcyan;margin:0 auto;padding:10px}.border-putus-teal {border:2px dashed teal;margin:0 auto;padding:10px}.border-putus-powderblue {border:2px dashed powderblue;margin:0 auto;padding:10px}.border-putus-lightblue {border:2px dashed lightblue;margin:0 auto;padding:10px}.border-putus-lightskyblue {border:2px dashed lightskyblue;margin:0 auto;padding:10px}.border-putus-skyblue {border:2px dashed skyblue;margin:0 auto;padding:10px}.border-putus-deepskyblue {border:2px dashed deepskyblue;margin:0 auto;padding:10px}.border-putus-lightsteelblue {border:2px dashed lightsteelblue;margin:0 auto;padding:10px}.border-putus-dodgerblue {border:2px dashed dodgerblue;margin:0 auto;padding:10px}.border-putus-cornflowerblue {border:2px dashed cornflowerblue;margin:0 auto;padding:10px}.border-putus-steelblue {border:2px dashed steelblue;margin:0 auto;padding:10px}.border-putus-royalblue {border:2px dashed royalblue;margin:0 auto;padding:10px}.border-putus-blue {border:2px dashed blue;margin:0 auto;padding:10px}.border-putus-mediumblue {border:2px dashed mediumblue;margin:0 auto;padding:10px}.border-putus-darkblue {border:2px dashed darkblue;margin:0 auto;padding:10px}.border-putus-navy {border:2px dashed navy;margin:0 auto;padding:10px}.border-putus-midnightblue {border:2px dashed midnightblue;margin:0 auto;padding:10px}.border-putus-mediumslateblue {border:2px dashed mediumslateblue;margin:0 auto;padding:10px}.border-putus-slateblue {border:2px dashed slateblue;margin:0 auto;padding:10px}.border-putus-darkslateblue {border:2px dashed darkslateblue;margin:0 auto;padding:10px}.border-putus-lavender {border:2px dashed lavender;margin:0 auto;padding:10px}.border-putus-thistle {border:2px dashed thistle;margin:0 auto;padding:10px}.border-putus-plum {border:2px dashed plum;margin:0 auto;padding:10px}.border-putus-violet {border:2px dashed violet;margin:0 auto;padding:10px}.border-putus-orchid {border:2px dashed orchid;margin:0 auto;padding:10px}.border-putus-fuchsia {border:2px dashed fuchsia;margin:0 auto;padding:10px}.border-putus-magenta {border:2px dashed magenta;margin:0 auto;padding:10px}.border-putus-mediumorchid {border:2px dashed mediumorchid;margin:0 auto;padding:10px}.border-putus-mediumpurple {border:2px dashed mediumpurple;margin:0 auto;padding:10px}.border-putus-blueviolet {border:2px dashed blueviolet;margin:0 auto;padding:10px}.border-putus-darkviolet {border:2px dashed darkviolet;margin:0 auto;padding:10px}.border-putus-darkorchid {border:2px dashed darkorchid;margin:0 auto;padding:10px}.border-putus-darkmagenta {border:2px dashed darkmagenta;margin:0 auto;padding:10px}.border-putus-purple {border:2px dashed purple;margin:0 auto;padding:10px}.border-putus-indigo {border:2px dashed indigo;margin:0 auto;padding:10px}.border-putus-pink {border:2px dashed pink;margin:0 auto;padding:10px}.border-putus-lightpink {border:2px dashed lightpink;margin:0 auto;padding:10px}.border-putus-hotpink {border:2px dashed hotpink;margin:0 auto;padding:10px}.border-putus-deeppink {border:2px dashed deeppink;margin:0 auto;padding:10px}.border-putus-palevioletred {border:2px dashed palevioletred;margin:0 auto;padding:10px}.border-putus-mediumvioletred {border:2px dashed mediumvioletred;margin:0 auto;padding:10px}.border-putus-white {border:2px dashed white;margin:0 auto;padding:10px}.border-putus-snow {border:2px dashed snow;margin:0 auto;padding:10px}.border-putus-honeydew {border:2px dashed honeydew;margin:0 auto;padding:10px}.border-putus-mintcream {border:2px dashed mintcream;margin:0 auto;padding:10px}.border-putus-azure {border:2px dashed azure;margin:0 auto;padding:10px}.border-putus-aliceblue {border:2px dashed aliceblue;margin:0 auto;padding:10px}.border-putus-ghostwhite {border:2px dashed ghostwhite;margin:0 auto;padding:10px}.border-putus-whitesmoke {border:2px dashed whitesmoke;margin:0 auto;padding:10px}.border-putus-seashell {border:2px dashed seashell;margin:0 auto;padding:10px}.border-putus-beige {border:2px dashed beige;margin:0 auto;padding:10px}.border-putus-oldlace {border:2px dashed oldlace;margin:0 auto;padding:10px}.border-putus-floralwhite {border:2px dashed floralwhite;margin:0 auto;padding:10px}.border-putus-ivory {border:2px dashed ivory;margin:0 auto;padding:10px}.border-putus-antiquewhite {border:2px dashed antiquewhite;margin:0 auto;padding:10px}.border-putus-linen {border:2px dashed linen;margin:0 auto;padding:10px}.border-putus-lavenderblush {border:2px dashed lavenderblush;margin:0 auto;padding:10px}.border-putus-mistyrose {border:2px dashed mistyrose;margin:0 auto;padding:10px}.border-putus-gainsboro {border:2px dashed gainsboro;margin:0 auto;padding:10px}.border-putus-lightgray {border:2px dashed lightgray;margin:0 auto;padding:10px}.border-putus-silver {border:2px dashed silver;margin:0 auto;padding:10px}.border-putus-darkgray {border:2px dashed darkgray;margin:0 auto;padding:10px}.border-putus-gray {border:2px dashed gray;margin:0 auto;padding:10px}.border-putus-dimgray {border:2px dashed dimgray;margin:0 auto;padding:10px}.border-putus-lightslategray {border:2px dashed lightslategray;margin:0 auto;padding:10px}.border-putus-slategray {border:2px dashed slategray;margin:0 auto;padding:10px}.border-putus-darkslategray {border:2px dashed darkslategray;margin:0 auto;padding:10px}.border-putus-black {border:2px dashed black;margin:0 auto;padding:10px}.border-putus-cornsilk {border:2px dashed cornsilk;margin:0 auto;padding:10px}.border-putus-blanchedalmond {border:2px dashed blanchedalmond;margin:0 auto;padding:10px}.border-putus-bisque {border:2px dashed bisque;margin:0 auto;padding:10px}.border-putus-navajowhite {border:2px dashed navajowhite;margin:0 auto;padding:10px}.border-putus-wheat {border:2px dashed wheat;margin:0 auto;padding:10px}.border-putus-burlywood {border:2px dashed burlywood;margin:0 auto;padding:10px}.border-putus-tan {border:2px dashed tan;margin:0 auto;padding:10px}.border-putus-rosybrown {border:2px dashed rosybrown;margin:0 auto;padding:10px}.border-putus-sandybrown {border:2px dashed sandybrown;margin:0 auto;padding:10px}.border-putus-goldenrod {border:2px dashed goldenrod;margin:0 auto;padding:10px}.border-putus-peru {border:2px dashed peru;margin:0 auto;padding:10px}.border-putus-chocolate {border:2px dashed chocolate;margin:0 auto;padding:10px}.border-putus-saddlebrown {border:2px dashed saddlebrown;margin:0 auto;padding:10px}.border-putus-sienna {border:2px dashed sienna;margin:0 auto;padding:10px}.border-putus-brown {border:2px dashed brown;margin:0 auto;padding:10px}.border-putus-maroon {border:2px dashed maroon}
.lebar{padding:30px  0 30px}
.box-kontak {border-color:#ffffff;border-image:none;border-style:solid;border-width:4px;margin:0 auto;padding:30px;width:60%;background-color:#ececec;}
.post-body-blockquote {border-color:#CC0000;border-image:none;border-style:dashed;border-width:4px;margin:0 auto;padding:20px;width:75%;}
.border-hijau{border:2px solid #23c869;margin:0 auto;padding:10px}
.border-hijautua{border:2px solid #049c2f;margin:0 auto;padding:10px}
.border-hijautoska{border:2px solid #4adc8f;margin:0 auto;padding:10px}
.border-hijaumuda{border:2px solid #62d552;margin:0 auto;padding:10px}
.border-biru{border:2px solid #2167c7;margin:0 auto;padding:10px}
.border-birutua{border:2px solid #29367a;margin:0 auto;padding:10px}
.border-birumuda{border:2px solid #21b6fc;margin:0 auto;padding:10px}
.border-birutoska{border:2px solid #1de1df;margin:0 auto;padding:10px}
.border-ungu{border:2px solid #8e24ba;margin:0 auto;padding:10px}
.border-ungutua{border:2px solid #7c0ab7;margin:0 auto;padding:10px}
.border-ungumuda{border:2px solid #c258cf;margin:0 auto;padding:10px}
.border-kuning{border:2px solid #f8ce26;margin:0 auto;padding:10px}
.border-kuningtua{border:2px solid #edbe03;margin:0 auto;padding:10px}
.border-kuningmuda{border:2px solid #ffd905;margin:0 auto;padding:10px}
.border-krem{border:2px solid #fde0be;margin:0 auto;padding:10px}
.border-kremmuda{border:2px solid #f8ecd5;margin:0 auto;padding:10px}
.border-merah{border:2px solid #e53e2d;margin:0 auto;padding:10px}
.border-merahtua{border:2px solid #c60404;margin:0 auto;padding:10px}
.border-merahmuda{border:2px solid #e53177;margin:0 auto;padding:10px}
.border-orange{border:2px solid darkorange;margin:0 auto;padding:10px}
.border-abuabu{border:1px solid #c9c9c9;margin:0 auto;padding:20px}
.border-abumuda{border:2px solid #c5c6c7;margin:0 auto;padding:10px}
.border-hitam{border:2px solid #333333;margin:0 auto;padding:10px}
.border-hitampekat{border:2px solid #000000;margin:0 auto;padding:10px}
.border-putih{border:2px solid #ffffff;margin:0 auto;padding:10px}
.border-coklat{border:2px solid #7e623f;margin:0 auto;padding:10px}
.border-putus-hijau{border:2px dashed #23c869;margin:0 auto;padding:10px}
.border-putus-hijautua{border:2px dashed #049c2f;margin:0 auto;padding:10px}
.border-putus-hijaumuda{border:2px dashed #62d552;margin:0 auto;padding:10px}
.border-putus-hijautoska{border:2px dashed #4adc8f;margin:0 auto;padding:10px}
.border-putus-biru{border:2px dashed #2167c7;margin:0 auto;padding:10px}
.border-putus-birutua{border:2px dashed #29367a;margin:0 auto;padding:10px}
.border-putus-birumuda{border:2px dashed #21b6fc;margin:0 auto;padding:10px}
.border-putus-birutoska{border:2px dashed #1de1df;margin:0 auto;padding:10px}
.border-putus-ungu{border:2px dashed #8e24ba;margin:0 auto;padding:10px}
.border-putus-ungutua{border:2px dashed #7c0ab7;margin:0 auto;padding:10px}
.border-putus-ungumuda{border:2px dashed #ffd905;margin:0 auto;padding:10px}
.border-putus-kuning{border:2px dashed #f8ce26;margin:0 auto;padding:10px}
.border-putus-kuningtua{border:2px dashed #edbe03;margin:0 auto;padding:10px}
.border-putus-kuningmuda{border:2px dashed #c258cf;margin:0 auto;padding:10px}
.border-putus-krem{border:2px dashed #fde0be;margin:0 auto;padding:10px}
.border-putus-kremmuda{border:2px dashed #f8ecd5;margin:0 auto;padding:10px}
.border-putus-merah{border:2px dashed #e53e2d;margin:0 auto;padding:10px}
.border-putus-merahtua{border:2px dashed #c60404;margin:0 auto;padding:10px}
.border-putus-merahmuda{border:2px dashed #e53177;margin:0 auto;padding:10px}
.border-putus-orange{border:2px dashed darkorange;margin:0 auto;padding:10px}
.border-putus-abuabu{border:2px dashed #7b8691;margin:0 auto;padding:10px}
.border-putus-abumuda{border:2px dashed #c5c6c7;margin:0 auto;padding:10px}
.border-putus-hitam{border:2px dashed #333333;margin:0 auto;padding:10px}
.border-putus-hitampekat{border:2px dashed #000000;margin:0 auto;padding:10px}
.border-putus-putih{border:2px dashed #ffffff;margin:0 auto;padding:10px}
.border-putus-coklat{border:2px dashed #7e623f;margin:0 auto;padding:10px}
.border-titik-hijau{border:2px dotted #23c869;margin:0 auto;padding:10px}
.border-titik-hijautua{border:2px dotted #049c2f;margin:0 auto;padding:10px}
.border-titik-hijaumuda{border:2px dotted #62d552;margin:0 auto;padding:10px}
.border-titik-hijautoska{border:2px dotted #4adc8f;margin:0 auto;padding:10px}
.border-titik-biru{border:2px dotted #2167c7;margin:0 auto;padding:10px}
.border-titik-birutua{border:2px dotted #29367a;margin:0 auto;padding:10px}
.border-titik-birumuda{border:2px dotted #21b6fc;margin:0 auto;padding:10px}
.border-titik-birutoska{border:2px dotted #1de1df;margin:0 auto;padding:10px}
.border-titik-ungu{border:2px dotted #8e24ba;margin:0 auto;padding:10px}
.border-titik-ungutua{border:2px dotted #7c0ab7;margin:0 auto;padding:10px}
.border-titik-ungumuda{border:2px dotted #ffd905;margin:0 auto;padding:10px}
.border-titik-kuning{border:2px dotted #f8ce26;margin:0 auto;padding:10px}
.border-titik-kuningtua{border:2px dotted #edbe03;margin:0 auto;padding:10px}
.border-titik-kuningmuda{border:2px dotted #c258cf;margin:0 auto;padding:10px}
.border-titik-krem{border:2px dotted #fde0be;margin:0 auto;padding:10px}
.border-titik-kremmuda{border:2px dotted #f8ecd5;margin:0 auto;padding:10px}
.border-titik-merah{border:2px dotted #e53e2d;margin:0 auto;padding:10px}
.border-titik-merahtua{border:2px dotted #c60404;margin:0 auto;padding:10px}
.border-titik-merahmuda{border:2px dotted #e53177;margin:0 auto;padding:10px}
.border-titik-orange{border:2px dotted darkorange;margin:0 auto;padding:10px}
.border-titik-abuabu{border:2px dotted #7b8691;margin:0 auto;padding:10px}
.border-titik-abumuda{border:2px dotted #c5c6c7;margin:0 auto;padding:10px}
.border-titik-hitam{border:2px dotted #333333;margin:0 auto;padding:10px}
.border-titik-hitampekat{border:2px dotted #000000;margin:0 auto;padding:10px}
.border-titik-putih{border:2px dotted #ffffff;margin:0 auto;padding:10px}
.border-titik-coklat{border:2px dotted #7e623f;margin:0 auto;padding:10px}
.border-tebal{border-width:4px}
.lebar80{max-width:80%}.lebar70{max-width:70%}.lebar85{max-width:85%}.lebar75{max-width:75%}.lebar90{max-width:90%}
.melengkung{border-radius:10px;-moz-border-radius:10px;-webkit-border-radius:10px}
.melengkung1{border-radius:4px;-moz-border-radius:6px;-webkit-border-radius:6px}
.melengkung2{border-radius:8px;-moz-border-radius:16px;-webkit-border-radius:16px}
.melengkung3{border-radius:12px;-moz-border-radius:20px;-webkit-border-radius:20px}
.melengkung4{border-radius:16px;-moz-border-radius:24px;-webkit-border-radius:24px}
.melengkung5{border-radius:20px;-moz-border-radius:28px;-webkit-border-radius:28px}
.melengkung6{border-radius:30px;-moz-border-radius:32px;-webkit-border-radius:32px}
.melengkung7{border-radius:30px;-moz-border-radius:36px;-webkit-border-radius:36px}
.melengkung8{border-radius:30px;-moz-border-radius:40px;-webkit-border-radius:40px}
.box1{border-radius: 40% 0px 40% 0px;}
.box2{border-radius: 0px 40% 0px 40%;}
.box3{border-radius: 40px 20px 60px 90px;}
.box4{border-radius: 20px 100px 20px 100px;}
.box5{border-radius: 100px 20px 100px 20px; }
.box6{border-radius: 0px 50% 0px 50%;}
.box7{border-radius: 50% 0px 50% 0px;}
.box8{border-radius: 0px 60px 0px 60px;}
.box9{border-radius: 60px 0px 60px 0px;}
.box10{border-radius: 100px 10px 100px 10px;}
.box11{border-radius: 10px 100px 10px 100px;}
.box12{border-radius: 40px 10px;}
.box13{border-radius: 10px 40px;}
.box14{border-radius: 10px 10px 50% 50%;}
.box15{border-radius: 10px 10px 100px 100px;}
.box16{border-radius: 100px 100px 0px 100px;}
.box17{border-radius: 100px 100px 100px 0px}
.box18{border-radius: 50% 50% 0px 50%}
.box19{border-radius: 50% 50%  50% 0px}
.box20{border-radius: 0px 60px  60px 60px}
.box21{border-radius: 60px 0px 60px 60px}
.bayangan-hitam{box-shadow:0 0 20px 0 #acacac inset;}.bayangan-merah{box-shadow:0 0 20px 0 #fcb3b3 inset;}.bayangan-kuning{box-shadow:0 0 20px 0 #fee994 inset;}.bayangan-biru{box-shadow:0 0 20px 0 #95dbfc inset;}.bayangan-hijau{box-shadow:0 0 20px 0 #9efe91 inset;}.bayangan-ungu{box-shadow:0 0 20px 0 #d27dfe inset;}
.icon-bulat-hijau{border:2px solid #23c869;color:#23c869;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-hijautua{border:2px solid #049c2f;color:#049c2f;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-hijaumuda{border:2px solid #62d552;color:#62d552;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-hijautoska{border:2px solid #4adc8f;color:#4adc8f;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-biru{border:2px solid #2167c7;color:#2167c7;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-birutua{border:2px solid #29367a;color:#29367a;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-birumuda{border:2px solid #21b6fc;color:#21b6fc;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-birutoska{border:2px solid #1de1df;color:#1de1df;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-ungu{border:2px solid #8e24ba;color:#8e24ba;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-ungutua{border:2px solid #7c0ab7;color:#7c0ab7;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-ungumuda{border:2px solid #c258cf;color:#c258cf;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-kuning{border:2px solid #f8ce26;color:#f8ce26;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-kuningtua{border:2px solid #edbe03;color:#edbe03;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-kuningmuda{border:2px solid #c258cf;color:#c258cf;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-krem{border:2px solid #fde0be;color:#fde0be;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-kremmuda{border:2px solid #f8ecd5;color:#f8ecd5;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-merah{border:2px solid #e53e2d;color:#e53e2d;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-merahtua{border:2px solid #c60404;color:#c60404;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-merahmuda{border:2px solid #e53177;color:#e53177;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-orange{border:2px solid darkorange;color:darkorange;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-abuabu{border:2px solid #7b8691;color:#7b8691;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-abumuda{border:2px solid #c5c6c7;color:#c5c6c7;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-hitam{border:2px solid #333333;color:#333333;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-hitam:hover{border:2px solid #fff;color:#fff;}
.icon-bulat-hitampekat{border:2px solid #000000;color:#000000;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-hitampekat:hover{border:2px solid #fff;color:#fff;}
.icon-bulat-putih{border:2px solid #ffffff;color:#ffffff;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-bulat-coklat{border:2px solid #7e623f;color:#7e623f;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:50%;}
.icon-rounded-hijau{border:2px solid #23c869;color:#23c869;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-hijautua{border:2px solid #049c2f;color:#049c2f;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-hijaumuda{border:2px solid #62d552;color:#62d552;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-hijautoska{border:2px solid #4adc8f;color:#4adc8f;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-biru{border:2px solid #2167c7;color:#2167c7;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-birutua{border:2px solid #29367a;color:#29367a;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-birumuda{border:2px solid #21b6fc;color:#21b6fc;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-birutoska{border:2px solid #1de1df;color:#1de1df;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-ungu{border:2px solid #8e24ba;color:#8e24ba;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-ungutua{border:2px solid #7c0ab7;color:#7c0ab7;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-ungumuda{border:2px solid #c258cf;color:#c258cf;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-kuning{border:2px solid #f8ce26;color:#f8ce26;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-kuningtua{border:2px solid #edbe03;color:#edbe03;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-kuningmuda{border:2px solid #c258cf;color:#c258cf;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-krem{border:2px solid #fde0be;color:#fde0be;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-kremmuda{border:2px solid #f8ecd5;color:#f8ecd5;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-merah{border:2px solid #e53e2d;color:#e53e2d;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-merahtua{border:2px solid #c60404;color:#c60404;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-merahmuda{border:2px solid #e53177;color:#e53177;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-orange{border:2px solid darkorange;color:darkorange;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-abuabu{border:2px solid #7b8691;color:#7b8691;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-abumuda{border:2px solid #c5c6c7;color:#c5c6c7;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-hitam{border:2px solid #333333;color:#333333;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-hitampekat{border:2px solid #000000;color:#000000;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-putih{border:2px solid #ffffff;color:#ffffff;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-rounded-coklat{border:2px solid #7e623f;color:#7e623f;width:100px;height:100px;font-size:60px;text-align:center;line-height:1.6em;border-radius:10px}
.icon-kecil{width:50px;height:50px;font-size:30px;text-align:center;line-height:1.55em;}
.icon-btn{width:35px;height:35px;font-size:20px;text-align:center;line-height:1.55em;}
.pattern1{background: url("../../3.bp.blogspot.com/-DDUInT9NuYk/W3EKXr9aPwI/AAAAAAAAA50/3ieijdvJDj0K0H9-of1s2XrazQTLKpuwACLcBGAs/s1600/pattern1.png")}
.pattern2{background: url("../../2.bp.blogspot.com/-Q5GfiRp8ZO0/W3E4nRerD7I/AAAAAAAAA6o/JU7WhcpIYPwp4pwE98WABwdHCi-gr51UwCLcBGAs/s1600/pattern2.png")}
.pattern3{background: url("../../2.bp.blogspot.com/-dkIet3tRw8s/W3HKyTOv1YI/AAAAAAAAA60/-e9yAt-ffdcQe20gHUWAK7AoxQQ7VR98QCLcBGAs/s1600/bg-doodle.png")}
.latar-hijau{background:#23c869;color:#ffffff}.latar-hijautua{background:#049c2f;color:#ffffff}.latar-hijaumuda{background:#9ec502;color:#ffffff}.latar-birudongker{background:#1b4661;}.latar-biru{background:#2167c7;color:#ffffff}.latar-birutua{background:#29367a;color:#ffffff}.latar-birumuda{background:#21b6fc;color:#ffffff}.latar-birutoska{background:#1de1df;color:#333333}.latar-hijautoska{background:#4adc8f;color:#ffffff}.latar-ungu{background:#8e24ba;color:#ffffff}.latar-ungutua{background:#7c0ab7;color:#ffffff}.latar-ungumuda{background:#c258cf;color:#ffffff}.latar-kuning{background:#f8ce26;color:#333333}.latar-kuningtua{background:#edbe03;color:#333333}.latar-kuningmuda{background:#ffd905;color:#333333}.latar-krem{background:#fde0be;color:#333333}.latar-kremmuda{background:#f8ecd5;color:#333333}.latar-merah{background:#e53e2d;color:#ffffff}.latar-merahtua{background:#c60404;color:#ffffff}.latar-merahmuda{background:#e53177;color:#ffffff}.latar-orange{background:darkorange;color:#ffffff}.latar-abuabu{background:#7b8691;color:#ffffff}.latar-abumuda{background:#c5c6c7;color:#ffffff}.latar-putih{background:#ffffff;color:#333333}.latar-hitam{background:#333333;color:#ffffff}.latar-coklat{background:#7e623f;color:#ffffff}.latar-hitampekat{background:#000000;color:#ffffff}
.bg-merah{background:#fec7c7;}.bg-hijau{background:#c7fecb;}.bg-biru{background:#F0FFFF;}.bg-kuning{background:#fef9c7;}.bg-ungu{background:#efc7fe;}.bg-abuabu{background:#f5f5f5;}
.tipis{background:#333333;opacity:0.5}
.transparan:hover{background-opacity:0.5}
.post-body,.widget-content{ font-size:20px;line-height:1.5em}
.xxx-besar { font-size:65px;line-height:1em}
.xx-besar { font-size:60px;line-height:1.2em}
.x-besar { font-size:45px;line-height:1.2em}
.besar { font-size:32px;line-height:1.3em;}
.sedang { font-size:26px}
.normal { font-size:20px}
.kecil { font-size:16px;line-height:1.6em}
.x-kecil { font-size:14px;line-height:1.5em}
.center,.tengah,.headline{text-align:center}
.teks-kanan,.right{text-align:right;}
.teks-kiri,.left{text-align:left}
.miring,.italic{font-style:italic}
.tebal,.bold,.strong{font-weight:bold}
.garisbawah,.underline{text-decoration: underline;}
.kanan{float:right;}
.kiri{float:left;}
.headerfixed{width:100%; z-index:1000; position:fixed;height:0px;}
.footerfixed{line-height:0px;position:fixed;bottom:0px;width:100%;}
.mainmenu{display:inline-flex;cursor:pointer;font-size:16px;font-weight:normal;box-shadow:0 1px 2px rgba(0,0,0,.2);color:#FFF!important;border:2px solid #FFF!important;background-color:#0dac14!important;background:0;margin:5px 0;padding:8px 10px;text-shadow:none!important;transition:all 0s!important} .mainmenu:hover{background-color:#f78d1d!important;background:0}.mainmenu:active{position:relative;top:1px}
.mobilemenu {text-align:left;font-size: 20px;border: 0; cursor: pointer; padding:15px;margin-top:0px;min-width:700px}.mobilemenu:hover {background-color: #333333; }
.dropdown { display: inline-block;}.dropdown-child {display: none; font-size: 20px; min-width: 700px;}.dropdown-child a {color: white; padding: 10px; text-decoration: none; display: block;}.dropdown:hover .dropdown-child { display: block;}
.zoom-in{border-radius: 2%;-webkit-transition: all 1s ease;-moz-transition: all 1s ease;-o-transition: all 1s ease;-ms-transition: all 1s ease;transition: all 1s ease;}.zoom-in:hover{-webkit-transform: scale(1.2, 1.2);-moz-transform: scale(1.2, 1.2);-ms-transform: scale(1.2, 1.2);-o-transform: scale(1.2, 1.2);transform: scale(1.2, 1.2);}
.bounce-out{transition-duration:.5s}.bounce-out:active,.bounce-out:focus,.bounce-out:hover{transform:scale(0.9);transition-timing-function:cubic-bezier(0.47,2.02,.31,-.36)}
.bounce-in{transition-duration:.5s}.bounce-in:active,.bounce-in:focus,.bounce-in:hover{transform:scale(1.1);transition-timing-function:cubic-bezier(0.47,2.02,.31,-.36)}
.berputar{-webkit-transition:all .2s ease-out;transition:all .2s ease-out}.berputar:hover {-webkit-transform:scale(1.3);transform:rotate(360deg);-webkit-transition:all .5s ease-out;transition:all .5s ease-out}
.footer-list{line-height:2em;padding-top:10px}
.garis-orange {border-bottom: 1px solid darkorange;padding-bottom:10px;margin-top:10px}
.garis-biru {border-bottom: 1px solid #61A8DC;padding-bottom:10px;margin-top:10px}
.garis-hijau {border-bottom: 1px solid #8EBD40;padding-bottom:10px;margin-top:10px}
.garis-ungu {border-bottom: 1px solid #988CC3;padding-bottom:10px;margin-top:10px}
.garis-kuning {border-bottom: 1px solid #fcd210;padding-bottom:10px;margin-top:10px}
.garis-merah {border-bottom: 1px solid #fc4a41;padding-bottom:10px;margin-top:10px}
.garis-coklat{border-bottom: 1px solid #7e623f;padding-bottom:10px;margin-top:10px}
.garis-putih {border-bottom: 1px solid #ffffff;padding-bottom:10px;margin-top:10px}
.garis-krem {border-bottom: 1px solid #fdd0aa;padding-bottom:10px;margin-top:10px}
.garis-hitam {border-bottom: 1px solid #000000;padding-bottom:10px;margin-top:10px}
.garis-abuabu {border-bottom: 1px solid #ececec;padding-bottom:10px;margin-top:10px}
.garis-box {border-right: 1px solid #ececec;border-left: 1px solid #ececec;}
.list-orange {border-left: 5px solid darkorange;padding-left:10px}
.list-biru {border-left: 5px solid #61A8DC;padding-left:10px}
.list-hijau {border-left: 5px solid #8EBD40;padding-left:10px}
.list-ungu {border-left: 5px solid #988CC3;padding-left:10px}
.list-kuning {border-left: 5px solid #fcd210;padding-left:10px}
.list-merah {border-left: 5px solid #fc4a41;padding-left:10px}
.list-hitam {border-left: 5px solid #333333;padding-left:10px}
.list-coklat {border-left: 5px solid #7e623f;padding-left:10px}
.list-krem {border-left: 5px solid #fdd0aa;padding-left:10px}
.list-putih {border-left: 5px solid #ffffff;padding-left:10px}
.sharepost {padding-top:20px}
.sharepost ul{margin-left:-40px}
.sharepost li{width:16.6%;padding:0;list-style:none;}
.sharepost li a{opacity:1;padding:10px 0;color:#fff;display:block;border:solid #fff;border-radius:6px;}
.sharepost{overflow:hidden;text-align:center;margin-bottom:20px;margin-top:20px;}
.sharepost li a:hover{opacity:1;color:#444;border:solaid #fff;}
.sharepost li .twitter{background-color:#55acee;}
.sharepost li .facebook{background-color:#3b5998;}
.sharepost li .telegram{background-color:#33ccff;}
.sharepost li .pinterest{background-color:#cc2127;}
.sharepost li .linkedin{background-color:#0976b4;}
.sharepost li .whatsapp{background-color:green;}
.sharepost li .twitter:hover,.sharepost li .facebook:hover,.sharepost li .telegram:hover,
.sharepost li .pinterest:hover,.sharepost li .linkedin:hover,.sharepost li .whatsapp:hover{background-color:#444;color:#fff;}
.sharepost li{float:left;margin-right:0}
.sharepost li:last-child{margin-right:0}
.sharepost li .fa:before{margin-right:5px}
.btn {font-size:17px;border: none;color: white;margin:3px;padding: 6px 20px;cursor: pointer;display:inline-block;  -webkit-transition-duration: 0.4s;transition-duration: 0.4s;} .btn:hover {background-color: #ffffff;color: black;}
.btn1 {font-size:17px;margin:3px;border: none;color: white;padding: 6px 20px;cursor: pointer;display:inline-block;  -webkit-transition-duration: 0.4s; transition-duration: 0.4s;border-radius:6px;} .btn1:hover {background-color: #ffffff;color: black;}
.btn2 {font-size:17px;margin:3px;border: none;color: white;padding: 6px 20px;cursor: pointer;display:inline-block;  -webkit-transition-duration: 0.4s; transition-duration: 0.4s;border-radius:50px;} .btn2:hover {background-color: #ffffff; color: black;}
.btn3 {font-size:17px;margin:3px;padding: 6px 20px;cursor: pointer;display:inline-block; border-radius:6px;background-color: transparent} .btn3:hover {opacity: 0.6;}
.btn-menu {margin:0px;border: none;padding: 0px 10px!important;cursor: pointer;display:inline-block;  -webkit-transition-duration: 0.4s; transition-duration: 0.4s;border-radius:50px;}
.btn-menu:hover {background-color: #ffffff!important; color: red!important;}
.btn-order,.btn-x-besar{padding:14px 26px;text-decoration:none;font-size:26px}
.btn-besar {font-size:20px;padding: 10px 24px;}
.btn-kecil {font-size:14px;padding: 3px 13px;}
.btn-hijau {background-color: #2ecc71;border: 2px solid #2ecc71}
.btn-hijautua {background-color: #27ae60;border: 2px solid #27ae60}
.btn-biru {background-color: #2196F3;border: 2px solid #2196F3}
.btn-birutua {background-color: #29367a;border: 2px solid #2969b9}
.btn-orange {background-color: darkorange;border: 2px solid #ff9800}
.btn-merah {background-color: #f03a28;border: 2px solid #f03a28}
.btn-merahtua {background-color: #c0392b;border: 2px solid #c0392b}
.btn-kuning {background-color: #f4c712;border: 2px solid #f4c712}
.btn-ungu {background-color: #8e44ad;border: 2px solid #8e44ad}
.btn-hitam {background-color: #333333;border: 2px solid #333333}
.btn-abuabu {background-color: #7b8691; color: white; border: 2px solid #7b8691}
.btn-abumuda {background-color: #c3c3c3; color: black; border: 2px solid #c3c3c3}
.btn-merahmuda{background:#e53177;border: 2px solid #e53177}
.btn-hijaumuda{background:#9ec502;border: 2px solid #62d552}
.btn-hijautoska{background:#4adc8f;border: 2px solid #4adc8f}
.btn-birumuda{background:#21b6fc;border: 2px solid #21b6fc}
.btn-birutoska{background:#1de1df;border: 2px solid #1de1df}
.btn-ungumuda{background:#c258cf;border: 2px solid #c258cf}
.btn-ungutua{background:#7c0ab7;border: 2px solid #7c0ab7}
.btn-kuningtua{background:#edbe03;border: 2px solid #edbe03}
.btn-kuningmuda{background:#ffd905;border: 2px solid #ffd905;color: #222222;}
.btn-putih{background:#ffffff;color:black;border: 2px solid #ffffff}
.btn-putih:hover{background:transparent;color:white;border: 2px solid #ffffff}
.btn3-hijau {color: #2ecc71;border: 2px solid #2ecc71}
.btn3-hijautua {color: #27ae60;border: 2px solid #27ae60}
.btn3-biru {color: #2196F3;border: 2px solid #2196F3}
.btn3-birutua {color: #29367a;border: 2px solid #2969b9}
.btn3-orange {color: darkorange;border: 2px solid #ff9800}
.btn3-merah {color: #f03a28;border: 2px solid #f03a28}
.btn3-merahtua {color: #c0392b;border: 2px solid #c0392b}
.btn3-kuning {color: #f4c712;border: 2px solid #f4c712}
.btn3-ungu {color: #8e44ad;border: 2px solid #8e44ad}
.btn3-hitam {color: #333333;border: 2px solid #333333}
.btn3-abuabu {color: #7b8691; border: 2px solid #7b8691}
.btn3-abumuda {color: #c3c3c3; border: 2px solid #c3c3c3}
.btn3-merahmuda{color: #e53177;border: 2px solid #e53177}
.btn3-hijaumuda{color: #9ec502;border: 2px solid #62d552}
.btn3-hijautoska{color: #4adc8f;border: 2px solid #4adc8f}
.btn3-birumuda{color: #21b6fc;border: 2px solid #21b6fc}
.btn3-birutoska{color: #1de1df;border: 2px solid #1de1df}
.btn3-ungutua{color: #7c0ab7;border: 2px solid #7c0ab7}
.btn3-ungumuda{color: #c258cf;border: 2px solid #c258cf}
.btn3-kuningtua{color: #edbe03;border: 2px solid #edbe03}
.btn3-kuningmuda{color: #ffd905;border: 2px solid #ffd905}
.btn3-putih{color: #ffffff;border: 2px solid #ffffff}.btn3-putih:hover{color: #ffffff;border: 2px solid #ffffff;background:#333}
.img-btn{width:40px;height:40px;float:left;background-color:#fff;border-radius:50%;text-align:center;margin-right:10px}
.btn-full{min-width:400px}
.btn-animasi1,.btn-animasi2,.btn-animasi3,.btn-animasi4,.btn-animasi5{font-size:19px;line-height:2em;color:#333;border:2px solid #fff;background-color:#fff;margin:3px;padding: 6px 20px 6px 6px;cursor: pointer;display:inline-block;  -webkit-transition-duration: 0.4s; transition-duration: 0.4s;border-radius:50px;text-align:left}
.btn-animasi1:hover{border:2px solid red;color:#fff;background:red;background:-webkit-linear-gradient(to left,red,#6284ff);background:linear-gradient(to left,red,#6284ff);animation:slidebg 5s linear infinite}
.btn-animasi2:hover{background:#cc5333;color:#fff;background:-webkit-linear-gradient(to left,#23074d,#cc5333);background:linear-gradient(to left,#23074d,#cc5333);animation:slidebg 5s linear infinite;border:2px solid #23074d}
.btn-animasi3:hover{border:2px solid #0d7fc8;color:#fff;background:red;background:-webkit-linear-gradient(to left,#0d7fc8,#01c458);background:linear-gradient(to left,#0d7fc8,#01c458);animation:slidebg 5s linear infinite}
.btn-animasi4:hover{border:2px solid #8e24ba;color:#fff;background:red;background:-webkit-linear-gradient(to left,#8e24ba,#2167c7);background:linear-gradient(to left,#8e24ba,#2167c7);animation:slidebg 5s linear infinite}
.btn-animasi5:hover{border:2px solid darkorange;color:#333;background:red;background:-webkit-linear-gradient(to left,darkorange,yellow);background:linear-gradient(to left,darkorange,yellow);animation:slidebg 5s linear infinite}
.btn-transform-putih:hover {background-color: transparent; color: white;border:2px solid white;border-radius:0;}
.btn-transform-hitam:hover {background-color: transparent; color: black;border:2px solid black;border-radius:0;}
.btn-transform-biru:hover {background-color: transparent; color: blue;border:2px solid blue;border-radius:0;}
.btn-transform-birumuda:hover {background-color: transparent; color: dodgerblue;border:2px solid dodgerblue;border-radius:0;}
.btn-transform-kuning:hover {background-color: transparent; color: yellow;border:2px solid yellow;border-radius:0;}
.btn-transform-hijau:hover {background-color: transparent; color: green;border:2px solid green;border-radius:0;}
.btn-transform-orange:hover {background-color: transparent; color: darkorange;border:2px solid darkorange;border-radius:0;}
.btn-transform-merah:hover {background-color: transparent; color: red;border:2px solid red;border-radius:0;}
.btn-transform-ungu:hover {background-color: transparent; color: blueviolet;border:2px solid blueviolet;border-radius:0;}
@keyframes slidebg{to{background-position:80vw;transform:translate3d(0,0,0)}}
.group:after {content: "";display: table;clear: both;}
.kol2,.kol-2,.kol-12{padding:0;float:left;width:49.8%;transition:all 1s ease 50ms;}
.kol3,.kol-3,.kol-13{padding:0;float:left;width:33.3%;transition:all 1s ease 50ms;}
.kol4,.kol-4,.kol-14{padding:0;float:left;width:24.95%;transition:all 1s ease 50ms;}
.kol5,.kol-5,.kol-15{padding:0;float:left;width:19.95%;transition:all 1s ease 50ms;}
.kol6,.kol-6,.kol-16{padding:0;float:left;width:16.5%;transition:all 1s ease 50ms;}
.kol23,.kol-23,.kol-123{padding-bottom:5px;float:left;width:66.5%;transition:all 1s ease 50ms;}
.lembut{transition:all 1s ease 50ms;}
.box{padding:17px}
.video { position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;}.video iframe,.video object,.video embed { position: absolute; top: 0; left: 0; width: 100%; height:100%;}
.order1-merah{text-align:center;border:5px dashed #e53e2d; width:400px;padding:15px}.order1-merah span{font-size:45px;color:red;font-weight:bold;line-height:1.5em}
.order1-hijau{text-align:center;border:5px dashed #049c2f; width:400px;padding:15px}.order1-hijau span{font-size:45px;color:green;font-weight:bold;line-height:1.5em}
.order1-biru{text-align:center;border:5px dashed #153aa5; width:400px;padding:15px}.order1-biru span{font-size:45px;color:blue;font-weight:bold;line-height:1.5em}
.order1-ungu{text-align:center;border:5px dashed #7c0ab7; width:400px;padding:15px}.order1-ungu span{font-size:45px;color:purple;font-weight:bold;line-height:1.5em}
.order2-merah{text-align:center;border:5px solid #e53e2d; width:400px;padding:15px; box-shadow:0 0 60px 0 #f9a2a2 inset;}.order2-merah span{font-size:45px;color:red;font-weight:bold;line-height:1.5em}
.order2-hijau{text-align:center;border:5px solid #049c2f; width:400px;padding:15px;box-shadow:0 0 60px 0 #9efe91 inset;}.order2-hijau span{font-size:45px;color:green;font-weight:bold;line-height:1.5em}
.order2-biru{text-align:center;border:5px solid #153aa5; width:400px;padding:15px;box-shadow:0 0 60px 0 #95dbfc inset;}.order2-biru span{font-size:45px;color:blue;font-weight:bold;line-height:1.5em}
.order2-ungu{text-align:center;border:5px solid #7c0ab7; width:400px;padding:15px;box-shadow:0 0 60px 0 #d27dfe inset;}.order2-ungu span{font-size:45px;color:purple;font-weight:bold;line-height:1.5em}
.gambar-fitur{width:100px;height:100px;float:left;padding-right:10px;padding-left:10px;padding-top:0;font-size:80px;text-align:center}
.img-fitur{width:120px;height:120px;float:left;padding-right:10px;padding-left:10px;padding-top:20px;font-size:80px;text-align:center}
.ico-fitur{width:60px;height:60px;float:left;padding-right:20px;padding-left:10px}
.ikon-fitur{width:80px;height:80px;float:left;padding:0 10px 0 10px;font-size:60px;text-align:center}
.icon1{overflow:hidden;margin:auto;border-radius:50%;border:4px solid #ffffff}
.teks-fitur {overflow:hidden;}
.ikon-merah{width:120px;height:120px;font-size:70px;text-align:center;color:red;border-radius:50%;border:2px solid red;line-height:1.7em;}
.ikon-hijau{width:120px;height:120px;font-size:70px;text-align:center;color:green;border-radius:50%;border:2px solid green;line-height:1.7em;}
.icon-samping{float:left;margin-right:20px;}
.renggang{padding-top:120px;padding-bottom:100px;}
.list{font-size:23px;line-height:1.5em}
.check1 ul{list-style-image: url('../../2.bp.blogspot.com/-g1wAbnzLvKo/WhWhEQfqUuI/AAAAAAAAAIM/AP3zVJh4w4MzdZKaqIXzxrvv2o0wy_KbACLcBGAs/s1600/check1.png');}
.check2 ul{list-style-image: url('../../4.bp.blogspot.com/-kHszTG1DaOc/WhWhEaH36gI/AAAAAAAAAII/M-0N2JwxNqQipS7nvite41U5EEWnwuugwCLcBGAs/s1600/check2.png');}
.check3 ul{list-style-image: url('../../1.bp.blogspot.com/-5OKaulX2Prs/WhWhFGSDZTI/AAAAAAAAAIQ/g_uiKdsob0IGcluk6BxrPpya_tCf5nwwQCLcBGAs/s1600/check3.png');}
.check4 ul{list-style-image: url('../../4.bp.blogspot.com/-VSifouyukbM/WhWhFYEaLOI/AAAAAAAAAIU/uOanTM_dPlsm9e9tVJexUaeDskNqKj3fQCLcBGAs/s1600/check4.png');}
.check5 ul{list-style-image: url('../../2.bp.blogspot.com/-RSTWTG2yqeQ/WhWhGQwsuMI/AAAAAAAAAIc/0JR_KKwSAUIG-LZDpGVA_m159UHIsYlVACLcBGAs/s1600/check5.png');}
.check6 ul{list-style-image: url('../../1.bp.blogspot.com/-DRKbyplPATw/WhWhGC3oySI/AAAAAAAAAIY/UXkz_vL68qo5V-udp9kT898CPIJJVW9_wCLcBGAs/s1600/check6.png');}
.check7 ul{list-style-image: url('../../4.bp.blogspot.com/-h4LSsq1E8tE/WhWhHXyHDkI/AAAAAAAAAIg/XxYK04zcVt8NnLP_0XOzEbnpxf4AoXioACLcBGAs/s1600/check7.png');}
.check8 ul{list-style-image: url('../../4.bp.blogspot.com/-gfdqUTcRblo/WhWhVfip-QI/AAAAAAAAAI0/eYby3NZQnEMc1k30YD5oihUFQJQfQ9LVgCLcBGAs/s1600/check8.png');}
.check9 ul{list-style-image: url('../../3.bp.blogspot.com/-RR7yUEGbCZU/WhWhLyfQCJI/AAAAAAAAAIk/uHsO4jrdsh8yr-sRwM2f4zkNQWDkU97HQCLcBGAs/s1600/check.png');}
.cross1 ul{list-style-image: url('../../1.bp.blogspot.com/-XV08gOB2vLA/WhWhNSG3OxI/AAAAAAAAAIo/rNpW0TGMcz0-MmT8Ad1cNRRhsCHa-_ONQCLcBGAs/s1600/x1.png');}
.cross2 ul{list-style-image: url('../../3.bp.blogspot.com/-HMGQ5eSTm8c/WhWhNcTZdII/AAAAAAAAAIw/CR5AY0xaNp0TSBIcennx9T4vLGN730dQgCLcBGAs/s1600/x2.png');}
.cross3 ul{list-style-image: url('../../3.bp.blogspot.com/-4fTJx0dJqbo/WhWhNWaaLuI/AAAAAAAAAIs/rTG01L6PeKUUiN9JXahewyBdgMByib58gCLcBGAs/s1600/x3.png');}
.logo{width:180px;height:auto;overflow:hidden;margin:auto}
.foto3{overflow:hidden;margin:auto;border-radius:20px;border:5px solid #dddddd}
.bulat{overflow:hidden;margin:auto;border-radius:50%;border:4px solid #dddddd}
.foto2{width:200px;height:200px;overflow:hidden;margin:auto;border-radius:200px;border:3px solid #e9e9e9}
.foto-logo{width:150px;height:150px;overflow:hidden;margin:auto;border-radius:200px;}
.foto1{width:100px;height:100px;overflow:hidden;margin:auto;border-radius:100px;border:3px solid #e9e9e9}
.avatar{width:170px;height:170px;overflow:hidden;margin:auto;border-radius:170px;border:3px solid #e9e9e9}
.harga1 {line-height:2em;width:97%;box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)} .harga1 .judul{font-size:28px;font-weight:bolder;padding:15px} .harga1 .btn{padding:15px}.harga1 .harga span{font-size:40px;}.harga1 ul{list-style:none;padding:0}
.harga2 {line-height:2em;width:500px;box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)} .harga2 .judul{font-size:28px;font-weight:bolder;padding:15px} .harga2 .btn{padding:15px}.harga2 .harga span{font-size:40px;}.harga2 ul{list-style:none;padding:0}
.testimonial{margin-bottom: 10px;}.testimonial-section {width: 100%;height: auto;padding: 15px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;position: relative;border: 1px solid #fff;}.testimonial-section:after {top: 100%;left: 50px;border: solid transparent;content: " ";position: absolute;border-top-color: #fff;border-width: 15px;margin-left: -15px;}.testimonial-desc {margin-top: 20px;text-align:left;padding-left: 15px;}.testimonial-desc img {border: 1px solid #f5f5f5;border-radius: 150px;height: 70px;padding: 3px;width: 70px;display:inline-block;vertical-align: top;}.testimonial-writer{display: inline-block;vertical-align: top;padding-left: 10px;}.testimonial-writer-name{font-weight: bold;}.testimonial-writer-designation{font-size: 85%;}.testimonial-writer-company{font-size: 85%;}
.testimonial.testimonial-hijau{}.testimonial.testimonial-hijau .testimonial-section{border-color: #5CB85C;color: #ffffff;background-color: #5cb85c;}.testimonial.testimonial-hijau .testimonial-section:after{border-top-color: #5CB85C;}.testimonial.testimonial-hijau .testimonial-desc{}.testimonial.testimonial-hijau .testimonial-desc img{border-color: #5CB85C;}.testimonial.testimonial-hijau .testimonial-writer-name{color: #5CB85C;}.testimonial.testimonial-merah{}.testimonial.testimonial-kuning .testimonial-section{border-color: #F0AD4E;color: #ffffff;background-color: #F0AD4E;}.testimonial.testimonial-kuning .testimonial-section:after{border-top-color: #F0AD4E;}.testimonial.testimonial-kuning .testimonial-desc{}.testimonial.testimonial-kuning .testimonial-desc img{border-color: #F0AD4E;}.testimonial.testimonial-kuning .testimonial-writer-name{color: #F0AD4E;}.testimonial.testimonial-biru{}.testimonial.testimonial-biru .testimonial-section{border-color: #5BC0DE;color: #ffffff;background-color: #5BC0DE;}.testimonial.testimonial-biru .testimonial-section:after{border-top-color: #5BC0DE;}.testimonial.testimonial-biru .testimonial-desc{}.testimonial.testimonial-biru .testimonial-desc img{border-color: #5BC0DE;}.testimonial.testimonial-biru .testimonial-writer-name{color: #5BC0DE;}.testimonial.testimonial-merah{}.testimonial.testimonial-merah .testimonial-section{border-color: #D9534F;color: #ffffff;background-color:#D9534F;}.testimonial.testimonial-merah .testimonial-section:after{border-top-color: #D9534F;}.testimonial.testimonial-merah .testimonial-desc{}.testimonial.testimonial-merah .testimonial-desc img{border-color: #D9534F;}.testimonial.testimonial-merah .testimonial-writer-name{color: #D9534F;}
.subscribe-form-wrapper input {border: 0;border-radius: 20px;margin:10px;}
.subscribe-form-wrapper input,.subscribe-form-wrapper button {-webkit-box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.3);-moz-box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.3);  box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.3);}
.subscribe-form-wrapper label{position:absolute;left:-9999px;text-align:center;}
.subscribe-form-wrapper input,.subscribe-form-wrapper textarea{font:inherit;resize:none;height: 40px;padding-left: 20px;width: 234px !important;}
.nama{margin-bottom:-30px;}
.peta{overflow:hidden;padding-bottom:56.25%;position:relative;height:0;}.peta iframe{left:0;top:0;height:100%;width:100%;position:absolute;}
.img-top{margin-top:-110px;}.tinggi{padding:100px  0 0px}.top{margin-top:-320px;}.top2,.top3{margin-top:-120px;}.lebar-bawah{padding-bottom:250px}.lebar-bawah2{padding-bottom:100px}
.text-shadow{text-shadow:#636363 2px 2px 2px}.teks-shadow{text-shadow:#000 1px 1px 1px}.shadow{filter:drop-shadow(0 20px 10px rgba(0,0,0,.4))}.shadow-hitam{box-shadow:0px 0px 10px 0px #6b6b6b}.shadow-biru{box-shadow:0px 0px 10px 0px #95dbfc}.shadow-merah{box-shadow:0px 0px 10px 0px #fcb3b3}.shadow-hijau{box-shadow:0px 0px 10px 0px #9efe91}.shadow-kuning{box-shadow:0px 0px 10px 0px #fee994}.shadow-ungu{box-shadow:0px 0px 10px 0px #d27dfe}.shadow-abuabu{box-shadow:0px 0px 10px 0px #c5c6c7}.shadow-putih{box-shadow:0px 0px 10px 0px #ffffff}
.shadow,.shadow-hitam, .shadow-biru, .shadow-merah, .shadow-kuning, .shadow-ungu, .shadow-hijau,.shadow-hitam, .sorot-shadow-biru, .sorot-shadow-merah, .sorot-shadow-kuning, .sorot-shadow-ungu, .sorot-shadow-hijau,.sorot-shadow-hitam,.sorot-shadow-abuabu,.shadow-putih,.sorot-shadow-putih{transition:all 1s ease 50ms;}
.sorot-shadow-hitam:hover{box-shadow:0px 0px 10px 0px #333}.sorot-shadow-biru:hover{box-shadow:0px 0px 10px 0px #95dbfc}.sorot-shadow-merah:hover{box-shadow:0px 0px 10px 0px #fcb3b3}.sorot-shadow-hijau:hover{box-shadow:0px 0px 10px 0px #9efe91}.sorot-shadow-kuning:hover{box-shadow:0px 0px 10px 0px #fee994}.sorot-shadow-ungu:hover{box-shadow:0px 0px 10px 0px #d27dfe}.sorot-shadow-abuabu:hover{box-shadow:0px 0px 10px 0px #c5c6c7}.sorot-shadow-putih:hover{box-shadow:0px 0px 5px 0px #ffffff}
.box-shadow-hijau{box-shadow:10px 10px 1px #23c869;}.box-shadow-hijautua{box-shadow:10px 10px 1px #049c2f;}.box-shadow-hijaumuda{box-shadow:10px 10px 1px #9ec502;}.box-shadow-hijautoska{box-shadow:10px 10px 1px #4adc8f;}.box-shadow-biru{box-shadow:10px 10px 1px #2167c7;}.box-shadow-birutua{box-shadow:10px 10px 1px #29367a;}.box-shadow-birumuda{box-shadow:10px 10px 1px #21b6fc;}.box-shadow-birutoska{box-shadow:10px 10px 1px #1de1df;}.box-shadow-ungu{box-shadow:10px 10px 1px #8e24ba;}.box-shadow-ungutua{box-shadow:10px 10px 1px #7c0ab7;}.box-shadow-ungumuda{box-shadow:10px 10px 1px #ffd905;}.box-shadow-kuning{box-shadow:10px 10px 1px #f8ce26;}.box-shadow-kuningtua{box-shadow:10px 10px 1px #edbe03;}.box-shadow-kuningmuda{box-shadow:10px 10px 1px #c258cf;}.box-shadow-krem{box-shadow:10px 10px 1px #fde0be;}.box-shadow-kremmuda{box-shadow:10px 10px 1px #f8ecd5;}.box-shadow-merah{box-shadow:10px 10px 1px #e53e2d;}.box-shadow-merahtua{box-shadow:10px 10px 1px #c60404;}.box-shadow-merahmuda{box-shadow:10px 10px 1px #e53177;}.box-shadow-orange{box-shadow:10px 10px 1px darkorange;}.box-shadow-abuabu{box-shadow:10px 10px 1px #d9d9d9;}.box-shadow-abumuda{box-shadow:10px 10px 1px #c5c6c7;}.box-shadow-hitam{box-shadow:10px 10px 1px #333333;}.box-shadow-hitampekat{box-shadow:10px 10px 1px #000000;}.box-shadow-putih{box-shadow:10px 10px 1px #ffffff;}.box-shadow-coklat{box-shadow:10px 10px 1px #7e623f;}
.sorot-box-shadow-hijau:hover{box-shadow:10px 10px 1px #23c869;}.sorot-box-shadow-hijautua:hover{box-shadow:10px 10px 1px #049c2f;}.sorot-box-shadow-hijaumuda:hover{box-shadow:10px 10px 1px #9ec502;}.sorot-box-shadow-hijautoska:hover{box-shadow:10px 10px 1px #4adc8f;}.sorot-box-shadow-biru:hover{box-shadow:10px 10px 1px #2167c7;}.sorot-box-shadow-birutua:hover{box-shadow:10px 10px 1px #29367a;}.sorot-box-shadow-birumuda:hover{box-shadow:10px 10px 1px #21b6fc;}.sorot-box-shadow-birutoska:hover{box-shadow:10px 10px 1px #1de1df;}.sorot-box-shadow-ungu:hover{box-shadow:10px 10px 1px #8e24ba;}.sorot-box-shadow-ungutua:hover{box-shadow:10px 10px 1px #7c0ab7;}.sorot-box-shadow-ungumuda:hover{box-shadow:10px 10px 1px #ffd905;}.sorot-box-shadow-kuning:hover{box-shadow:10px 10px 1px #f8ce26;}.sorot-box-shadow-kuningtua:hover{box-shadow:10px 10px 1px #edbe03;}.sorot-box-shadow-kuningmuda:hover{box-shadow:10px 10px 1px #c258cf;}.sorot-box-shadow-krem:hover{box-shadow:10px 10px 1px #fde0be;}.sorot-box-shadow-kremmuda:hover{box-shadow:10px 10px 1px #f8ecd5;}.sorot-box-shadow-merah:hover{box-shadow:10px 10px 1px #e53e2d;}.sorot-box-shadow-merahtua:hover{box-shadow:10px 10px 1px #c60404;}.sorot-box-shadow-merahmuda:hover{box-shadow:10px 10px 1px #e53177;}.sorot-box-shadow-orange:hover{box-shadow:10px 10px 1px darkorange;}.sorot-box-shadow-abuabu:hover{box-shadow:10px 10px 1px #d9d9d9;}.sorot-box-shadow-abumuda:hover{box-shadow:10px 10px 1px #c5c6c7;}.sorot-box-shadow-hitam:hover{box-shadow:10px 10px 1px #333333;}.sorot-box-shadow-hitampekat:hover{box-shadow:10px 10px 1px #000000;}.sorot-box-shadow-putih:hover{box-shadow:10px 10px 1px #ffffff;}.sorot-box-shadow-coklat:hover{box-shadow:10px 10px 1px #7e623f;}
.box-shadow-hijau2{box-shadow:10px -15px 1px #23c869;}.box-shadow-hijautua2{box-shadow:10px -15px 1px #049c2f;}.box-shadow-hijaumuda2{box-shadow:10px -15px 1px #9ec502;}.box-shadow-hijautoska2{box-shadow:10px -15px 1px #4adc8f;}.box-shadow-biru2{box-shadow:10px -15px 1px #2167c7;}.box-shadow-birutua2{box-shadow:10px -15px 1px #29367a;}.box-shadow-birumuda2{box-shadow:10px -15px 1px #21b6fc;}.box-shadow-birutoska2{box-shadow:10px -15px 1px #1de1df;}.box-shadow-ungu2{box-shadow:10px -15px 1px #8e24ba;}.box-shadow-ungutua2{box-shadow:10px -15px 1px #7c0ab7;}.box-shadow-ungumuda2{box-shadow:10px -15px 1px #ffd905;}.box-shadow-kuning2{box-shadow:10px -15px 1px #f8ce26;}.box-shadow-kuningtua2{box-shadow:10px -15px 1px #edbe03;}.box-shadow-kuningmuda2{box-shadow:10px -15px 1px #c258cf;}.box-shadow-krem2{box-shadow:10px -15px 1px #fde0be;}.box-shadow-kremmuda2{box-shadow:10px -15px 1px #f8ecd5;}.box-shadow-merah2{box-shadow:10px -15px 1px #e53e2d;}.box-shadow-merahtua2{box-shadow:10px -15px 1px #c60404;}.box-shadow-merahmuda2{box-shadow:10px -15px 1px #e53177;}.box-shadow-orange2{box-shadow:10px -15px 1px darkorange;}.box-shadow-abuabu2{box-shadow:10px -15px 1px #7b8691;}.box-shadow-abumuda2{box-shadow:10px -15px 1px #c5c6c7;}.box-shadow-hitam2{box-shadow:10px -15px 1px #333333;}.box-shadow-hitampekat2{box-shadow:10px -15px 1px #000000;}.box-shadow-putih2{box-shadow:10px -15px 1px #ffffff;}.box-shadow-coklat2{box-shadow:10px -15px 1px #7e623f;}
.sorot-box-shadow-hijau2:hover{box-shadow:10px -15px 1px #23c869;}.sorot-box-shadow-hijautua2:hover{box-shadow:10px -15px 1px #049c2f;}.sorot-box-shadow-hijaumuda2:hover{box-shadow:10px -15px 1px #9ec502;}.sorot-box-shadow-hijautoska2:hover{box-shadow:10px -15px 1px #4adc8f;}.sorot-box-shadow-biru2:hover{box-shadow:10px -15px 1px #2167c7;}.sorot-box-shadow-birutua2:hover{box-shadow:10px -15px 1px #29367a;}.sorot-box-shadow-birumuda2:hover{box-shadow:10px -15px 1px #21b6fc;}.sorot-box-shadow-birutoska2:hover{box-shadow:10px -15px 1px #1de1df;}.sorot-box-shadow-ungu2:hover{box-shadow:10px -15px 1px #8e24ba;}.sorot-box-shadow-ungutua2:hover{box-shadow:10px -15px 1px #7c0ab7;}.sorot-box-shadow-ungumuda2:hover{box-shadow:10px -15px 1px #ffd905;}.sorot-box-shadow-kuning2:hover{box-shadow:10px -15px 1px #f8ce26;}.sorot-box-shadow-kuningtua2:hover{box-shadow:10px -15px 1px #edbe03;}.sorot-box-shadow-kuningmuda2:hover{box-shadow:10px -15px 1px #c258cf;}.sorot-box-shadow-krem2:hover{box-shadow:10px -15px 1px #fde0be;}.sorot-box-shadow-kremmuda2:hover{box-shadow:10px -15px 1px #f8ecd5;}.sorot-box-shadow-merah2:hover{box-shadow:10px -15px 1px #e53e2d;}.sorot-box-shadow-merahtua2:hover{box-shadow:10px -15px 1px #c60404;}.sorot-box-shadow-merahmuda2:hover{box-shadow:10px -15px 1px #e53177;}.sorot-box-shadow-orange2:hover{box-shadow:10px -15px 1px darkorange;}.sorot-box-shadow-abuabu2:hover{box-shadow:10px -15px 1px #7b8691;}.sorot-box-shadow-abumuda2:hover{box-shadow:10px -15px 1px #c5c6c7;}.sorot-box-shadow-hitam2:hover{box-shadow:10px -15px 1px #333333;}.sorot-box-shadow-hitampekat2:hover{box-shadow:10px -15px 1px #000000;}.sorot-box-shadow-putih2:hover{box-shadow:10px -15px 1px #ffffff;}.sorot-box-shadow-coklat2:hover{box-shadow:10px -15px 1px #7e623f;}
.box-shadow-hijau3{box-shadow:-15px 10px 1px #23c869;}.box-shadow-hijautua3{box-shadow:-15px 10px 1px #049c2f;}.box-shadow-hijaumuda3{box-shadow:-15px 10px 1px #9ec502;}.box-shadow-hijautoska3{box-shadow:-15px 10px 1px #4adc8f;}.box-shadow-biru3{box-shadow:-15px 10px 1px #2167c7;}.box-shadow-birutua3{box-shadow:-15px 10px 1px #29367a;}.box-shadow-birumuda3{box-shadow:-15px 10px 1px #21b6fc;}.box-shadow-birutoska3{box-shadow:-15px 10px 1px #1de1df;}.box-shadow-ungu3{box-shadow:-15px 10px 1px #8e24ba;}.box-shadow-ungutua3{box-shadow:-15px 10px 1px #7c0ab7;}.box-shadow-ungumuda3{box-shadow:-15px 10px 1px #ffd905;}.box-shadow-kuning3{box-shadow:-15px 10px 1px #f8ce26;}.box-shadow-kuningtua3{box-shadow:-15px 10px 1px #edbe03;}.box-shadow-kuningmuda3{box-shadow:-15px 10px 1px #c258cf;}.box-shadow-krem3{box-shadow:-15px 10px 1px #fde0be;}.box-shadow-kremmuda3{box-shadow:-15px 10px 1px #f8ecd5;}.box-shadow-merah3{box-shadow:-15px 10px 1px #e53e2d;}.box-shadow-merahtua3{box-shadow:-15px 10px 1px #c60404;}.box-shadow-merahmuda3{box-shadow:-15px 10px 1px #e53177;}.box-shadow-orange3{box-shadow:-15px 10px 1px darkorange;}.box-shadow-abuabu3{box-shadow:-15px 10px 1px #7b8691;}.box-shadow-abumuda3{box-shadow:-15px 10px 1px #c5c6c7;}.box-shadow-hitam3{box-shadow:-15px 10px 1px #333333;}.box-shadow-hitampekat3{box-shadow:-15px 10px 1px #000000;}.box-shadow-putih3{box-shadow:-15px 10px 1px #ffffff;}.box-shadow-coklat3{box-shadow:-15px 10px 1px #7e623f;}
.sorot-box-shadow-hijau3:hover{box-shadow:-15px 10px 1px #23c869;}.sorot-box-shadow-hijautua3:hover{box-shadow:-15px 10px 1px #049c2f;}.sorot-box-shadow-hijaumuda3:hover{box-shadow:-15px 10px 1px #9ec502;}.sorot-box-shadow-hijautoska3:hover{box-shadow:-15px 10px 1px #4adc8f;}.sorot-box-shadow-biru3:hover{box-shadow:-15px 10px 1px #2167c7;}.sorot-box-shadow-birutua3:hover{box-shadow:-15px 10px 1px #29367a;}.sorot-box-shadow-birumuda3:hover{box-shadow:-15px 10px 1px #21b6fc;}.sorot-box-shadow-birutoska3:hover{box-shadow:-15px 10px 1px #1de1df;}.sorot-box-shadow-ungu3:hover{box-shadow:-15px 10px 1px #8e24ba;}.sorot-box-shadow-ungutua3:hover{box-shadow:-15px 10px 1px #7c0ab7;}.sorot-box-shadow-ungumuda3:hover{box-shadow:-15px 10px 1px #ffd905;}.sorot-box-shadow-kuning3:hover{box-shadow:-15px 10px 1px #f8ce26;}.sorot-box-shadow-kuningtua3:hover{box-shadow:-15px 10px 1px #edbe03;}.sorot-box-shadow-kuningmuda3:hover{box-shadow:-15px 10px 1px #c258cf;}.sorot-box-shadow-krem3:hover{box-shadow:-15px 10px 1px #fde0be;}.sorot-box-shadow-kremmuda3:hover{box-shadow:-15px 10px 1px #f8ecd5;}.sorot-box-shadow-merah3:hover{box-shadow:-15px 10px 1px #e53e2d;}.sorot-box-shadow-merahtua3:hover{box-shadow:-15px 10px 1px #c60404;}.sorot-box-shadow-merahmuda3:hover{box-shadow:-15px 10px 1px #e53177;}.sorot-box-shadow-orange3:hover{box-shadow:-15px 10px 1px darkorange;}.sorot-box-shadow-abuabu3:hover{box-shadow:-15px 10px 1px #7b8691;}.sorot-box-shadow-abumuda3:hover{box-shadow:-15px 10px 1px #c5c6c7;}.sorot-box-shadow-hitam3:hover{box-shadow:-15px 10px 1px #333333;}.sorot-box-shadow-hitampekat3:hover{box-shadow:-15px 10px 1px #000000;}.sorot-box-shadow-putih3:hover{box-shadow:-15px 10px 1px #ffffff;}.sorot-box-shadow-coklat3:hover{box-shadow:-15px 10px 1px #7e623f;}
.box-shadow-hijau4{box-shadow:-15px -10px 1px #23c869;}.box-shadow-hijautua4{box-shadow:-15px -10px 1px #049c2f;}.box-shadow-hijaumuda4{box-shadow:-15px -10px 1px #9ec502;}.box-shadow-hijautoska4{box-shadow:-15px -10px 1px #4adc8f;}.box-shadow-biru4{box-shadow:-15px -10px 1px #2167c7;}.box-shadow-birutua4{box-shadow:-15px -10px 1px #29367a;}.box-shadow-birumuda4{box-shadow:-15px -10px 1px #21b6fc;}.box-shadow-birutoska4{box-shadow:-15px -10px 1px #1de1df;}.box-shadow-ungu4{box-shadow:-15px -10px 1px #8e24ba;}.box-shadow-ungutua4{box-shadow:-15px -10px 1px #7c0ab7;}.box-shadow-ungumuda4{box-shadow:-15px -10px 1px #ffd905;}.box-shadow-kuning4{box-shadow:-15px -10px 1px #f8ce26;}.box-shadow-kuningtua4{box-shadow:-15px -10px 1px #edbe03;}.box-shadow-kuningmuda4{box-shadow:-15px -10px 1px #c258cf;}.box-shadow-krem4{box-shadow:-15px -10px 1px #fde0be;}.box-shadow-kremmuda4{box-shadow:-15px -10px 1px #f8ecd5;}.box-shadow-merah4{box-shadow:-15px -10px 1px #e53e2d;}.box-shadow-merahtua4{box-shadow:-15px -10px 1px #c60404;}.box-shadow-merahmuda4{box-shadow:-15px -10px 1px #e53177;}.box-shadow-orange4{box-shadow:-15px -10px 1px darkorange;}.box-shadow-abuabu4{box-shadow:-15px -10px 1px #7b8691;}.box-shadow-abumuda4{box-shadow:-15px -10px 1px #c5c6c7;}.box-shadow-hitam4{box-shadow:-15px -10px 1px #333333;}.box-shadow-hitampekat4{box-shadow:-15px -10px 1px #000000;}.box-shadow-putih4{box-shadow:-15px -10px 1px #ffffff;}.box-shadow-coklat4{box-shadow:-15px -10px 1px #7e623f;}
.sorot-box-shadow-hijau4:hover{box-shadow:-15px -10px 1px #23c869;}.sorot-box-shadow-hijautua4:hover{box-shadow:-15px -10px 1px #049c2f;}.sorot-box-shadow-hijaumuda4:hover{box-shadow:-15px -10px 1px #9ec502;}.sorot-box-shadow-hijautoska4:hover{box-shadow:-15px -10px 1px #4adc8f;}.sorot-box-shadow-biru4:hover{box-shadow:-15px -10px 1px #2167c7;}.sorot-box-shadow-birutua4:hover{box-shadow:-15px -10px 1px #29367a;}.sorot-box-shadow-birumuda4:hover{box-shadow:-15px -10px 1px #21b6fc;}.sorot-box-shadow-birutoska4:hover{box-shadow:-15px -10px 1px #1de1df;}.sorot-box-shadow-ungu4:hover{box-shadow:-15px -10px 1px #8e24ba;}.sorot-box-shadow-ungutua4:hover{box-shadow:-15px -10px 1px #7c0ab7;}.sorot-box-shadow-ungumuda4:hover{box-shadow:-15px -10px 1px #ffd905;}.sorot-box-shadow-kuning4:hover{box-shadow:-15px -10px 1px #f8ce26;}.sorot-box-shadow-kuningtua4:hover{box-shadow:-15px -10px 1px #edbe03;}.sorot-box-shadow-kuningmuda4:hover{box-shadow:-15px -10px 1px #c258cf;}.sorot-box-shadow-krem4:hover{box-shadow:-15px -10px 1px #fde0be;}.sorot-box-shadow-kremmuda4:hover{box-shadow:-15px -10px 1px #f8ecd5;}.sorot-box-shadow-merah4:hover{box-shadow:-15px -10px 1px #e53e2d;}.sorot-box-shadow-merahtua4:hover{box-shadow:-15px -10px 1px #c60404;}.sorot-box-shadow-merahmuda4:hover{box-shadow:-15px -10px 1px #e53177;}.sorot-box-shadow-orange4:hover{box-shadow:-15px -10px 1px darkorange;}.sorot-box-shadow-abuabu4:hover{box-shadow:-15px -10px 1px #7b8691;}.sorot-box-shadow-abumuda4:hover{box-shadow:-15px -10px 1px #c5c6c7;}.sorot-box-shadow-hitam4:hover{box-shadow:-15px -10px 1px #333333;}.sorot-box-shadow-hitampekat4:hover{box-shadow:-15px -10px 1px #000000;}.sorot-box-shadow-putih4:hover{box-shadow:-15px -10px 1px #ffffff;}.sorot-box-shadow-coklat4:hover{box-shadow:-15px -10px 1px #7e623f;}
.bg-melayang{background: url(" "#) top center;background-attachment: fixed; background-size:cover;}
.bg-gambar{background: url("../../3.bp.blogspot.com/-AkhbNKHgADw/W8HTvY8A3FI/AAAAAAAABjU/bRHz32iiXNkx3MuFBaqklY0X9tjzPkVDACLcBGAs/s1600/bg-theme.jpg") top center repeat;}
.garis-footer{background: url("../../1.bp.blogspot.com/-bLb0J6wnA58/XdphEuBjc3I/AAAAAAAAAEs/BaNMD_33syIzy628lww2g7aVL1iPwyb5ACLcBGAsYHQ/s1600/footer_top_strip.jpg") no-repeat 0 0 transparent;}
.quote-besar{background: url("../../4.bp.blogspot.com/-Mtg25_BKWoU/XdxY89El_gI/AAAAAAAADtU/8elhcfA7LP0AYhI_-YqAakCge-0opGsmACNcBGAsYHQ/s1600/quote.png") no-repeat top center;padding-top:40px}
.quote-kecil{background: url("../../1.bp.blogspot.com/-7cxNuxoAcFo/Xe8wRS8kAsI/AAAAAAAAD3c/r9Ek-dT8ANUIUMOf9xx8ee61DAHraVfiwCNcBGAsYHQ/s1600/quote-kecil.png") no-repeat bottom right;}
.bg-header{background: url(" "#) repeat scroll 0 0 #ffffff;background-size:cover;}
.tekstur1{background: url("../../4.bp.blogspot.com/-YOjPxJyQ4VU/W26sULyJ1II/AAAAAAAAA5M/ojxNAcnGiOE0SmpoiwY5C6ng-PF11FZ2wCLcBGAs/s1600/tekstur-plafon.jpg") repeat scroll 0 0 #ffffff}
.tekstur2{background: url("../../4.bp.blogspot.com/-09DuxXRdxr4/W26sUWL9RpI/AAAAAAAAA5Q/NAIXXGWBzXwsd-VpV3Sl3qfIXv3UZr1hACLcBGAs/s1600/tekstur-putih.jpg") repeat scroll 0 0 #ffffff}
.tekstur3{color:#ffffff;background: url("../../1.bp.blogspot.com/-hS1G_82t3_M/W26sTY7H5LI/AAAAAAAAA5E/PTRMg64w8n8DD_0HEHIChdLMR2DVj4oyACLcBGAs/s1600/tekstur-karpet.jpg") repeat scroll 0 0 #ffffff}
.tekstur4{color:#ffffff;background: url("../../4.bp.blogspot.com/-_4iU17OmITU/W26sTLlq4OI/AAAAAAAAA48/o2yrKOgXamo7fhtNj5CGb7T0113r-v8HQCLcBGAs/s1600/tekstur-abuabu.jpg") repeat scroll 0 0 #ffffff}
.tekstur5{color:#ffffff;background: url("../../1.bp.blogspot.com/-Bx-u_VSbHfY/W26sTPlwKcI/AAAAAAAAA5A/h5ab31leb2kYcR8YT2vclJodNk_54-MFQCLcBGAs/s1600/tekstur-hitam.jpg") repeat scroll 0 0 #ffffff}
.tekstur6{color:#ffffff;background: url("../../1.bp.blogspot.com/-5XswhsK44yE/W26sUEOcNbI/AAAAAAAAA5I/d25aLNjYsDsxH_xljsoLJIaUpiBHQ_GsACLcBGAs/s1600/tekstur-kayu.jpg") repeat scroll 0 0 #ffffff}
.tekstur7{color:#ffffff;background: url("../../3.bp.blogspot.com/-UUpIg1g1g80/W26sVX7J-yI/AAAAAAAAA5U/LuXRlk4v1f0L_t8m4XPKJSDSwKNssaVYACLcBGAs/s1600/tekstur-tembok.jpg") repeat scroll 0 0 #ffffff}
.melayang {background-attachment:fixed}
.bg-gradien-radial,.bg-gradient1 {background:-webkit-radial-gradient(center, circle, rgba(227,199,8,0.9), rgba(232,117,15,0.9));
background:-moz-radial-gradient(center, circle, rgba(227,199,8,0.9), rgba(232,117,15,0.9));
background:-o-radial-gradient(center, circle, rgba(227,199,8,0.9), rgba(232,117,15,0.9)); filter:progid:DXImageTransform.Microsoft.Alpha (opacity=0, finishopacity=100, style=2);height:100%;}
.bg-gradien-radial2,.bg-gradient2 {background:-webkit-radial-gradient(center, circle, rgba(33,182,252,0.9), rgba(41,54,122,0.9));
background:-moz-radial-gradient(center, circle, rgba(33,182,252,0.9), rgba(41,54,122,0.9));
background:-o-radial-gradient(center, circle,  rgba(33,182,252,0.9), rgba(41,54,122,0.9));
filter:progid:DXImageTransform.Microsoft.Alpha (opacity=0, finishopacity=100, style=2);height:100%;}
.bg-gradien-radial3,.bg-gradient3 {background:-webkit-radial-gradient(center, circle, rgba(10,126,253,0.9), rgba(210,10,253,0.9));
background:-moz-radial-gradient(center, circle, rgba(10,126,253,0.9), rgba(210,10,253,0.9));
background:-o-radial-gradient(center, circle,  rgba(10,126,253,0.9), rgba(210,10,253,0.9));
filter:progid:DXImageTransform.Microsoft.Alpha (opacity=0, finishopacity=100, style=2);height:100%;}
.bg-gradien-radial4,.bg-gradient4 {background:-webkit-radial-gradient(center, circle, rgba(45,181,98,0.7), rgba(63,153,244,0.7));
background:-moz-radial-gradient(center, circle, rgba(45,181,98,0.9), rgba(63,153,244,0.9));
background:-o-radial-gradient(center, circle,  rgba(45,181,98,0.9), rgba(63,153,244,0.9));
filter:progid:DXImageTransform.Microsoft.Alpha (opacity=0, finishopacity=100, style=2);height:100%;}
.bg-gradien-linear,.bg-gradient5{background:linear-gradient(to bottom right, rgba(4, 156, 47), rgba(4, 156, 47)),url("https://media.istockphoto.com/photos/circuit-board-abstract-futuristic-technology-processing-high-tech-picture-id1321202868?b=1&amp;k=20&amp;m=1321202868&amp;s=170667a&amp;w=0&amp;h=1DpqniIrb7Ozy9U6K5knIzkk0-kY3C5yxjBAlmiggmU=") center center no-repeat; background-size:cover}
.bg-gradien-linear2,.bg-gradient6{background:linear-gradient(to bottom, rgba(45,181,98,0.9), rgba(63,153,244,0.9)),url(" "#) center center no-repeat; background-size:cover}
.bg-gradien-linear3,.bg-gradient7{background:linear-gradient(to bottom left, rgba(33,182,252,0.9), rgba(41,54,122,0.9)),url(" "#) center center no-repeat; background-size:cover}
.bg-gradien-linear4,.bg-gradient8{background:linear-gradient(to top left, rgba(227,199,8,0.8), rgba(232,117,15,0.8)),url(" "#) center center no-repeat; background-size:cover}
.bg-gradien-linear5,.bg-gradient9{background:linear-gradient(to top left, rgba(227,199,8,0.7), rgba(232,117,15,0.7)),url("") center center no-repeat; background-size:cover}
.bg-gradient10{background:linear-gradient(15deg,#6d4dd9,#14badc);filter:drop-shadow(0 20px 10px rgba(0,0,0,.4))}
.bg-gradient11{background:linear-gradient(15deg,#0d763b,#3fb348);filter:drop-shadow(0 20px 10px rgba(0,0,0,.4))}
.bg-gradient12{background:linear-gradient(0deg,#00baff 0,#ff8c00)}
.bg-transparan-hitam {background:linear-gradient(to bottom right, rgba(0,0,0,0.5), rgba(0,0,0,0.5)),url(" "#) center center no-repeat; background-size:cover}
.bg-transparan-putih {background:linear-gradient(to bottom, rgba(255,255,255,0.6), rgba(255,255,255,0.6)),url(" "#) center center no-repeat; background-size:cover}
.bg-warnawarni{background: linear-gradient(-45deg, #EE7752, #E73C7E, #23A6D5, #23D5AB);background-size: 400% 400%;-webkit-animation: Gradient 15s ease infinite;-moz-animation: Gradient 15s ease infinite;animation: Gradient 15s ease infinite;}
@-webkit-keyframes Gradient{0%{background-position:0 50%}50%{background-position:100% 50%}100%{background-position:0 50%}}
@-moz-keyframes Gradient{0%{background-position:0 50%}50%{background-position:100% 50%}100%{background-position:0 50%}}
@keyframes Gradient{0%{background-position:0 50%}50%{background-position:100% 50%}100%{background-position:0 50%}}
.overlay-hitam{background:linear-gradient(to bottom right, rgba(0,0,0,0.6), rgba(0,0,0,0.6))}
.overlay-putih{background:linear-gradient(to bottom right, rgba(255,255,255,0.6), rgba(255,255,255,0.6))}
.overlay-merah{background:linear-gradient(to bottom right, rgba(220,20,60,0.6), rgba(220,20,60,0.6))}
.overlay-orange{background:linear-gradient(to bottom right, rgba(255,140,0,0.6), rgba(255,140,0,0.6))}
.overlay-kuning{background:linear-gradient(to bottom right, rgba(255,255,0,0.6), rgba(255,255,0,0.6))}
.overlay-ungu{background:linear-gradient(to bottom right, rgba(255,0,255,0.6), rgba(255,0,255,0.6))}
.overlay-biru{background:linear-gradient(to bottom right, rgba(0,191,255,0.6), rgba(0,191,255,0.6))}
.overlay-hijau{background:linear-gradient(to bottom right, rgba(50,205,50,0.6), rgba(50,205,50,0.6))}
#kontak-landing{margin:auto;max-width:640px}
#ContactForm1_contact-form-name,
#ContactForm1_contact-form-email{height:auto;margin:5px auto;padding:12px 8px;background:#fff;color:#444;border:1px solid rgba(0,0,0,.14);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);border-radius:2px;width:100%;min-width:100%;transition:all 0.5s ease-out}
#ContactForm1_contact-form-email-message{width:100%;height:175px;margin:5px 0;padding:15px 12px;background:#fff;color:#444;border:1px solid rgba(0,0,0,.14);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);border-radius:3px;resize:none;transition:all 0.5s ease-out}
#ContactForm1_contact-form-name:focus,
#ContactForm1_contact-form-email:focus,
#ContactForm1_contact-form-email-message:focus{outline:none;background:#fff;color:#444;border-color:#66afe9;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,0.6)}
#ContactForm1_contact-form-submit,{height:50px; float:left;background:red!important;margin:auto;vertical-align:middle;cursor:pointer;padding:0 10px;font-size:14px;text-align:center;letter-spacing:.5px;border:0;width:100%;max-width:140px;border-radius:3px;color:#fff;font-weight:500;transition:all .8s ease}
#ContactForm1_contact-form-submit:hover{background:#3498db;color:#fff;}
#ContactForm1_contact-form-error-message,#ContactForm1_contact-form-success-message{width:100%;margin-top:35px}.contact-form-error-message-with-border{background:#f6f6f6;border:none;box-shadow:none;color:#444;padding:5px 0}.contact-form-success-message{background:#4fc3f7;border:none;box-shadow:none;color:#fff}img.contact-form-cross{line-height:40px;margin-left:5px}.post-body input{width:initial}
.easyslider-wrapper {width: auto;float: left;position: relative;padding-right: 1%;padding-top: 0px;}
.easyslider {overflow: hidden;position: relative;width: 960px;height: 380px;background: transparent;}
.image_reel {position: absolute;top: 0;left: 0;}
.image_reel img {float: left;width: 20%;height: 380px;}
.paging {background: none;position: absolute;bottom: 15px;right: 20px;padding:4px 0 2px;z-index: 100;display:none;}
.paging a {margin: 3px;background: #fff;width: 10px;height:10px;display: inline-block;border: none;outline:none;}
.paging a.active {background: #15E3FF;border: 1px solid #15E3FF;}
.paging a:hover {}
.easytitledes {width:70%;display: none;position: absolute;bottom: 20px;left: 20px;z-index: 101;background:#000A3F;background: rgba(2, 0, 51, 0.6);padding: 10px 15px;}
.easytitledes a {color: #54aefa;font: 20px sans-serif;text-transform: uppercase;font-weight: bold;}
.easytitledes a:hover {color:#2b89fd}
.easytitledes span {color: #fff;font: 16px Arial;}
.mengambang-1{animation: animation-1 1s ease-out infinite;}
.mengambang-2{animation: animation-2 2s ease-out infinite;}
.mengambang-3{animation: animation-3 3s ease-out infinite;}
.mengambang-4{animation: animation-4 4s ease-out infinite;}
@keyframes animation-1 {50% { transform: translate(0, 20px);}}
@keyframes animation-2 {50% { transform: translate(0, 35px);}}
@keyframes animation-3 {50% { transform: translate(0, 25px);}}
@keyframes animation-4 {50% { transform: translate(0, 40px);}}
@keyframes blink{0%{color:red}100%{color:black}}
@-webkit-keyframes blink{0%{color:red}100%{color:black}}
.blink{-webkit-animation:blink 1s linear infinite;-moz-animation:blink 1s linear infinite;animation:blink 1s linear infinite}
@media only screen and (min-width: 1600px){
.oke{padding-left:20px; padding-right:20px}
.zoom{-webkit-transform: scale(1.2, 1.2);-moz-transform: scale(1.2, 1.2);-ms-transform: scale(1.2, 1.2);-o-transform: scale(1.2, 1.2);transform: scale(1.2, 1.2);}
.mobileshow { display: none; }}
@media only screen and (min-width: 1371px)and (max-width: 1599px){
.oke{padding-left:20px; padding-right:20px}
.zoom{-webkit-transform: scale(1.2, 1.2);-moz-transform: scale(1.2, 1.2);-ms-transform: scale(1.2, 1.2);-o-transform: scale(1.2, 1.2);transform: scale(1.2, 1.2);}
.mobileshow { display: none; }}
@media only screen and (min-width: 1154px)and (max-width: 1370px){
.oke{padding-left:20px; padding-right:20px}
.zoom{-webkit-transform: scale(1.2, 1.2);-moz-transform: scale(1.2, 1.2);-ms-transform: scale(1.2, 1.2);-o-transform: scale(1.2, 1.2);transform: scale(1.2, 1.2);}
.mobileshow { display: none; }}
@media only screen and (min-width: 960px)and (max-width: 1153px){
.zoom{-webkit-transform: scale(1.2, 1.2);-moz-transform: scale(1.2, 1.2);-ms-transform: scale(1.2, 1.2);-o-transform: scale(1.2, 1.2);transform: scale(1.2, 1.2);}
.mobileshow { display: none; }}
@media only screen and (min-width: 769px) and (max-width: 959px){
h4,.sedang { font-size:24px}
.xx-besar { font-size:45px}
.x-besar { font-size:38px}
.besar { font-size:30px}
.x-kecil { font-size:13px}
.kol-16{width:33.3%}
.kol-14{width:49.8%}
.img-fitur,.gambar-fitur{width:100px;height:100px;;font-size:60px}
.harga1 {max-width:95%}
.mobileshow { display: none; }
.box{padding:15px}
.easyslider {overflow: hidden;position: relative;width: 765px;height: 313px;background: transparent;}
.image_reel {position: absolute;top: 0;left: 0;}
.image_reel img {float: left;width: 20%;height: 313px;}
.top{margin-top:-250px;}
.lebar-bawah{padding-bottom:200px}
.zoom{-webkit-transform: scale(1.2, 1.2);-moz-transform: scale(1.2, 1.2);-ms-transform: scale(1.2, 1.2);-o-transform: scale(1.2, 1.2);transform: scale(1.2, 1.2);}
.order1-merah,.order1-hijau,.order1-biru,.order1-ungu,.order2-merah,.order2-hijau,.order2-biru,.order2-ungu{width:350px}}
@media only screen and (min-width: 631px) and (max-width: 768px){
.post-body,.widget-content{ font-size:18px;line-height:1.5em}
h2.post-title.entry-title,h2.post-title.entry-title a,h2,h1,h3 {font-size:28px}
.mobilecenter {text-align: center;}
h4,.sedang { font-size:22px}
.xx-besar { font-size:43px}
.x-besar { font-size:34px}
.besar { font-size:28px}
h5,.normal { font-size:18px}
.kecil { font-size:15px}
.x-kecil { font-size:12px;line-height:1.5em}
.lebar{padding:25px 0 25px}
.kol-6{width:33.3%}
.kol6{width:33.3%}
.kol-4{width:49.8%}
.kol-12,.kol-13,.kol-14,.kol-15,.kol-16,.kol-123{width:99.5%}
.harga1 {max-width:95%}
.mobileshow { display: none; }
.box{padding:13px}
.box-kontak {padding:20px;width:80%;background-color:#ececec;}
.img-fitur,.gambar-fitur{width:100px;height:100px;;font-size:60px}
.ikon-fitur{width:100%;height:auto;float:none;padding:10px;font-size:60px;text-align:center}
.avatar{width:140px;height:140px;overflow:hidden;margin:auto;border-radius:140px;border:3px solid #e9e9e9}
.logo{width:170px;height:auto;}
.easyslider {overflow: hidden;position: relative;width: 635px;height: 259px;background: transparent;}
.image_reel {position: absolute;top: 0;left: 0;}
.image_reel img {float: left;width: 20%;height:259px;}
.lebar-bawah{padding-bottom:135px}
.top{margin-top:-200px;}
.harga2 {max-width:80%}}
@media only screen and (min-width: 600px) and (max-width: 630px){
.post-body,.widget-content{ font-size:18px;line-height:1.5em}
h2.post-title.entry-title,h2.post-title.entry-title a,h2,h1,h3 {font-size:25px}
.xx-besar { font-size:40px}
.x-besar { font-size:34px}
.mobilecenter{text-align: center;}
.mobilehide { display: none; }
.besar { font-size:26px}
h4,.sedang { font-size:22px}
h5,.normal { font-size:18px}
.kecil { font-size:15px}
.x-kecil { font-size:12px;line-height:1.5em}
.lebar{padding:25px 0 25px}
.kol-6{width:33.3%}
.kol6{width:33.3%}
.kol-4{width:49.8%}
.kol-12,.kol-13,.kol-14,.kol-15,.kol-5,.kol-16,.kol-123{width:99.5%}
.harga1 {max-width:95%}
.img-fitur,.gambar-fitur{width:100px;height:100px;;font-size:60px}
.ikon-fitur{width:100%;height:auto;float:none;padding:10px;font-size:60px;text-align:center}
.box{padding:13px}
.box-kontak {padding:20px;width:80%;background-color:#ececec;}
.avatar{width:140px;height:140px;overflow:hidden;margin:auto;border-radius:140px;border:3px solid #e9e9e9}
.logo{width:170px;height:auto;}
.easyslider {overflow: hidden;position: relative;width: 595px;height: 243px;background: transparent;}
.image_reel {position: absolute;top: 0;left: 0;}
.image_reel img {float: left;width: 20%;height:243px;}
.lebar-bawah{padding-bottom:10px}
.top{margin-top:-70px;}
.harga2 {max-width:80%}}
@media only screen and (min-width: 480px) and (max-width: 599px){
.mobilehide{ display: none; }
.post-body,.widget-content{ font-size:18px;line-height:1.5em}
h2.post-title.entry-title,h2.post-title.entry-title a,h2,h1,h3 {font-size:23px}
.mobilecenter{text-align: center;}
.xx-besar { font-size:40px}
.x-besar { font-size:34px}
.besar { font-size:26px}
h4,.sedang { font-size:22px}
h5,.normal { font-size:18px}
.kecil { font-size:15px}
.x-kecil { font-size:12px;line-height:1.5em}
.lebar{padding:20px 0 20px}
.kol-6{width:33.3%}
.kol-4{width:49.8%}
.kol6{width:33.3%}
.kol-12,.kol-13,.kol-14,.kol-15,.kol-5,.kol-16,.kol-123{width:99.5%}
.harga1 {max-width:90%}
.img-fitur,.gambar-fitur{width:100px;height:100px;;font-size:60px}
.ikon-fitur{width:100%;height:auto;float:none;padding:10px;font-size:60px;text-align:center}
.lebar80,.lebar75,.lebar70,.lebar85{max-width:85%}
.box{padding:13px}
.box-kontak {padding:20px;width:80%;background-color:#ececec;}
.avatar{width:140px;height:140px;overflow:hidden;margin:auto;border-radius:140px;border:3px solid #e9e9e9}
.easyslider {overflow: hidden;position: relative;width: 475px;height: 194px;background: transparent;}
.image_reel {position: absolute;top: 0;left: 0;}
.image_reel img {float: left;width: 20%;height:194px;}
.top{margin-top:-100px}
.lebar-bawah{padding-bottom:60px}
.harga2 {max-width:80%}
.order1-merah,.order1-hijau,.order1-biru,.order1-ungu,.order2-merah,.order2-hijau,.order2-biru,.order2-ungu{width:95%}}
@media only screen and (max-width: 480px){
.post-body,.widget-content{ font-size:17px;line-height:1.5em}
.mobilehide{ display: none;}
h2.post-title.entry-title,h2.post-title.entry-title a,h2,h1,h3 {font-size:23px}
.post-body {font-size: 17px;}
.box-kontak {padding:20px;width:80%;background-color:#ececec;}
.mobilecenter{text-align: center;}
.xx-besar { font-size:36px}
.x-besar { font-size:32px}
.besar { font-size:26px}
h4,.sedang { font-size:20px}
.kecil { font-size:14px}
.x-kecil { font-size:12px;line-height:1.5em}
h5,.normal { font-size:17px}
.lebar{padding:20px 0 20px}
.lebar-bawah{padding-bottom:60px}
.top{margin-top:-100px}
.top2{margin-top:-200px;}
.top3{margin-top:-140px;}
.kol6{width:33.3%}
.kol4{width:49.8%}
.kol-2,.kol-3,.kol-4,.kol-5,.kol-6,.kol-23,.kol-12,.kol-13,.kol-14,.kol-15,.kol-16,.kol-123{width:99%}
.fitur{padding:20px 10px 20px}
.img-fitur{width:90px;height:90px;;font-size:60px}
.gambar-fitur{width:80px;height:80px;;font-size:50px}
.ico-fitur{width:45px;height:45px;float:left;padding-right:20px;padding-left:5px}
.ikon-fitur{width:100%;height:auto;float:none;padding:10px;font-size:60px;text-align:center}
.icon-samping{margin-right:10px;width:80px;height:80px;font-size:50px;line-height:1.55em;}
.icon-kecil{width:50px;height:50px;font-size:30px;text-align:center;line-height:1.55em;}
.btn-full{min-width:280px}
.btn-animasi1,.btn-animasi2,.btn-animasi3,.btn-animasi4,.btn-animasi5{font-size:16px;line-height:2em}
.img-btn{width:32px;height:32px;margin-right:5px}
.order{ width:300px; padding:10px}
.order1-merah,.order1-hijau,.order1-biru,.order1-ungu,.order2-merah,.order2-hijau,.order2-biru,.order2-ungu{width:98%}.order1-merah span,.order1-hijau span,.order1-biru span,.order1-ungu span,.order2-merah span,.order2-hijau span,.order2-biru span,.order2-ungu span{font-size:35px;}
.lebar80,.lebar75,.lebar70,.lebar85,.lebar90{max-width:95%}
.box{padding:13px}.post-body-blockquote {border-color:#CC0000;border-image:none;border-style:dashed;border-width:3px;margin:0 auto;padding:15px;width:95%;}
.garis-box {border-right: 0px solid #ececec;border-left: 0px solid #ececec;border-top: 1px solid #ececec;border-bottom: 1px solid #ececec;}
.harga1 {max-width:90%}.harga1 .judul{font-size:26px;font-weight:normal}.harga1 .harga span{font-size:30px;}
.harga2 {max-width:90%}.harga2 .judul{font-size:26px;font-weight:normal}.harga2 .harga span{font-size:30px;}
.btn {font-size:15px;margin:2px;padding: 6px 14px}
.btn1 {font-size:15px;margin:2px;padding: 6px 14px}
.btn2 {font-size:15px;margin:2px;padding: 6px 14px}
.btn3 {font-size:15px;margin:2px;padding: 6px 14px}
.btn-order,.btn-x-besar {padding:10px 20px;font-size:22px}
.btn-besar {font-size:20px; padding: 8px 16px;}
.btn-kecil {font-size:12px; padding: 2px 8px;}
.avatar{width:140px;height:140px;overflow:hidden;margin:auto;border-radius:140px;border:3px solid #e9e9e9}
.paging {background: none;position: absolute;bottom: 5px;right: 5px;padding:2px 0 2px;z-index: 100;display:none;}
.easyslider {overflow: hidden;position: relative;width: 350px;height: 143px;background: transparent;}
.image_reel {position: absolute;top: 0;left: 0;}
.image_reel img {float: left;width: 20%;height:143px;}
.easytitledes {width:60%;display: none;position: absolute;bottom: 5px;left: 5px;z-index: 101;background:#000A3F;background: rgba(2, 0, 51, 0.6);padding: 5px 5px;}
.easytitledes a {font: 16px sans-serif;font-weight: bold;}
.easytitledes span {font: 12px Arial;}
}

--></style>
<!-- Css Animasi -->
<style>
/*!
 * animate.css -http://daneden.me/animate
 * Version - 3.5.2
 * Licensed under the MIT license - http://opensource.org/licenses/MIT
 *Copyright (c) 2017 Daniel Eden
 */
.animated{animation-duration:1s;animation-fill-mode:both}.animated.infinite{animation-iteration-count:infinite}.animated.hinge{animation-duration:2s}
.animated.bounceIn,.animated.bounceOut,.animated.flipOutX,.animated.flipOutY{animation-duration:.75s}
@keyframes bounce{0%,20%,53%,80%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1);transform:translateZ(0)}40%,43%{animation-timing-function:cubic-bezier(.755,.05,.855,.06);transform:translate3d(0,-30px,0)}70%{animation-timing-function:cubic-bezier(.755,.05,.855,.06);transform:translate3d(0,-15px,0)}90%{transform:translate3d(0,-4px,0)}}.bounce{animation-name:bounce;transform-origin:center bottom}
@keyframes flash{0%,50%,to{opacity:1}25%,75%{opacity:0}}.flash{animation-name:flash}
@keyframes pulse{0%{transform:scaleX(1)}50%{transform:scale3d(1.05,1.05,1.05)}to{transform:scaleX(1)}}.pulse{animation-name:pulse}
@keyframes rubberBand{0%{transform:scaleX(1)}30%{transform:scale3d(1.25,.75,1)}40%{transform:scale3d(.75,1.25,1)}50%{transform:scale3d(1.15,.85,1)}65%{transform:scale3d(.95,1.05,1)}75%{transform:scale3d(1.05,.95,1)}to{transform:scaleX(1)}}.rubberBand{animation-name:rubberBand}
@keyframes shake{0%,to{transform:translateZ(0)}10%,30%,50%,70%,90%{transform:translate3d(-10px,0,0)}20%,40%,60%,80%{transform:translate3d(10px,0,0)}}.shake{animation-name:shake}
@keyframes headShake{0%{transform:translateX(0)}6.5%{transform:translateX(-6px) rotateY(-9deg)}18.5%{transform:translateX(5px) rotateY(7deg)}31.5%{transform:translateX(-3px) rotateY(-5deg)}43.5%{transform:translateX(2px) rotateY(3deg)}50%{transform:translateX(0)}}.headShake{animation-timing-function:ease-in-out;animation-name:headShake}
@keyframes swing{20%{transform:rotate(15deg)}40%{transform:rotate(-10deg)}60%{transform:rotate(5deg)}80%{transform:rotate(-5deg)}to{transform:rotate(0deg)}}.swing{transform-origin:top center;animation-name:swing}
@keyframes tada{0%{transform:scaleX(1)}10%,20%{transform:scale3d(.9,.9,.9) rotate(-3deg)}30%,50%,70%,90%{transform:scale3d(1.1,1.1,1.1) rotate(3deg)}40%,60%,80%{transform:scale3d(1.1,1.1,1.1) rotate(-3deg)}to{transform:scaleX(1)}}.tada{animation-name:tada}
@keyframes wobble{0%{transform:none}15%{transform:translate3d(-25%,0,0) rotate(-5deg)}30%{transform:translate3d(20%,0,0) rotate(3deg)}45%{transform:translate3d(-15%,0,0) rotate(-3deg)}60%{transform:translate3d(10%,0,0) rotate(2deg)}75%{transform:translate3d(-5%,0,0) rotate(-1deg)}to{transform:none}}.wobble{animation-name:wobble}
@keyframes jello{0%,11.1%,to{transform:none}22.2%{transform:skewX(-12.5deg) skewY(-12.5deg)}33.3%{transform:skewX(6.25deg) skewY(6.25deg)}44.4%{transform:skewX(-3.125deg) skewY(-3.125deg)}55.5%{transform:skewX(1.5625deg) skewY(1.5625deg)}66.6%{transform:skewX(-.78125deg) skewY(-.78125deg)}77.7%{transform:skewX(.390625deg) skewY(.390625deg)}88.8%{transform:skewX(-.1953125deg) skewY(-.1953125deg)}}.jello{animation-name:jello;transform-origin:center}
@keyframes bounceIn{0%,20%,40%,60%,80%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:scale3d(.3,.3,.3)}20%{transform:scale3d(1.1,1.1,1.1)}40%{transform:scale3d(.9,.9,.9)}60%{opacity:1;transform:scale3d(1.03,1.03,1.03)}80%{transform:scale3d(.97,.97,.97)}to{opacity:1;transform:scaleX(1)}}.bounceIn{animation-name:bounceIn}
@keyframes bounceInDown{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(0,-3000px,0)}60%{opacity:1;transform:translate3d(0,25px,0)}75%{transform:translate3d(0,-10px,0)}90%{transform:translate3d(0,5px,0)}to{transform:none}}.bounceInDown{animation-name:bounceInDown}
@keyframes bounceInLeft{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(-3000px,0,0)}60%{opacity:1;transform:translate3d(25px,0,0)}75%{transform:translate3d(-10px,0,0)}90%{transform:translate3d(5px,0,0)}to{transform:none}}.bounceInLeft{animation-name:bounceInLeft}
@keyframes bounceInRight{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(3000px,0,0)}60%{opacity:1;transform:translate3d(-25px,0,0)}75%{transform:translate3d(10px,0,0)}90%{transform:translate3d(-5px,0,0)}to{transform:none}}.bounceInRight{animation-name:bounceInRight}
@keyframes bounceInUp{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(0,3000px,0)}60%{opacity:1;transform:translate3d(0,-20px,0)}75%{transform:translate3d(0,10px,0)}90%{transform:translate3d(0,-5px,0)}to{transform:translateZ(0)}}.bounceInUp{animation-name:bounceInUp}
@keyframes bounceOut{20%{transform:scale3d(.9,.9,.9)}50%,55%{opacity:1;transform:scale3d(1.1,1.1,1.1)}to{opacity:0;transform:scale3d(.3,.3,.3)}}.bounceOut{animation-name:bounceOut}
@keyframes bounceOutDown{20%{transform:translate3d(0,10px,0)}40%,45%{opacity:1;transform:translate3d(0,-20px,0)}to{opacity:0;transform:translate3d(0,2000px,0)}}.bounceOutDown{animation-name:bounceOutDown}
@keyframes bounceOutLeft{20%{opacity:1;transform:translate3d(20px,0,0)}to{opacity:0;transform:translate3d(-2000px,0,0)}}.bounceOutLeft{animation-name:bounceOutLeft}
@keyframes bounceOutRight{20%{opacity:1;transform:translate3d(-20px,0,0)}to{opacity:0;transform:translate3d(2000px,0,0)}}.bounceOutRight{animation-name:bounceOutRight}
@keyframes bounceOutUp{20%{transform:translate3d(0,-10px,0)}40%,45%{opacity:1;transform:translate3d(0,20px,0)}to{opacity:0;transform:translate3d(0,-2000px,0)}}.bounceOutUp{animation-name:bounceOutUp}
@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fadeIn{animation-name:fadeIn}
@keyframes fadeInDown{0%{opacity:0;transform:translate3d(0,-100%,0)}to{opacity:1;transform:none}}.fadeInDown{animation-name:fadeInDown}
@keyframes fadeInDownBig{0%{opacity:0;transform:translate3d(0,-2000px,0)}to{opacity:1;transform:none}}.fadeInDownBig{animation-name:fadeInDownBig}
@keyframes fadeInLeft{0%{opacity:0;transform:translate3d(-100%,0,0)}to{opacity:1;transform:none}}.fadeInLeft{animation-name:fadeInLeft}
@keyframes fadeInLeftBig{0%{opacity:0;transform:translate3d(-2000px,0,0)}to{opacity:1;transform:none}}.fadeInLeftBig{animation-name:fadeInLeftBig}
@keyframes fadeInRight{0%{opacity:0;transform:translate3d(100%,0,0)}to{opacity:1;transform:none}}.fadeInRight{animation-name:fadeInRight}
@keyframes fadeInRightBig{0%{opacity:0;transform:translate3d(2000px,0,0)}to{opacity:1;transform:none}}.fadeInRightBig{animation-name:fadeInRightBig}
@keyframes fadeInUp{0%{opacity:0;transform:translate3d(0,100%,0)}to{opacity:1;transform:none}}.fadeInUp{animation-name:fadeInUp}
@keyframes fadeInUpBig{0%{opacity:0;transform:translate3d(0,2000px,0)}to{opacity:1;transform:none}}.fadeInUpBig{animation-name:fadeInUpBig}
@keyframes fadeOut{0%{opacity:1}to{opacity:0}}.fadeOut{animation-name:fadeOut}
@keyframes fadeOutDown{0%{opacity:1}to{opacity:0;transform:translate3d(0,100%,0)}}.fadeOutDown{animation-name:fadeOutDown}
@keyframes fadeOutDownBig{0%{opacity:1}to{opacity:0;transform:translate3d(0,2000px,0)}}.fadeOutDownBig{animation-name:fadeOutDownBig}
@keyframes fadeOutLeft{0%{opacity:1}to{opacity:0;transform:translate3d(-100%,0,0)}}.fadeOutLeft{animation-name:fadeOutLeft}
@keyframes fadeOutLeftBig{0%{opacity:1}to{opacity:0;transform:translate3d(-2000px,0,0)}}.fadeOutLeftBig{animation-name:fadeOutLeftBig}
@keyframes fadeOutRight{0%{opacity:1}to{opacity:0;transform:translate3d(100%,0,0)}}.fadeOutRight{animation-name:fadeOutRight}
@keyframes fadeOutRightBig{0%{opacity:1}to{opacity:0;transform:translate3d(2000px,0,0)}}.fadeOutRightBig{animation-name:fadeOutRightBig}
@keyframes fadeOutUp{0%{opacity:1}to{opacity:0;transform:translate3d(0,-100%,0)}}.fadeOutUp{animation-name:fadeOutUp}
@keyframes fadeOutUpBig{0%{opacity:1}to{opacity:0;transform:translate3d(0,-2000px,0)}}.fadeOutUpBig{animation-name:fadeOutUpBig}
@keyframes flip{0%{transform:perspective(400px) rotateY(-1turn);animation-timing-function:ease-out}40%{transform:perspective(400px) translateZ(150px) rotateY(-190deg);animation-timing-function:ease-out}50%{transform:perspective(400px) translateZ(150px) rotateY(-170deg);animation-timing-function:ease-in}80%{transform:perspective(400px) scale3d(.95,.95,.95);animation-timing-function:ease-in}to{transform:perspective(400px);animation-timing-function:ease-in}}.animated.flip{-webkit-backface-visibility:visible;backface-visibility:visible;animation-name:flip}
@keyframes flipInX{0%{transform:perspective(400px) rotateX(90deg);animation-timing-function:ease-in;opacity:0}40%{transform:perspective(400px) rotateX(-20deg);animation-timing-function:ease-in}60%{transform:perspective(400px) rotateX(10deg);opacity:1}80%{transform:perspective(400px) rotateX(-5deg)}to{transform:perspective(400px)}}.flipInX{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipInX}
@keyframes flipInY{0%{transform:perspective(400px) rotateY(90deg);animation-timing-function:ease-in;opacity:0}40%{transform:perspective(400px) rotateY(-20deg);animation-timing-function:ease-in}60%{transform:perspective(400px) rotateY(10deg);opacity:1}80%{transform:perspective(400px) rotateY(-5deg)}to{transform:perspective(400px)}}.flipInY{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipInY}
@keyframes flipOutX{0%{transform:perspective(400px)}30%{transform:perspective(400px) rotateX(-20deg);opacity:1}to{transform:perspective(400px) rotateX(90deg);opacity:0}}.flipOutX{animation-name:flipOutX;-webkit-backface-visibility:visible!important;backface-visibility:visible!important}
@keyframes flipOutY{0%{transform:perspective(400px)}30%{transform:perspective(400px) rotateY(-15deg);opacity:1}to{transform:perspective(400px) rotateY(90deg);opacity:0}}.flipOutY{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipOutY}
@keyframes lightSpeedIn{0%{transform:translate3d(100%,0,0) skewX(-30deg);opacity:0}60%{transform:skewX(20deg);opacity:1}80%{transform:skewX(-5deg);opacity:1}to{transform:none;opacity:1}}.lightSpeedIn{animation-name:lightSpeedIn;animation-timing-function:ease-out}
@keyframes lightSpeedOut{0%{opacity:1}to{transform:translate3d(100%,0,0) skewX(30deg);opacity:0}}.lightSpeedOut{animation-name:lightSpeedOut;animation-timing-function:ease-in}
@keyframes rotateIn{0%{transform-origin:center;transform:rotate(-200deg);opacity:0}to{transform-origin:center;transform:none;opacity:1}}.rotateIn{animation-name:rotateIn}
@keyframes rotateInDownLeft{0%{transform-origin:left bottom;transform:rotate(-45deg);opacity:0}to{transform-origin:left bottom;transform:none;opacity:1}}.rotateInDownLeft{animation-name:rotateInDownLeft}
@keyframes rotateInDownRight{0%{transform-origin:right bottom;transform:rotate(45deg);opacity:0}to{transform-origin:right bottom;transform:none;opacity:1}}.rotateInDownRight{animation-name:rotateInDownRight}
@keyframes rotateInUpLeft{0%{transform-origin:left bottom;transform:rotate(45deg);opacity:0}to{transform-origin:left bottom;transform:none;opacity:1}}.rotateInUpLeft{animation-name:rotateInUpLeft}
@keyframes rotateInUpRight{0%{transform-origin:right bottom;transform:rotate(-90deg);opacity:0}to{transform-origin:right bottom;transform:none;opacity:1}}.rotateInUpRight{animation-name:rotateInUpRight}
@keyframes rotateOut{0%{transform-origin:center;opacity:1}to{transform-origin:center;transform:rotate(200deg);opacity:0}}.rotateOut{animation-name:rotateOut}
@keyframes rotateOutDownLeft{0%{transform-origin:left bottom;opacity:1}to{transform-origin:left bottom;transform:rotate(45deg);opacity:0}}.rotateOutDownLeft{animation-name:rotateOutDownLeft}
@keyframes rotateOutDownRight{0%{transform-origin:right bottom;opacity:1}to{transform-origin:right bottom;transform:rotate(-45deg);opacity:0}}.rotateOutDownRight{animation-name:rotateOutDownRight}
@keyframes rotateOutUpLeft{0%{transform-origin:left bottom;opacity:1}to{transform-origin:left bottom;transform:rotate(-45deg);opacity:0}}.rotateOutUpLeft{animation-name:rotateOutUpLeft}
@keyframes rotateOutUpRight{0%{transform-origin:right bottom;opacity:1}to{transform-origin:right bottom;transform:rotate(90deg);opacity:0}}.rotateOutUpRight{animation-name:rotateOutUpRight}
@keyframes hinge{0%{transform-origin:top left;animation-timing-function:ease-in-out}20%,60%{transform:rotate(80deg);transform-origin:top left;animation-timing-function:ease-in-out}40%,80%{transform:rotate(60deg);transform-origin:top left;animation-timing-function:ease-in-out;opacity:1}to{transform:translate3d(0,700px,0);opacity:0}}.hinge{animation-name:hinge}
@keyframes jackInTheBox{0%{opacity:0;transform:scale(.1) rotate(30deg);transform-origin:center bottom}50%{transform:rotate(-10deg)}70%{transform:rotate(3deg)}to{opacity:1;transform:scale(1)}}.jackInTheBox{animation-name:jackInTheBox}
@keyframes rollIn{0%{opacity:0;transform:translate3d(-100%,0,0) rotate(-120deg)}to{opacity:1;transform:none}}.rollIn{animation-name:rollIn}
@keyframes rollOut{0%{opacity:1}to{opacity:0;transform:translate3d(100%,0,0) rotate(120deg)}}.rollOut{animation-name:rollOut}
@keyframes zoomIn{0%{opacity:0;transform:scale3d(.3,.3,.3)}50%{opacity:1}}.zoomIn{animation-name:zoomIn}
@keyframes zoomInDown{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,-1000px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,60px,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInDown{animation-name:zoomInDown}
@keyframes zoomInLeft{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(-1000px,0,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(10px,0,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInLeft{animation-name:zoomInLeft}
@keyframes zoomInRight{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(1000px,0,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(-10px,0,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInRight{animation-name:zoomInRight}
@keyframes zoomInUp{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,1000px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,-60px,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInUp{animation-name:zoomInUp}
@keyframes zoomOut{0%{opacity:1}50%{opacity:0;transform:scale3d(.3,.3,.3)}to{opacity:0}}.zoomOut{animation-name:zoomOut}
@keyframes zoomOutDown{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,-60px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}to{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,2000px,0);transform-origin:center bottom;animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomOutDown{animation-name:zoomOutDown}
@keyframes zoomOutLeft{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(42px,0,0)}to{opacity:0;transform:scale(.1) translate3d(-2000px,0,0);transform-origin:left center}}.zoomOutLeft{animation-name:zoomOutLeft}
@keyframes zoomOutRight{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(-42px,0,0)}to{opacity:0;transform:scale(.1) translate3d(2000px,0,0);transform-origin:right center}}.zoomOutRight{animation-name:zoomOutRight}
@keyframes zoomOutUp{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,60px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}to{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,-2000px,0);transform-origin:center bottom;animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomOutUp{animation-name:zoomOutUp}
@keyframes slideInDown{0%{transform:translate3d(0,-100%,0);visibility:visible}to{transform:translateZ(0)}}.slideInDown{animation-name:slideInDown}
@keyframes slideInLeft{0%{transform:translate3d(-100%,0,0);visibility:visible}to{transform:translateZ(0)}}.slideInLeft{animation-name:slideInLeft}
@keyframes slideInRight{0%{transform:translate3d(100%,0,0);visibility:visible}to{transform:translateZ(0)}}.slideInRight{animation-name:slideInRight}
@keyframes slideInUp{0%{transform:translate3d(0,100%,0);visibility:visible}to{transform:translateZ(0)}}.slideInUp{animation-name:slideInUp}
@keyframes slideOutDown{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(0,100%,0)}}.slideOutDown{animation-name:slideOutDown}
@keyframes slideOutLeft{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(-100%,0,0)}}.slideOutLeft{animation-name:slideOutLeft}
@keyframes slideOutRight{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(100%,0,0)}}.slideOutRight{animation-name:slideOutRight}
@keyframes slideOutUp{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(0,-100%,0)}}.slideOutUp{animation-name:slideOutUp}
.delay-1 {-webkit-animation-delay: 0.2s;-moz-animation-delay: 0.2s;-o-animation-delay: 0.2s;-ms-animation-delay: 0.2s;}.delay-2 {-webkit-animation-delay: 0.5s;-moz-animation-delay: 0.5s;-o-animation-delay: 0.5s;-ms-animation-delay: 0.2s;}.delay-3 {-webkit-animation-delay: 0.8s;-moz-animation-delay: 0.8s;-o-animation-delay: 0.8s;-ms-animation-delay: 0.2s;}.delay-4 {-webkit-animation-delay: 1.1s;-moz-animation-delay: 1.1s;-o-animation-delay: 1.1s;-ms-animation-delay: 0.2s;}.delay-5 {-webkit-animation-delay: 1.4s;-moz-animation-delay: 1.4s;-o-animation-delay: 1.4s;-ms-animation-delay: 0.2s;}.delay-6 {-webkit-animation-delay: 1.7s;-moz-animation-delay: 1.7s;-o-animation-delay: 1.7s;-ms-animation-delay: 0.2s;}.delay-7 {-webkit-animation-delay: 2.0s;-moz-animation-delay: 2.0s;-o-animation-delay: 2.0s;-ms-animation-delay: 0.2s;}.delay-8 {-webkit-animation-delay: 2.3s;-moz-animation-delay: 2.3s;-o-animation-delay: 2.3s;-ms-animation-delay: 0.2s;}.delay-9 {-webkit-animation-delay: 2.6s;-moz-animation-delay: 2.6s;-o-animation-delay: 2.6s;-ms-animation-delay: 0.2s;}.delay-10 {-webkit-animation-delay: 2.9s;-moz-animation-delay: 2.9s;-o-animation-delay: 2.9s;-ms-animation-delay: 0.2s;}.delay-11 {-webkit-animation-delay: 3.2s;-moz-animation-delay: 3.2s;-o-animation-delay: 3.2s;-ms-animation-delay: 0.2s;}.delay-12 {-webkit-animation-delay: 3.5s;-moz-animation-delay: 3.5s;-o-animation-delay: 3.5s;-ms-animation-delay: 0.2s;}.delay-13 {-webkit-animation-delay: 3.8s;-moz-animation-delay: 3.8s;-o-animation-delay: 3.8s;-ms-animation-delay: 0.2s;}.delay-14 {-webkit-animation-delay: 4.1s;-moz-animation-delay: 4.1s;-o-animation-delay: 4.1s;-ms-animation-delay: 0.2s;}.delay-15 {-webkit-animation-delay: 4.4s;-moz-animation-delay: 4.4s;-o-animation-delay: 4.4s;-ms-animation-delay: 0.2s;}.visible{visibility: visible;}
</style>
<!-- CSS on AllPage -->
<style>
body {
margin: 0px; font-family: 'Poppins', sans-serif; color:#494949;letter-spacing:auto;line-height:1.5em;font-size:20px}
a {	text-decoration: none;}
img {max-width: 100%; height: auto;border-radius:4px}
#headermenu, #landingpage {margin-bottom: 0px; clear:both;}
.box-column {padding:0px 0px 0px 0px; border:0px dotted $bordercolor;}
#left-side .widget, #right-bar .widget {padding: 0 0px;	margin: 0px 0 0px 0;}
#outer-wrapper {max-width: 100%; margin: 0px auto; padding: 0px; border:0px}
#peklis-wrapper { overflow: hidden;}
.right {float: right;}
.left {float: left;}
#header-wrapper {overflow: hidden; margin: 0px 0;}
#left-side{width:70%;float:left;overflow:hidden;}
#right-bar{width:30%;overflow:hidden;}
#header {padding: 0px 0;}
.kanan {float: right;}
.kiri {float: left;}
.post-outer {overflow: hidden; padding: 0px; margin: 0 0 10px 0;}
.postt {float: left; margin: 0 5px 0 0;}
.info-post a {color: #666;	margin-right: 6px;}
.info-post {font-size: 12px; margin: 0 0 5px 0;	color: #666; overflow: hidden;}
.snippetpost {font-size: 18px;	line-height: 21px;}
.date-header {font-size: 12px;	padding: 15px 0 0 0;}
#blog-pager a:hover {background: #ffffff;}
#blog-pager a {display: inline-block; padding: 6px 12px; font-size: 12px; text-transform: uppercase; font-weight: bold;}
#blog-pager {border-bottom: 0px solid #2980b9;	border-radius: 5px;}
#page-loader{position:fixed!important;position:absolute;top:0;right:0;bottom:0;left:0;z-index:999999;background:#fff url(../../1.bp.blogspot.com/-LVLuytW5d3o/XsdBLVEbENI/AAAAAAAAAK4/CgRyvdx5XLsXovtM25oafxNcbWhHS4mGgCK4BGAsYHg/tenor.gif) no-repeat 50% 50%;padding:1em 1.2em;display:none}
#ignielRelated{display:block; margin:20px 0px;  line-height:1.5em;max-width:1140px}
#ignielRelated h3.title{ font-weight:600;  text-align:center;  text-transform:uppercase;  line-height:initial;}
.dihome{ font-size:26px; }
.dipostingan{ font-size:16px;}
#ignielRelated h3.title span{  background-color:#fff;  padding:0px 15px;  position:relative;  z-index:1;}
#ignielRelated h3.title:before{  content: '';  display: block;  position: relative;  top:20px;  width: 100%;  border-top: 2px solid #cccccc;}
#ignielRelated ul{  margin:20px 0px 0px;  padding:0px;  display:flex;  display:-webkit-flex;  flex-wrap:wrap;  -webkit-flex-wrap:wrap;  -ms-flex-wrap:wrap;}
#ignielRelated ul li{  list-style:none;  width:calc((100% / 3) - 15px);  text-align:center;  margin-right:20px;  margin-bottom:20px;  padding:0px;  -webkit-margin-start:0px !important;}
#ignielRelated ul li .thumb{  overflow:hidden;  line-height:0px;  border-radius:7px;}
#ignielRelated ul li:nth-of-type(3n){  margin-right:0px;}
#ignielRelated ul li a{  display:block;}
#ignielRelated ul li a.judul{  color:#494949; font-weight:500;  margin-top:7px;font-size:18px}
#ignielRelated ul li a.judul:hover, #ignielRelated ul li:hover a.judul{  color:#2167c7;}
#ignielRelated ul li a img{  width:100%;  max-height:143px;  transition:all .3s ease;  border:0px;  margin:0px;}
#ignielRelated ul li a img:hover, #ignielRelated ul li:hover img{ filter: brightness(75%);  -webkit-filter: brightness(75%);}
#ignielRelated .norelated{  text-align:center;  font-weight:600;}
.gsc-search-box {width: 100%;margin-left: -8px }
.gsc-search-box input {outline: none;}
input:focus::-webkit-input-placeholder {color: transparent;}
input:focus:-moz-placeholder {color: transparent;}
input:focus::-moz-placeholder {color: transparent;}
.gsc-search-box input {background: url(../../2.bp.blogspot.com/-xpzxYc77ack/VDpdOE5tzMI/AAAAAAAAAeQ/TyXhIfEIUy4/s1600/search-dark.png) no-repeat 10px 13px #f2f2f2;border: 2px solid #b1b1b1;font: bold 12px Arial,Helvetica,Sans-serif;color: #6A6F75;width: 100%;padding: 15px 17px 10px 30px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;text-shadow: 0 2px 3px #fff;-webkit-transition: all 0.7s ease 0s;-moz-transition: all 0.7s ease 0s;-o-transition: all 0.7s ease 0s;transition: all 0.7s ease 0s;}
.follow-by-email-email{border: 2px solid #b1b1b1;font: normal 14px Arial,Helvetica,Sans-serif;color: #6A6F75;width: 100%;padding: 15px 10px 15px 10px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;text-shadow: 0 2px 3px #fff;-webkit-transition: all 0.7s ease 0s;-moz-transition: all 0.7s ease 0s;-o-transition: all 0.7s ease 0s;transition: all 0.7s ease 0s;}
.follow-by-email-inner{text-align:center;}
.tombol-submit{margin-top:5px;}
.gsc-search-box input:focus {background: #ffffff;border: 2px solid #b1b1b1;width: 100%;}
.gsc-input{margin-left: 10px}
.search-input{width:88%;float:left;}
.gsc-search-button{background: url(../../4.bp.blogspot.com/-slkXXLUcxqg/VEQI-sJKfZI/AAAAAAAAAlA/9UtEyStfDHw/s1600/slider-arrow-right.png) no-repeat;margin-left: 100px;border-width: 0px;width: 43px;height: 45px;text-indent:0px;font-size:1px;overflow:hidden;}
.search-result {margin: 0 40px;padding: 0 0 10px 0;}
.link-snippet {font-size: 13px;color: #09a000;}
.item-snippet {font-size: 13px;}
.search-result a {color: #1a0dabf;font-size:18px;line-height:1em}
.search-result a:hover {color:#1a0dab;text-decoration:underline !important;}
.search-result a:visited {color:#7e1a8b;}
.PopularPosts .item-title {font-size: 18px;}
.PopularPosts h3.post-title {font-size: 18px;line-height:1.2em;margin:5px 0}
.PopularPosts .snippet-item {font-size: 14px;line-height:1.5em}
.PopularPosts .item-snippet {font-size: 14px;line-height:1.3em}
.PopularPosts .post-content{padding:2px 10px 10px 10px ;background:#fff;margin-bottom:10px;border-radius:3px;}
.Label ul {margin-left:-35px;}
.Label li {display:inline-block;list-style:none;margin:0px 0px 5px 0px;background:#fff;padding:5px 8px;width:48%;font-size:16px;border-radius:3px;}
.FeaturedPost .post-summary {padding:10px;background:#ffffff;border-radius:3px;margin-top:-8px}
.FeaturedPost h3 {font-size: 18px;line-height:1.3em;margin-top:-10px}
.FeaturedPost p {font-size: 14px;line-height:1.3em}
h2.post-title.entry-title,h2.post-title.entry-title a {padding-top:0px;margin-top:0px}
#right-bar h3.title{padding:10px; margin:20px 0 10px 0;background:#2167c7;color:#ffffff;font-size: 22px;border-radius:3px;}
.BlogArchive li {font-size: 16px;line-height:1.3em;}
#ArchiveList {overflow:auto; width:ancho; height:300px; background:white; border-radius:3px; padding:8px;margin-top:-8px}
.LinkList .widget-content {padding:10px;background:#ffffff;border-radius:3px;margin-top:-8px}
.LinkList .widget-content li{list-style:none;margin:3px 0 5px -35px;border-bottom:2px dotted #cee0e5;font-size:16px;line-height:1.6em;padding-bottom:5px}
.TextList .widget-content li{list-style:none;margin:5px 0 10px -35px;background:#fff;padding:8px 10px;border-radius:3px;font-size:16px}
.mepet{padding:0px}
.berbaris{line-height:2em}
.line10{line-height:2.8em}
.line9{line-height:2.6em}
.line8{line-height:2.4em}
.line7{line-height:2.2em}
.line6{line-height:2em}
.line5{line-height:1.8em}
.line4{line-height:1.6em}
.line3{line-height:1.4em}
.line2{line-height:1.2em}
.line1{line-height:1em}
.spasi1{letter-spacing:0.05em;}
.spasi2{letter-spacing:0.1em;}
.spasi3{letter-spacing:0.15em;}
.spasi4{letter-spacing:0.2em;}
.spasi5{letter-spacing:0.25em;}
@media screen and (max-width:991px) {
#right-bar h3.title{padding:8px;font-size: 20px;text-align:center;}
.PopularPosts .post-content,#ArchiveList,.LinkList .widget-content,.TextList .widget-content li {background:#f1f6f7;}
.Label li {background:#f1f6f7;width:49%}
.BlogArchive li,.LinkList .widget-content li,.TextList .widget-content li {font-size: 15px;}
h1.post-title.entry-title,h1.post-title.entry-title a {font-size: 28px;}
}
@media screen and (max-width:480px){
#ignielRelated ul li{width: calc((100% / 2) - 7.5px);margin-right:15px;margin-bottom:15px;  }
#ignielRelated ul li:nth-of-type(3n){margin-right:15px;}
#ignielRelated ul li:nth-of-type(2n){margin-right:0px;}
#ignielRelated ul li a.judul{ font-size:14px;line-height:1.2em;}
.PopularPosts h3.post-title {font-size: 16px;line-height:1.2em;margin:0} 
h1.post-title.entry-title,h1.post-title.entry-title a {font-size: 22px;}
}
</style>
<!-- CSS Cuma di Home -->
<!-- CSS Cuma di Postingan -->
<!-- CSS Cuma di Halaman -->
<style>
body {background:#ffffff}
#left-side{width:100%;float:left;overflow:hidden;}
#right-bar,#artikelterkait{display: none;}
#outer-wrapper {padding-top:32px;margin-bottom:-20px}
h1.post-title.entry-title,h1.post-title.entry-title a {text-align:center;font-size:12px;}
@media screen and (max-width:768px){
#outer-wrapper {padding-top:10px;}
h1.post-title.entry-title,h1.post-title.entry-title a {font-size:6px;}
}
</style>
<!-- CSS Di Search -->
<!-- CSS Di 404 -->
<!-- Style End -->
<!-- Javascript Here -->
<script>
/*<![CDATA[*/
/*! WOW wow.js - v1.3.0 - 2016-10-04
* https://wowjs.uk
* Copyright (c) 2016 Thomas Grainger; Licensed MIT */!function(a,b){if("function"==typeof define&&define.amd)define(["module","exports"],b);else if("undefined"!=typeof exports)b(module,exports);else{var c={exports:{}};b(c,c.exports),a.WOW=c.exports}}(this,function(a,b){"use strict";function c(a,b){if(!(a instanceof b))throw new TypeError("Cannot call a class as a function")}function d(a,b){return b.indexOf(a)>=0}function e(a,b){for(var c in b)if(null==a[c]){var d=b[c];a[c]=d}return a}function f(a){return/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(a)}function g(a){var b=arguments.length<=1||void 0===arguments[1]?!1:arguments[1],c=arguments.length<=2||void 0===arguments[2]?!1:arguments[2],d=arguments.length<=3||void 0===arguments[3]?null:arguments[3],e=void 0;return null!=document.createEvent?(e=document.createEvent("CustomEvent"),e.initCustomEvent(a,b,c,d)):null!=document.createEventObject?(e=document.createEventObject(),e.eventType=a):e.eventName=a,e}function h(a,b){null!=a.dispatchEvent?a.dispatchEvent(b):b in(null!=a)?a[b]():"on"+b in(null!=a)&&a["on"+b]()}function i(a,b,c){null!=a.addEventListener?a.addEventListener(b,c,!1):null!=a.attachEvent?a.attachEvent("on"+b,c):a[b]=c}function j(a,b,c){null!=a.removeEventListener?a.removeEventListener(b,c,!1):null!=a.detachEvent?a.detachEvent("on"+b,c):delete a[b]}function k(){return"innerHeight"in window?window.innerHeight:document.documentElement.clientHeight}Object.defineProperty(b,"__esModule",{value:!0});var l,m,n=function(){function a(a,b){for(var c=0;c<b.length;c++){var d=b[c];d.enumerable=d.enumerable||!1,d.configurable=!0,"value"in d&&(d.writable=!0),Object.defineProperty(a,d.key,d)}}return function(b,c,d){return c&&a(b.prototype,c),d&&a(b,d),b}}(),o=window.WeakMap||window.MozWeakMap||function(){function a(){c(this,a),this.keys=[],this.values=[]}return n(a,[{key:"get",value:function(a){for(var b=0;b<this.keys.length;b++){var c=this.keys[b];if(c===a)return this.values[b]}}},{key:"set",value:function(a,b){for(var c=0;c<this.keys.length;c++){var d=this.keys[c];if(d===a)return this.values[c]=b,this}return this.keys.push(a),this.values.push(b),this}}]),a}(),p=window.MutationObserver||window.WebkitMutationObserver||window.MozMutationObserver||(m=l=function(){function a(){c(this,a),"undefined"!=typeof console&&null!==console&&(console.warn("MutationObserver is not supported by your browser."),console.warn("WOW.js cannot detect dom mutations, please call .sync() after loading new content."))}return n(a,[{key:"observe",value:function(){}}]),a}(),l.notSupported=!0,m),q=window.getComputedStyle||function(a){var b=/(\-([a-z]){1})/g;return{getPropertyValue:function(c){"float"===c&&(c="styleFloat"),b.test(c)&&c.replace(b,function(a,b){return b.toUpperCase()});var d=a.currentStyle;return(null!=d?d[c]:void 0)||null}}},r=function(){function a(){var b=arguments.length<=0||void 0===arguments[0]?{}:arguments[0];c(this,a),this.defaults={boxClass:"wow",animateClass:"animated",offset:0,mobile:!0,live:!0,callback:null,scrollContainer:null,resetAnimation:!0},this.animate=function(){return"requestAnimationFrame"in window?function(a){return window.requestAnimationFrame(a)}:function(a){return a()}}(),this.vendors=["moz","webkit"],this.start=this.start.bind(this),this.resetAnimation=this.resetAnimation.bind(this),this.scrollHandler=this.scrollHandler.bind(this),this.scrollCallback=this.scrollCallback.bind(this),this.scrolled=!0,this.config=e(b,this.defaults),null!=b.scrollContainer&&(this.config.scrollContainer=document.querySelector(b.scrollContainer)),this.animationNameCache=new o,this.wowEvent=g(this.config.boxClass)}return n(a,[{key:"init",value:function(){this.element=window.document.documentElement,d(document.readyState,["interactive","complete"])?this.start():i(document,"DOMContentLoaded",this.start),this.finished=[]}},{key:"start",value:function(){var a=this;if(this.stopped=!1,this.boxes=[].slice.call(this.element.querySelectorAll("."+this.config.boxClass)),this.all=this.boxes.slice(0),this.boxes.length)if(this.disabled())this.resetStyle();else for(var b=0;b<this.boxes.length;b++){var c=this.boxes[b];this.applyStyle(c,!0)}if(this.disabled()||(i(this.config.scrollContainer||window,"scroll",this.scrollHandler),i(window,"resize",this.scrollHandler),this.interval=setInterval(this.scrollCallback,50)),this.config.live){var d=new p(function(b){for(var c=0;c<b.length;c++)for(var d=b[c],e=0;e<d.addedNodes.length;e++){var f=d.addedNodes[e];a.doSync(f)}});d.observe(document.body,{childList:!0,subtree:!0})}}},{key:"stop",value:function(){this.stopped=!0,j(this.config.scrollContainer||window,"scroll",this.scrollHandler),j(window,"resize",this.scrollHandler),null!=this.interval&&clearInterval(this.interval)}},{key:"sync",value:function(){p.notSupported&&this.doSync(this.element)}},{key:"doSync",value:function(a){if("undefined"!=typeof a&&null!==a||(a=this.element),1===a.nodeType){a=a.parentNode||a;for(var b=a.querySelectorAll("."+this.config.boxClass),c=0;c<b.length;c++){var e=b[c];d(e,this.all)||(this.boxes.push(e),this.all.push(e),this.stopped||this.disabled()?this.resetStyle():this.applyStyle(e,!0),this.scrolled=!0)}}}},{key:"show",value:function(a){return this.applyStyle(a),a.className=a.className+" "+this.config.animateClass,null!=this.config.callback&&this.config.callback(a),h(a,this.wowEvent),this.config.resetAnimation&&(i(a,"animationend",this.resetAnimation),i(a,"oanimationend",this.resetAnimation),i(a,"webkitAnimationEnd",this.resetAnimation),i(a,"MSAnimationEnd",this.resetAnimation)),a}},{key:"applyStyle",value:function(a,b){var c=this,d=a.getAttribute("data-wow-duration"),e=a.getAttribute("data-wow-delay"),f=a.getAttribute("data-wow-iteration");return this.animate(function(){return c.customStyle(a,b,d,e,f)})}},{key:"resetStyle",value:function(){for(var a=0;a<this.boxes.length;a++){var b=this.boxes[a];b.style.visibility="visible"}}},{key:"resetAnimation",value:function(a
){if(a.type.toLowerCase().indexOf("animationend")>=0){var b=a.target||a.srcElement;b.className=b.className.replace(this.config.animateClass,"").trim()}}},{key:"customStyle",value:function(a,b,c,d,e){return b&&this.cacheAnimationName(a),a.style.visibility=b?"hidden":"visible",c&&this.vendorSet(a.style,{animationDuration:c}),d&&this.vendorSet(a.style,{animationDelay:d}),e&&this.vendorSet(a.style,{animationIterationCount:e}),this.vendorSet(a.style,{animationName:b?"none":this.cachedAnimationName(a)}),a}},{key:"vendorSet",value:function(a,b){for(var c in b)if(b.hasOwnProperty(c)){var d=b[c];a[""+c]=d;for(var e=0;e<this.vendors.length;e++){var f=this.vendors[e];a[""+f+c.charAt(0).toUpperCase()+c.substr(1)]=d}}}},{key:"vendorCSS",value:function(a,b){for(var c=q(a),d=c.getPropertyCSSValue(b),e=0;e<this.vendors.length;e++){var f=this.vendors[e];d=d||c.getPropertyCSSValue("-"+f+"-"+b)}return d}},{key:"animationName",value:function(a){var b=void 0;try{b=this.vendorCSS(a,"animation-name").cssText}catch(c){b=q(a).getPropertyValue("animation-name")}return"none"===b?"":b}},{key:"cacheAnimationName",value:function(a){return this.animationNameCache.set(a,this.animationName(a))}},{key:"cachedAnimationName",value:function(a){return this.animationNameCache.get(a)}},{key:"scrollHandler",value:function(){this.scrolled=!0}},{key:"scrollCallback",value:function(){if(this.scrolled){this.scrolled=!1;for(var a=[],b=0;b<this.boxes.length;b++){var c=this.boxes[b];if(c){if(this.isVisible(c)){this.show(c);continue}a.push(c)}}this.boxes=a,this.boxes.length||this.config.live||this.stop()}}},{key:"offsetTop",value:function(a){for(;void 0===a.offsetTop;)a=a.parentNode;for(var b=a.offsetTop;a.offsetParent;)a=a.offsetParent,b+=a.offsetTop;return b}},{key:"isVisible",value:function(a){var b=a.getAttribute("data-wow-offset")||this.config.offset,c=this.config.scrollContainer&&this.config.scrollContainer.scrollTop||window.pageYOffset,d=c+Math.min(this.element.clientHeight,k())-b,e=this.offsetTop(a),f=e+a.clientHeight;return d>=e&&f>=c}},{key:"disabled",value:function(){return!this.config.mobile&&f(navigator.userAgent)}}]),a}();b["default"]=r,a.exports=b["default"]});
  new WOW().init();
var containerHeight = $(window).height() / 2;
$('.spacer').css("height", containerHeight);
var x = $('.skills').prev().height() / 4;
$(window).scroll(function() {
  if ($(window).scrollTop() >= x) {
    $('.skill-percent').each(function() {
      $(this).animate({
        width: $(this).data('percent') + '%'
      }, 1000);
    });
  }
});
/*]]>*/
</script>
<!-- Javascript End -->
<link href='../../www.blogger.com/dyn-css/authorization9aeb.css?targetBlogID=1537200080672385442&amp;zx=5531415b-026f-4f4e-8002-df647b341cfc' media='none' onload='if(media!=&#39;all&#39;)media=&#39;all&#39;' rel='stylesheet'/><noscript><link href='../../www.blogger.com/dyn-css/authorization9aeb.css?targetBlogID=1537200080672385442&amp;zx=5531415b-026f-4f4e-8002-df647b341cfc' rel='stylesheet'/></noscript>
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>

</head>
<body>
<div id='headermenu'>
<div id='box1' style='width: 100%; float: center; margin:0;'>
<div class='box-column no-items section' id='header-menu'></div>
</div>
<div style='clear:both;'></div>
</div>
<div id='landingpage'>
<div style='clear:both;'></div>
</div>
<div id='outer-wrapper'>
<div id='left-side'>
<div class='main section' id='postingan'><div class='widget Blog' data-version='1' id='Blog1'>
<div class='blog-posts hfeed'>
<!--Can't find substitution for tag [defaultAdStart]-->

          <div class="date-outer">
        

          <div class="date-posts">
        
<div class='post-outer'>
<div class='post hentry' itemprop='blogPost' itemscope='itemscope' itemtype='https://schema.org/BlogPosting'>
<meta content='1537200080672385442' itemprop='blogId'/>
<meta content='4395665374629080492' itemprop='postId'/>
<a name='4395665374629080492'></a>
<h1 class='post-title entry-title'>
<a href='bagikan-aplikasi-naufalid.html'>Bagikan Aplikasi Naufal.id</a>
</h1>
<div class='post-header'>
<div class='post-header-line-1'></div>
</div>
<div class='post-body entry-content' id='post-body-4395665374629080492' itemprop='description articleBody'>
<head>
<title>Bagikan aplikasi</title>
   <script>
      	Website2APK.shareIntent();
</script>
<script type="text/javascript">
window.location = "https://play.google.com/store/apps/details?id=com.naufal.id";
</script>
<head>
<body> </body>

<!-- Mirrored from bejajadigital24.blogspot.com/p/bagikan-aplikasi-naufalid.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 10 Nov 2022 06:49:34 GMT -->
</html>
<div style='clear: both;'></div>
</div>
<div class='post-footer'>
<div class='post-footer-line post-footer-line-1'><span class='post-icons'>
<span class='item-control blog-admin pid-1730394683'>
<a href='https://www.blogger.com/page-edit.g?blogID=1537200080672385442&amp;pageID=4395665374629080492&amp;from=pencil' title='Edit Halaman'>
<img alt='' class='icon-action' height='18' src='../../img2.blogblog.com/img/icon18_edit_allbkg.gif' width='18'/>
</a>
</span>
</span>
</div>
<div class='post-footer-line post-footer-line-2'></div>
<div class='post-footer-line post-footer-line-3'></div>
</div>
</div>
<div class='konten sharepost'>
<ul>
<li><a class='twitter' href='https://twitter.com/share?url=https://play.google.com/store/apps/details?id=com.naufal.id' rel='nofollow' target='_blank' title='Twitter Tweet'><i class='fa fa-twitter'></i></a></li>
<li><a class='facebook' href='https://www.facebook.com/sharer.php?u=https://play.google.com/store/apps/details?id=com.naufal.id' rel='nofollow' target='_blank' title='Facebook Share'><i class='fa fa-facebook'></i></a></li>
<li><a class='telegram' href='https://t.me/share/url?url=https://play.google.com/store/apps/details?id=com.naufal.id' rel='nofollow' target='_blank' title='Telegram Share'><i class='fa fa-telegram'></i></a></li>
<li><a class='linkedin' href='https://www.linkedin.com/shareArticle?mini=true&amp;url=https://play.google.com/store/apps/details?id=com.naufal.id&amp;title=Bagikan%20Aplikasi%20Naufal.id&amp;summary=' target='_blank'><i class='fa fa-linkedin'></i></a></li>
<li><a class='pinterest' href='https://pinterest.com/pin/create/button/?url=https://play.google.com/store/apps/details?id=com.naufal.id&amp;media=&amp;description=%20+%20data:post.title' target='_blank'><i class='fa fa-pinterest'></i></a></li>
<li><a class='whatsapp' href='https://api.whatsapp.com/send?text=Silahkan%20Kunjungi%20https://play.google.com/store/apps/details?id=com.naufal.id&amp;title=Bejajadigital24&amp;summary=' rel='nofollow' target='_blank'><i aria-hidden='true' class='fa fa-whatsapp'></i></a></li>
</ul>
</div>
<center>
<div id='artikelterkait'>
<div class='konten'>
<div id='ignielRelated'>
<h3 class='title dihome'><span>Blog Post</span></h3>
<h3 class='title dipostingan'><span>Related Post</span></h3>
<script>//<![CDATA[
      var jumlah = 6;
      eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('d a=["\\y","\\x\\1f\\f\\k\\h","\\f\\e\\q\\C\\h\\E","\\w","\\k\\q\\A\\e\\1Y\\1d\\P","\\x\\z\\U\\x\\h\\n\\k\\q\\C","","\\1l\\F\\k\\q","\\e\\q\\h\\n\\1E","\\P\\e\\e\\A","\\1H\\h","\\h\\k\\h\\f\\e","\\S\\F\\q\\h\\e\\q\\h","\\x\\z\\v\\v\\g\\n\\1E","\\v\\e\\A\\k\\g\\1H\\h\\E\\z\\v\\U\\q\\g\\k\\f","\\z\\n\\f","\\A\\g\\h\\g\\2n\\k\\v\\g\\C\\e\\D\\1f\\q\\C\\2q\\U\\g\\x\\e\\1M\\1z\\2p\\k\\1t\\1w\\1d\\1C\\1i\\2k\\2j\\2e\\C\\F\\b\\b\\b\\b\\1I\\1n\\Z\\E\\V\\Z\\C\\b\\b\\b\\b\\V\\b\\b\\b\\b\\1w\\O\\b\\1r\\b\\b\\b\\O\\W\\A\\1b\\2f\\e\\b\\b\\b\\b\\b\\1A\\1I\\O\\1n\\1t\\W\\1r\\O\\b\\1l\\U\\1z\\Z\\D\\C\\b\\b\\b\\b\\2h\\V\\f\\V\\W\\1t\\W\\1r\\v\\1T\\1d\\F\\n\\1M\\2g\\2b\\b\\b\\1B\\1X\\b\\1W\\1V\\1j\\1d\\1K\\1G\\1J\\b\\b\\b\\b\\b\\V\\f\\1K\\1J\\1k\\1n\\z\\W\\v\\O\\O","\\f\\k\\q\\1k","\\n\\e\\f","\\g\\f\\h\\e\\n\\q\\g\\h\\e","\\E\\n\\e\\P","\\n\\g\\q\\A\\F\\v","\\P\\f\\F\\F\\n","\\Z\\1C\\1B","\\y\\f\\k\\w","\\y\\A\\k\\1j\\K\\S\\f\\g\\x\\x\\I\\p\\h\\E\\z\\v\\U\\p\\w\\y\\g\\K\\E\\n\\e\\P\\I\\p","\\p\\K\\h\\k\\h\\f\\e\\I\\p","\\p\\w\\y\\k\\v\\C\\K\\x\\n\\S\\I\\p","\\D\\1i\\1b\\2a\\1b\\X\\E\\1b\\1G\\1A\\X\\1f\\X\\1k\\X\\q\\F\\X\\q\\z","\\n\\e\\1f\\f\\g\\S\\e","\\p\\K\\g\\f\\h\\I\\p","\\p\\D\\w\\y\\D\\g\\w\\y\\D\\A\\k\\1j\\w","\\y\\g\\K\\E\\n\\e\\P\\I\\p","\\p\\K\\S\\f\\g\\x\\x\\I\\p\\1l\\z\\A\\z\\f\\p\\w","\\y\\D\\g\\w","\\y\\D\\f\\k\\w","\\1i\\n\\k\\h\\e"];d Q=0,l=J H(),r=J H(),B=J H();1c 2l(t,T){d i=t[a[1]](a[0]);N(d j=0;j<i[a[2]];j++){u(i[j][a[4]](a[3])!=-1){i[j]=i[j][a[5]](i[j][a[4]](a[3])+1,i[j][a[2]])}};i=i[a[7]](a[6]);i=i[a[5]](0,T-1);1q i}1c 2d(T){N(d i=0;i<T[a[9]][a[8]][a[2]];i++){d t=T[a[9]][a[8]][i];l[Q]=t[a[11]][a[10]];1g=a[6];u(a[12]1h t){1g=t[a[12]][a[10]]}1s{u(a[13]1h t){1g=t[a[13]][a[10]]}};u(a[14]1h t){1m=t[a[14]][a[15]]}1s{1m=a[16]};B[Q]=1m;N(d j=0;j<t[a[17]][a[2]];j++){u(t[a[17]][j][a[18]]==a[19]){r[Q]=t[a[17]][j][a[20]];1o}};Q++}}1c 1L(1p,i){N(d j=0;j<1p[a[2]];j++){u(1p[j]==i){1q 1Q}};1q 1P}1c 1R(){d L=J H(0);d R=J H(0);d 1N=J H(0);d Y=J H(0);N(d m=0;m<r[a[2]];m++){u(!1L(L,r[m])){L[a[2]]+=1;L[L[a[2]]-1]=r[m];R[a[2]]+=1;R[R[a[2]]-1]=l[m];1N[a[2]]+=1;Y[a[2]]+=1;Y[Y[a[2]]-1]=B[m]}};l=R;r=L;B=Y;N(d m=0;m<l[a[2]];m++){d G=1a[a[22]]((l[a[2]]-1)*1a[a[21]]());d 1O=l[m];d 1F=r[m];d 1v=B[m];l[m]=l[G];r[m]=r[G];B[m]=B[G];l[G]=1O;r[G]=1F;B[G]=1v};d 1e=0;d o=1a[a[22]]((l[a[2]]-1)*1a[a[21]]());d 1D=o;d M;d 1y=1u[a[23]];2i(1e<1x){u(r[o]!=1y){M=a[24];M+=a[25]+r[o]+a[26]+l[o]+a[27]+B[o][a[29]](/\\/s[0-9]+(\\-c)?/,a[28])+a[2o]+l[o]+a[26]+l[o]+a[2c];M+=a[2m]+r[o]+a[2r]+l[o]+a[1Z];M+=a[1S];1u[a[1U]](M);1e++;u(1e==1x){1o}};u(o<l[a[2]]-1){o++}1s{o=0};u(o==1D){1o}}}',62,152,'||||||||||_0x91f7|x41||var|x65|x6C|x61|x74|_0x46aax8|_0x46aax9|x69|judul|_0x46aax12|x72|_0x46aax18|x27|x6E|urls||_0x46aax6|if|x6D|x3E|x73|x3C|x75|x64|gambar|x67|x2F|x68|x6F|_0x46aax13|Array|x3D|new|x20|_0x46aaxe|_0x46aax1a|for|x43|x66|rel|_0x46aaxf|x63|_0x46aax7|x62|x45|x51|x2D|_0x46aax11|x55|||||||||||Math|x31|function|x4F|_0x46aax17|x70|postcontent|in|x77|x76|x6B|x6A|postimg|x53|break|_0x46aaxc|return|x49|else|x56|document|_0x46aax16|x42|jumlah|_0x46aax1b|x34|x33|x4C|x52|_0x46aax19|x79|_0x46aax15|x32|x24|x4E|x54|x46|contains|x36|_0x46aax10|_0x46aax14|false|true|ignielRelatedGrid|35|x57|36|x37|x58|x2B|x78|34|||||||||||x39|x48|31|relpostimgcuplik|x47|x50|x38|x44|while|x4B|x30|filter|32|x3A|30|x2C|x3B|33'.split('|'),0,{}));
      //]]></script>

      Mohon maaf, belum ada postingan.
    
</div>
</div>
</div>
</center>
<div class='clear'></div>
<div class='comments' id='comments'>
<a name='comments'></a>
<div id='backlinks-container'>
<div id='Blog1_backlinks-container'>
</div>
</div>
</div>
</div>

        </div></div>
      
<!--Can't find substitution for tag [adEnd]-->
</div>
</div><div class='widget HTML' data-version='2' id='HTML5'>
<h3 class='title'>
Back to Top
</h3>
<div class='widget-content'>
<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-chevron-up"></i></button>
<style type='text/css'>
#myBtn {
    display: none;
    position: fixed;
    bottom: 20px;
    right: 10px;
    z-index: 99999;
    border: none;
    outline: none;
    background-color: #229af7;
    color: white;
    cursor: pointer;
    padding: 10px 16px;
    border-radius: 50%;
    font-size: 17px;
    transition:all 1s ease 50ms;
}
#myBtn:hover {background-color: #555;}
@media (max-width: 480px){
#myBtn {bottom:80px;}
}
</style>

<script type='text/javascript'>
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
</div>
</div></div>
</div>
<div id='right-bar'>
<div class='sidebar-post section' id='sidebar-post'><div class='widget BlogSearch' data-version='2' id='BlogSearch1'>
<h3 class='title'>
Cari Artikel
</h3>
<div class='widget-content' role='search'>
<form action='https://rtrwnet.xyz/search' target='_top'>
<div class='search-input gsc-search-box'>
<input aria-label='Cari blog ini' autocomplete='off' class='gsc-input' name='q' placeholder='Cari blog ini' value=''/>
</div>
<input class='search-action gsc-search-button' type='submit' value='Telusuri'/>
</form>
</div>
</div><div class='widget PopularPosts' data-version='2' id='PopularPosts1'>
<h3 class='title'>
Produk Populer
</h3>
<div class='widget-content'>
<div role='feed'>
<article class='post' role='article'>
<div class='post-content'>
<div class='item-byline'>
</div>
</div>
</article>
</div>
</div>
</div><div class='widget LinkList' data-version='2' id='LinkList1'>
<h3 class='title'>
Daftar Link
</h3>
<div class='widget-content'>
<ul>
<li><a href='https://link.rtkn1.com/product/Blogspot-Landing-Page-Builder-fm63?aff=cunulimut@gmail.com'>Beli Template Blogspot Landingpage Builder</a></li>
<li><a href='https://www.blandingpage.com/'>Jasa Pembuatan Landingpage Blogspot</a></li>
<li><a href='https://rtrwnet.xyz/'>Link 3</a></li>
<li><a href='https://rtrwnet.xyz/'>Link 4</a></li>
<li><a href='https://rtrwnet.xyz/'>Link 5</a></li>
<li><a href='#testimonial-wrap'>Reviews</a></li>
<li><a href='#main-wrapper'>Blog</a></li>
</ul>
</div>
</div><div class='widget Label' data-version='2' id='Label1'>
<h3 class='title'>
Label
</h3>
<div class='widget-content list-label-widget-content'>
<ul>
<li><a class='label-name' href='https://rtrwnet.xyz/search/label/fsfsdfsd'>fsfsdfsd</a></li>
</ul>
</div>
</div><div class='widget BlogArchive' data-version='2' id='BlogArchive1'>
<h3 class='title'>
Arsip Blog
</h3>
<div class='widget-content'>
<div id='ArchiveList'>
<div id='BlogArchive1_ArchiveList'>
<ul class='hierarchy'>
<li class='archivedate'>
<div class='hierarchy-title'>
<a class='post-count-link' href='https://rtrwnet.xyz/2022/'>
2022
<span class='post-count'>2</span>
</a>
</div>
<div class='hierarchy-content'>
<ul class='hierarchy'>
<li class='archivedate'>
<div class='hierarchy-title'>
<a class='post-count-link' href='https://rtrwnet.xyz/2022/03/'>
Maret
<span class='post-count'>1</span>
</a>
</div>
<div class='hierarchy-content'>
<ul class='posts hierarchy'>
<li>
<a href='https://rtrwnet.xyz/2022/03/blog-post.html'>
</a>
</li>
</ul>
</div>
</li>
<li class='archivedate'>
<div class='hierarchy-title'>
<a class='post-count-link' href='https://rtrwnet.xyz/2022/02/'>
Februari
<span class='post-count'>1</span>
</a>
</div>
<div class='hierarchy-content'>
</div>
</li>
</ul>
</div>
</li>
</ul>
</div>
</div>
</div>
</div></div>
</div>
<div style='clear:both;'></div>
</div>
<div>
<div class='bawah section' id='footer'>
<div class='widget HTML' data-version='2' id='HTML2'>
<h3 class='title'>
mobile setting
</h3>
<div class='widget-content'>
<!-- mobile setting -->
<script type='text/javascript'>
var uri = window.location.toString(); if (uri.indexOf("%3D","%3D") > 0) {var clean_uri = uri.substring(0, uri.indexOf("%3D")); window.history.replaceState({}, document.title, clean_uri);}var uri = window.location.toString();if (uri.indexOf("%3D%3D","%3D%3D") > 0) {var clean_uri = uri.substring(0, uri.indexOf("%3D%3D")); window.history.replaceState({}, document.title, clean_uri);}
var uri = window.location.toString(); if (uri.indexOf("&m=1","&m=1") > 0) {var clean_uri = uri.substring(0, uri.indexOf("&m=1")); window.history.replaceState({}, document.title, clean_uri);}
var uri = window.location.toString();if (uri.indexOf("?m=1","?m=1") > 0) {var clean_uri = uri.substring(0, uri.indexOf("?m=1")); window.history.replaceState({}, document.title, clean_uri);}
</script>
</div>
</div></div>
</div>
<script src='../../www.blogger.com/static/v1/widgets/2271878333-widgets.js' type='text/javascript'></script>
<script type='text/javascript'>
//<![CDATA[
if (typeof(BLOG_attachCsiOnload) != 'undefined' && BLOG_attachCsiOnload != null) { window['blogger_templates_experiment_id'] = "templatesV1";window['blogger_blog_id'] = '1537200080672385442';BLOG_attachCsiOnload(''); }_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x1537200080672385442,'//www.blogspotlandingpage.com/','1537200080672385442');
_WidgetManager._RegisterWidget('_ContactFormView', new _WidgetInfo('ContactForm1', 'sidebar3', null, document.getElementById('ContactForm1'), {'contactFormMessageSendingMsg': 'Sending...', 'contactFormMessageSentMsg': 'Your message has been sent.', 'contactFormMessageNotSentMsg': 'Message could not be sent. Please try again later.', 'contactFormInvalidEmailMsg': 'A valid email address is required.', 'contactFormEmptyMessageMsg': 'Message field cannot be empty.', 'title': 'Contact Form', 'blogId': '1537200080672385442', 'contactFormNameMsg': 'Name', 'contactFormEmailMsg': 'Email', 'contactFormMessageMsg': 'Message', 'contactFormSendMsg': 'Send', 'submitUrl': 'https://www.blogger.com/contact-form.do'}, 'displayModeFull'));
//]]>
</script>
<script type='text/javascript'>
//<![CDATA[
$(document.body).append('<div id="page-loader"></div>');
$(window).on("beforeunload", function() {
$('#page-loader').fadeIn(1000).delay(9000).fadeOut(1000);
});
//]]>
</script>
<script>
	$('.thumbnail').hover(
        function(){
            $(this).find('.caption').slideDown(250); //.fadeIn(250)
        },
        function(){
            $(this).find('.caption').slideUp(250); //.fadeOut(205)
        }
    ); 
</script>

<script type="text/javascript" src="../../www.blogger.com/static/v1/widgets/1456298461-widgets.js"></script>
<script type='text/javascript'>
window['__wavt'] = 'AOuZoY7qjUej3d0qs0drMtoSCeW5U6zGnw:1668062951515';_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x3d1537200080672385442','bagikan-aplikasi-naufalid.html','1537200080672385442');
_WidgetManager._SetDataContext([{'name': 'blog', 'data': {'blogId': '1537200080672385442', 'title': 'Bejajadigital24', 'url': 'https://play.google.com/store/apps/details?id=com.naufal.id', 'canonicalUrl': 'https://play.google.com/store/apps/details?id=com.naufal.id', 'homepageUrl': 'https://rtrwnet.xyz/', 'searchUrl': 'https://rtrwnet.xyz/search', 'canonicalHomepageUrl': 'https://rtrwnet.xyz/', 'blogspotFaviconUrl': 'https://rtrwnet.xyz/favicon.ico', 'bloggerUrl': 'https://www.blogger.com', 'hasCustomDomain': false, 'httpsEnabled': true, 'enabledCommentProfileImages': true, 'gPlusViewType': 'FILTERED_POSTMOD', 'adultContent': false, 'analyticsAccountNumber': '', 'encoding': 'UTF-8', 'locale': 'id', 'localeUnderscoreDelimited': 'id', 'languageDirection': 'ltr', 'isPrivate': false, 'isMobile': false, 'isMobileRequest': false, 'mobileClass': '', 'isPrivateBlog': false, 'isDynamicViewsAvailable': true, 'feedLinks': '\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Bejajadigital24 - Atom\x22 href\x3d\x22https://rtrwnet.xyz/feeds/posts/default\x22 /\x3e\n\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/rss+xml\x22 title\x3d\x22Bejajadigital24 - RSS\x22 href\x3d\x22https://rtrwnet.xyz/feeds/posts/default?alt\x3drss\x22 /\x3e\n\x3clink rel\x3d\x22service.post\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Bejajadigital24 - Atom\x22 href\x3d\x22https://www.blogger.com/feeds/1537200080672385442/posts/default\x22 /\x3e\n', 'meTag': '', 'adsenseHostId': 'ca-host-pub-1556223355139109', 'adsenseHasAds': false, 'adsenseAutoAds': false, 'boqCommentIframeForm': true, 'loginRedirectParam': '', 'view': '', 'dynamicViewsCommentsSrc': '//www.blogblog.com/dynamicviews/4224c15c4e7c9321/js/comments.js', 'dynamicViewsScriptSrc': '//www.blogblog.com/dynamicviews/6e88cb65099efd5e', 'plusOneApiSrc': 'https://apis.google.com/js/platform.js', 'disableGComments': true, 'sharing': {'platforms': [{'name': 'Dapatkan link', 'key': 'link', 'shareMessage': 'Dapatkan link', 'target': ''}, {'name': 'Facebook', 'key': 'facebook', 'shareMessage': 'Bagikan ke Facebook', 'target': 'facebook'}, {'name': 'BlogThis!', 'key': 'blogThis', 'shareMessage': 'BlogThis!', 'target': 'blog'}, {'name': 'Twitter', 'key': 'twitter', 'shareMessage': 'Bagikan ke Twitter', 'target': 'twitter'}, {'name': 'Pinterest', 'key': 'pinterest', 'shareMessage': 'Bagikan ke Pinterest', 'target': 'pinterest'}, {'name': 'Email', 'key': 'email', 'shareMessage': 'Email', 'target': 'email'}], 'disableGooglePlus': true, 'googlePlusShareButtonWidth': 0, 'googlePlusBootstrap': '\x3cscript type\x3d\x22text/javascript\x22\x3ewindow.___gcfg \x3d {\x27lang\x27: \x27id\x27};\x3c/script\x3e'}, 'hasCustomJumpLinkMessage': false, 'jumpLinkMessage': 'Baca selengkapnya', 'pageType': 'static_page', 'pageId': '4395665374629080492', 'pageName': 'Bagikan Aplikasi Naufal.id', 'pageTitle': 'Bejajadigital24: Bagikan Aplikasi Naufal.id'}}, {'name': 'features', 'data': {'sharing_get_link_dialog': 'true', 'sharing_native': 'false'}}, {'name': 'messages', 'data': {'edit': 'Edit', 'linkCopiedToClipboard': 'Tautan disalin ke papan klip!', 'ok': 'Oke', 'postLink': 'Tautan Pos'}}, {'name': 'template', 'data': {'name': 'custom', 'localizedName': 'Khusus', 'isResponsive': false, 'isAlternateRendering': false, 'isCustom': true}}, {'name': 'view', 'data': {'classic': {'name': 'classic', 'url': '?view\x3dclassic'}, 'flipcard': {'name': 'flipcard', 'url': '?view\x3dflipcard'}, 'magazine': {'name': 'magazine', 'url': '?view\x3dmagazine'}, 'mosaic': {'name': 'mosaic', 'url': '?view\x3dmosaic'}, 'sidebar': {'name': 'sidebar', 'url': '?view\x3dsidebar'}, 'snapshot': {'name': 'snapshot', 'url': '?view\x3dsnapshot'}, 'timeslide': {'name': 'timeslide', 'url': '?view\x3dtimeslide'}, 'isMobile': false, 'title': 'Bagikan Aplikasi Naufal.id', 'description': ' Bagikan aplikasi          ', 'url': 'https://play.google.com/store/apps/details?id=com.naufal.id', 'type': 'item', 'isSingleItem': true, 'isMultipleItems': false, 'isError': false, 'isPage': true, 'isPost': false, 'isHomepage': false, 'isArchive': false, 'isLabelSearch': false, 'pageId': 4395665374629080492}}]);
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML3', 'landing-page-home', document.getElementById('HTML3'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML7', 'landing-page-home', document.getElementById('HTML7'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_BlogView', new _WidgetInfo('Blog1', 'postingan', document.getElementById('Blog1'), {'cmtInteractionsEnabled': false, 'lightboxEnabled': true, 'lightboxModuleUrl': 'https://www.blogger.com/static/v1/jsbin/3567954105-lbx.js', 'lightboxCssUrl': 'https://www.blogger.com/static/v1/v-css/3523451998-lightbox_bundle.css'}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML5', 'postingan', document.getElementById('HTML5'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_BlogSearchView', new _WidgetInfo('BlogSearch1', 'sidebar-post', document.getElementById('BlogSearch1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_PopularPostsView', new _WidgetInfo('PopularPosts1', 'sidebar-post', document.getElementById('PopularPosts1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_LinkListView', new _WidgetInfo('LinkList1', 'sidebar-post', document.getElementById('LinkList1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_LabelView', new _WidgetInfo('Label1', 'sidebar-post', document.getElementById('Label1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_BlogArchiveView', new _WidgetInfo('BlogArchive1', 'sidebar-post', document.getElementById('BlogArchive1'), {'languageDirection': 'ltr', 'loadingMessage': 'Memuat\x26hellip;'}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML2', 'footer', document.getElementById('HTML2'), {}, 'displayModeFull'));
</script>
</body>
</html>